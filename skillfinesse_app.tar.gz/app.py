from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, make_response, Response, send_from_directory
from datetime import datetime, date, timedelta
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
import sys
import uuid
import json
import requests
import hashlib
import hmac

# Set up Firebase Application Default Credentials before any Firebase imports
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = os.path.join(os.path.dirname(__file__), 'firebase-service-key.json')
from utils import (send_verification_code, check_verification_code, 
                 verify_turnstile, 
                 store_otp_session, validate_otp_session, clear_otp_session, mask_email, send_password_reset_code)

app = Flask(__name__, static_folder=None)  # Disable built-in static folder
app.config['SECRET_KEY'] = 'skillfinesse_secret_key'
app.config["MAX_CONTENT_LENGTH"] = None  # No upload size limit

# Database configuration - Supabase PostgreSQL
from urllib.parse import quote_plus

# Supabase connection details (using pooler)
SUPABASE_HOST = 'aws-0-us-west-1.pooler.supabase.com'
SUPABASE_DATABASE = 'postgres'
SUPABASE_USER = 'postgres.bsveticknlwbjktnunae'
SUPABASE_PASSWORD = 'MyWebDatabase@12'
SUPABASE_PORT = '5432'

# Encode password for URL
encoded_password = quote_plus(SUPABASE_PASSWORD)

# PostgreSQL connection string
app.config['SQLALCHEMY_DATABASE_URI'] = f'postgresql://{SUPABASE_USER}:{encoded_password}@{SUPABASE_HOST}:{SUPABASE_PORT}/{SUPABASE_DATABASE}?sslmode=require'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Configure Bunny CDN for static files
app.config['BUNNY_CDN_STATIC_URL'] = 'https://skill-finesse-videos.b-cdn.net/static'

# Set a local static folder path for file operations (but not for serving)
LOCAL_STATIC_FOLDER = os.path.join(os.path.dirname(__file__), 'static')

# Override static file serving to redirect to Bunny CDN
@app.route('/static/<path:filename>')
def serve_static(filename):
    """Serve static files with fallback to local when CDN fails"""
    from flask import redirect, send_from_directory
    import requests
    import os
    
    # For newly uploaded about and homepage images, serve locally first
    if filename.startswith('images/about_') or filename.startswith('images/homepage_'):
        local_path = os.path.join(LOCAL_STATIC_FOLDER, filename)
        if os.path.exists(local_path):
            # Check if file exists on CDN
            try:
                cdn_url = f"{app.config['BUNNY_CDN_STATIC_URL']}/{filename}"
                response = requests.head(cdn_url, timeout=2)
                if response.status_code == 200:
                    # File exists on CDN, redirect there
                    return redirect(cdn_url, code=301)
                else:
                    # File doesn't exist on CDN, serve locally
                    return send_from_directory(LOCAL_STATIC_FOLDER, filename)
            except:
                # CDN check failed, serve locally
                return send_from_directory(LOCAL_STATIC_FOLDER, filename)
        
    # For all other static files, redirect to Bunny CDN
    return redirect(f"{app.config['BUNNY_CDN_STATIC_URL']}/{filename}", code=301)

# SSLCommerz Configuration (Live Environment)
app.config['SSLCOMMERZ_STORE_ID'] = 'skillfinesse0live'
app.config['SSLCOMMERZ_STORE_PASSWORD'] = '6832CA5EDAA6856122'
app.config['SSLCOMMERZ_SESSION_API'] = 'https://securepay.sslcommerz.com/gwprocess/v4/api.php'
app.config['SSLCOMMERZ_VALIDATION_API'] = 'https://securepay.sslcommerz.com/validator/api/validationserverAPI.php'

# Dynamic URL configuration - will use actual domain in production
# These will be set dynamically in the create_session function based on request context

# Bunny.net Configuration for Video Storage
app.config['BUNNY_API_KEY'] = '08b32784-a662-44ab-8045-0aec41fe17ee0ca63ea3-c5ee-4a7c-bedb-69700ee8e416'
app.config['BUNNY_STORAGE_PASSWORD'] = '30d3761f-3b03-4360-b03727074942-8db5-431c'
app.config['BUNNY_STORAGE_ZONE'] = 'skill-finesse-media'
app.config['BUNNY_PULL_ZONE'] = 'skill-finesse-videos'
app.config['BUNNY_STORAGE_HOSTNAME'] = 'ny.storage.bunnycdn.com'
app.config['BUNNY_CDN_HOSTNAME'] = 'skill-finesse-videos.b-cdn.net'

# Add custom template filter for JSON parsing
@app.template_filter('from_json')
def from_json_filter(value):
    """Parse JSON string in templates"""
    if value:
        try:
            return json.loads(value)
        except (ValueError, TypeError):
            return []
    return []

# Template context processor for site settings
@app.context_processor
def inject_site_settings():
    """Make site settings available to all templates"""
    try:
        site_settings = SiteSettings.get_all_settings()
        return {'site_settings': site_settings}
    except Exception as e:
        # Return defaults if database error
        return {'site_settings': SiteSettings.get_default_settings()}

# Override url_for to use Bunny CDN for static files
from flask import url_for as flask_url_for

def bunny_url_for(endpoint, **values):
    """Custom url_for that uses Bunny CDN for static files"""
    if endpoint == 'static':
        filename = values.get('filename', '')
        # For about and homepage images, use local routes to enable fallback logic
        if filename.startswith('images/about_') or filename.startswith('images/homepage_'):
            return flask_url_for('serve_static', filename=filename)
        return f"{app.config['BUNNY_CDN_STATIC_URL']}/{filename}"
    return flask_url_for(endpoint, **values)

# Make the custom url_for available in templates
@app.template_global()
def url_for(endpoint, **values):
    return bunny_url_for(endpoint, **values)

# Also make bunny_url_for directly available in templates
@app.template_global('bunny_url_for')
def bunny_url_for_template(endpoint, **values):
    return bunny_url_for(endpoint, **values)

# Add custom Jinja2 filters
import json

@app.template_filter('from_json')
def from_json_filter(value):
    """Convert JSON string to Python object"""
    if not value:
        return []
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return []

# Create database and initialize app
db = SQLAlchemy(app)

# Custom Jinja2 filters
@app.template_filter('get_attr')
def get_attr(obj, attr_name):
    """Get attribute value from object or dictionary"""
    if isinstance(obj, dict):
        return obj.get(attr_name)
    return getattr(obj, attr_name, None)

@app.template_filter('get_attr_safe')
def get_attr_safe(obj, attr_name, default=''):
    """Get attribute value from object or dictionary with safe default"""
    if isinstance(obj, dict):
        return obj.get(attr_name, default)
    return getattr(obj, attr_name, default)

# Template context processor for site settings
@app.context_processor
def inject_site_settings():
    """Make site settings available to all templates"""
    try:
        # We'll add this after we define the SiteSettings model
        # For now, return defaults
        default_settings = {
            'logo': 'logo.png',
            'logo_alt': 'Skill Finesse Logo',
            'footer_description': 'Skill Finesse is a premier online learning platform dedicated to empowering individuals with the skills they need to succeed in today\'s competitive world.',
            'social_links': {
                'facebook': 'https://www.facebook.com/Skillfinesse',
                'twitter': '#',
                'instagram': 'https://www.instagram.com/skill.finesse/',
                'linkedin': 'https://www.linkedin.com/in/masud-ashraf-taha-61242a1a9/',
                'youtube': '',
                'github': ''
            },
            'contact_info': {
                'address': 'E-14/X, ICT Tower (14th Floor), Agargaon, Dhaka - 1207, Bangladesh',
                'phone': '+8801786661453',
                'email': 'info@skillfinesse.com'
            }
        }
        return {'site_settings': default_settings}
    except Exception as e:
        # Return defaults if any error
        default_settings = {
            'logo': 'logo.png',
            'logo_alt': 'Skill Finesse Logo',
            'footer_description': 'Skill Finesse is a premier online learning platform.',
            'social_links': {
                'facebook': '#',
                'twitter': '#',
                'instagram': '#',
                'linkedin': '#',
                'youtube': '',
                'github': ''
            },
            'contact_info': {
                'address': 'Contact us for more information',
                'phone': '',
                'email': ''
            }
        }
        return {'site_settings': default_settings}

# Import auth manager
from auth import AuthManager, login_required, admin_required

# Import models
import models
models.db = db

# Import homepage content model - will be defined below

class TrustedDevice(db.Model):
    """
    Model for tracking trusted devices that don't need OTP verification
    every time a user logs in
    """
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=False)
    token_hash = db.Column(db.String(128), nullable=False)
    token_salt = db.Column(db.String(32), nullable=False)
    fingerprint = db.Column(db.String(64), nullable=False)
    device_name = db.Column(db.String(128), nullable=True)
    last_ip = db.Column(db.String(45), nullable=True)  # IPv6 can be up to 45 chars
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_used = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with User
    user = db.relationship('User', backref=db.backref('trusted_devices', lazy=True, cascade='all, delete-orphan'))
    
    def __repr__(self):
        return f'<TrustedDevice {self.id} for User {self.user_id}>'

# Security-related models
class LoginAttempt(db.Model):
    """
    Model for tracking login attempts to detect suspicious activity
    """
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id', ondelete='CASCADE'), nullable=True)
    ip_address = db.Column(db.String(45), nullable=False)
    user_agent = db.Column(db.String(512), nullable=True)
    status = db.Column(db.String(20), nullable=False)  # 'success', 'failed', 'blocked'
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with User
    user = db.relationship('User', backref=db.backref('login_attempts', lazy=True, cascade='all, delete-orphan'))
    
    def __repr__(self):
        return f'<LoginAttempt {self.id} for User {self.user_id} - {self.status}>'

# Replace placeholder models
models.TrustedDevice = TrustedDevice
models.LoginAttempt = LoginAttempt





# Replace placeholder models with actual models

# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    country_code = db.Column(db.String(10), nullable=False)
    country = db.Column(db.String(80), nullable=False)
    birth_date = db.Column(db.Date, nullable=False)
    gender = db.Column(db.String(20), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    phone_verified = db.Column(db.Boolean, default=False)
    email_verified = db.Column(db.Boolean, default=False)
    profile_picture = db.Column(db.String(200), nullable=True)  # Profile picture filename
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    messages = db.relationship('Message', foreign_keys='Message.user_id', backref='user', lazy=True)
    enrollments = db.relationship('Enrollment', backref='user', lazy=True)
    
    @property
    def full_name(self):
        """Return user's full name"""
        return f"{self.first_name} {self.last_name}"

class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    image = db.Column(db.String(120), nullable=True)
    category = db.Column(db.String(100), nullable=True)
    
    # Public discount fields (visible to all)
    discount_percent = db.Column(db.Float, nullable=True, default=0.0)  # Public discount percentage
    discounted_price = db.Column(db.Float, nullable=True)  # Calculated discounted price
    
    # Legacy coupon fields (will be deprecated - use CourseCoupon model instead)
    coupon = db.Column(db.String(50), nullable=True)  # Deprecated
    coupon_discount = db.Column(db.Integer, nullable=True)  # Deprecated
    instructor_name = db.Column(db.String(120), nullable=True)
    instructor_image = db.Column(db.String(120), nullable=True)
    # Additional course details
    about_course = db.Column(db.Text, nullable=True)
    what_youll_learn = db.Column(db.Text, nullable=True)
    course_requirements = db.Column(db.Text, nullable=True)
    instructor_bio = db.Column(db.Text, nullable=True)
    is_published = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    admin = db.relationship('User', backref='courses')
    enrollments = db.relationship('Enrollment', backref='course', lazy=True)
    
    @property
    def current_price(self):
        """Get the current price (with discount if applicable)"""
        if self.discount_percent and self.discount_percent > 0:
            return self.price * (1 - self.discount_percent / 100)
        return self.price
    
    @property
    def has_public_discount(self):
        """Check if course has a public discount"""
        return self.discount_percent and self.discount_percent > 0
    
    def calculate_discounted_price(self):
        """Calculate and update the discounted price"""
        if self.discount_percent and self.discount_percent > 0:
            self.discounted_price = self.price * (1 - self.discount_percent / 100)
        else:
            self.discounted_price = None
        return self.discounted_price

class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    purchased_at = db.Column(db.DateTime, default=datetime.utcnow)

# Video Course Models for Bunny.net Integration
class VideoLesson(db.Model):
    """Model for individual video lessons within a course"""
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    video_url = db.Column(db.String(500), nullable=False)  # Bunny.net CDN URL
    bunny_video_id = db.Column(db.String(100), nullable=True)  # Bunny video ID
    storage_path = db.Column(db.String(500), nullable=True)  # Bunny.net storage path
    order_index = db.Column(db.Integer, nullable=False, default=0)  # For ordering lessons
    duration = db.Column(db.Integer, nullable=True)  # Duration in seconds
    is_preview = db.Column(db.Boolean, default=False)  # Free preview for non-enrolled users
    instructions = db.Column(db.Text, nullable=True)  # Written instructions
    external_links = db.Column(db.Text, nullable=True)  # JSON string of external links
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    course = db.relationship('Course', backref=db.backref('video_lessons', lazy=True, order_by='VideoLesson.order_index'))
    attachments = db.relationship('LessonAttachment', backref='lesson', lazy=True, cascade='all, delete-orphan')
    progress = db.relationship('LessonProgress', backref='lesson', lazy=True)
    
    def __repr__(self):
        return f'<VideoLesson {self.id}: {self.title}>'

class LessonAttachment(db.Model):
    """Model for files attached to video lessons (PDF, HTML, TXT, etc.)"""
    id = db.Column(db.Integer, primary_key=True)
    lesson_id = db.Column(db.Integer, db.ForeignKey('video_lesson.id'), nullable=False)
    filename = db.Column(db.String(200), nullable=False)
    original_filename = db.Column(db.String(200), nullable=False)
    file_url = db.Column(db.String(500), nullable=False)  # Bunny.net storage URL
    file_type = db.Column(db.String(50), nullable=False)  # pdf, html, txt, etc.
    file_size = db.Column(db.BigInteger, nullable=True)  # File size in bytes
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<LessonAttachment {self.id}: {self.original_filename}>'

class LessonProgress(db.Model):
    """Model to track user progress through video lessons"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    lesson_id = db.Column(db.Integer, db.ForeignKey('video_lesson.id'), nullable=False)
    watched_duration = db.Column(db.Integer, default=0)  # Seconds watched
    is_completed = db.Column(db.Boolean, default=False)
    last_watched_at = db.Column(db.DateTime, default=datetime.utcnow)
    completion_percentage = db.Column(db.Float, default=0.0)  # 0-100
    
    # Relationships
    user = db.relationship('User', backref='lesson_progress')
    
    # Unique constraint to prevent duplicate progress records
    __table_args__ = (db.UniqueConstraint('user_id', 'lesson_id', name='unique_user_lesson_progress'),)
    
    def __repr__(self):
        return f'<LessonProgress {self.id}: User {self.user_id}, Lesson {self.lesson_id}>'

class CourseEnrollment(db.Model):
    """Enhanced course enrollment model for video courses"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    enrolled_at = db.Column(db.DateTime, default=datetime.utcnow)
    progress_percentage = db.Column(db.Float, default=0.0)  # Overall course progress
    last_accessed_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_completed = db.Column(db.Boolean, default=False)
    completed_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    user = db.relationship('User', backref='course_enrollments')
    course = db.relationship('Course', backref='enrollments_detailed')
    
    # Unique constraint
    __table_args__ = (db.UniqueConstraint('user_id', 'course_id', name='unique_user_course_enrollment'),)
    
    def __repr__(self):
        return f'<CourseEnrollment {self.id}: User {self.user_id}, Course {self.course_id}>'
    
class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    is_from_admin = db.Column(db.Boolean, default=False)

class Alert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.Text, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    background_color = db.Column(db.String(7), default='#00a651')  # Website primary green color
    text_color = db.Column(db.String(7), default='#ffffff')  # White text for good contrast
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    admin = db.relationship('User', backref='alerts')
    
    def __repr__(self):
        return f'<Alert {self.id}: {self.message[:50]}...>'

# Contact Message Model
class ContactMessage(db.Model):
    """Model for storing contact form submissions"""
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    subject = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)
    admin_reply = db.Column(db.Text, nullable=True)
    replied_at = db.Column(db.DateTime, nullable=True)
    replied_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    status = db.Column(db.String(20), default='new')  # new, replied, resolved
    
    # Relationship with admin who replied
    admin = db.relationship('User', backref='contact_replies')
    
    def __repr__(self):
        return f'<ContactMessage {self.id}: {self.subject} from {self.full_name}>'
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    @property
    def short_message(self):
        """Return truncated message for display"""
        return self.message[:100] + ('...' if len(self.message) > 100 else '')
    
    def mark_as_read(self):
        """Mark message as read"""
        self.is_read = True
        db.session.commit()
    
    def update_status(self, new_status):
        """Update message status"""
        self.status = new_status
        db.session.commit()

# eBook Model
class Ebook(db.Model):
    """Model for eBooks"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    cover_image = db.Column(db.String(120), nullable=True)
    pdf_file = db.Column(db.String(120), nullable=True)
    pdf_url = db.Column(db.String(500), nullable=True)  # Bunny CDN URL for PDF
    
    # Public discount fields (visible to all)
    discount_percent = db.Column(db.Float, nullable=True, default=0.0)  # Public discount percentage
    discounted_price = db.Column(db.Float, nullable=True)  # Calculated discounted price
    
    # Legacy coupon fields (will be deprecated - use EbookCoupon model instead)
    coupon = db.Column(db.String(50), nullable=True)  # Deprecated
    coupon_discount = db.Column(db.Integer, nullable=True)  # Deprecated
    category = db.Column(db.String(100), nullable=True)
    pages = db.Column(db.Integer, nullable=True)
    language = db.Column(db.String(50), default='English')
    isbn = db.Column(db.String(20), nullable=True)
    publication_date = db.Column(db.Date, nullable=True)
    is_published = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationships
    admin = db.relationship('User', backref='ebooks')
    purchases = db.relationship('EbookPurchase', backref='ebook', lazy=True)
    
    def __repr__(self):
        return f'<Ebook {self.name} by {self.author}>'
    
    @property
    def total_purchases(self):
        return len(self.purchases)
    
    @property
    def current_price(self):
        """Get the current price (with discount if applicable)"""
        if self.discount_percent and self.discount_percent > 0:
            return self.price * (1 - self.discount_percent / 100)
        return self.price
    
    @property
    def has_public_discount(self):
        """Check if ebook has a public discount"""
        return self.discount_percent and self.discount_percent > 0
    
    def calculate_discounted_price(self):
        """Calculate and update the discounted price"""
        if self.discount_percent and self.discount_percent > 0:
            self.discounted_price = self.price * (1 - self.discount_percent / 100)
        else:
            self.discounted_price = None
        return self.discounted_price

class EbookPurchase(db.Model):
    """Model for eBook purchases"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    ebook_id = db.Column(db.Integer, db.ForeignKey('ebook.id'), nullable=False)
    purchased_at = db.Column(db.DateTime, default=datetime.utcnow)
    coupon_used = db.Column(db.String(50), nullable=True)
    discount_amount = db.Column(db.Float, nullable=True)
    total_paid = db.Column(db.Float, nullable=False)
    
    # Relationships
    user = db.relationship('User', backref='ebook_purchases')
    # ebook relationship already defined in Ebook model via backref
    
    # Unique constraint to prevent duplicate purchases
    __table_args__ = (db.UniqueConstraint('user_id', 'ebook_id', name='unique_user_ebook'),)
    
    def __repr__(self):
        return f'<EbookPurchase User:{self.user_id} Ebook:{self.ebook_id}>'

# Payment Transaction Models for SSLCommerz Integration
class PaymentTransaction(db.Model):
    __tablename__ = 'payment_transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.String(100), unique=True, nullable=False)  # SSLCommerz tran_id
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Purchase details
    purchase_type = db.Column(db.String(20), nullable=False)  # 'course' or 'ebook'
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=True)
    ebook_id = db.Column(db.Integer, db.ForeignKey('ebook.id'), nullable=True)
    
    # Payment amounts
    amount = db.Column(db.Float, nullable=False)  # Original amount
    discount_amount = db.Column(db.Float, default=0.0)  # Discount applied
    total_amount = db.Column(db.Float, nullable=False)  # Final amount to pay
    currency = db.Column(db.String(3), default='BDT')
    
    # Coupon details
    coupon_code = db.Column(db.String(50), nullable=True)
    coupon_discount_percent = db.Column(db.Float, nullable=True)
    
    # SSLCommerz specific fields
    val_id = db.Column(db.String(100), nullable=True)  # SSLCommerz validation ID
    store_amount = db.Column(db.Float, nullable=True)  # Amount after gateway charges
    card_type = db.Column(db.String(50), nullable=True)
    card_no = db.Column(db.String(20), nullable=True)  # Masked card number
    bank_tran_id = db.Column(db.String(100), nullable=True)
    
    # Transaction status and timing
    status = db.Column(db.String(20), default='PENDING')  # PENDING, PROCESSING, VALID, FAILED, CANCELLED
    risk_level = db.Column(db.Integer, default=0)  # SSLCommerz risk level
    risk_title = db.Column(db.String(100), nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    payment_date = db.Column(db.DateTime, nullable=True)  # When payment was completed
    
    # Gateway response data (JSON)
    gateway_response = db.Column(db.Text, nullable=True)  # Store full SSLCommerz response
    
    # Relationships
    user = db.relationship('User', backref='payment_transactions')
    course = db.relationship('Course', backref='payment_transactions')
    ebook = db.relationship('Ebook', backref='payment_transactions')
    
    def __repr__(self):
        return f'<PaymentTransaction {self.transaction_id} - {self.status}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'transaction_id': self.transaction_id,
            'user_id': self.user_id,
            'purchase_type': self.purchase_type,
            'course_id': self.course_id,
            'ebook_id': self.ebook_id,
            'amount': self.amount,
            'discount_amount': self.discount_amount,
            'total_amount': self.total_amount,
            'currency': self.currency,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'payment_date': self.payment_date.isoformat() if self.payment_date else None
        }
    
    @staticmethod
    def generate_transaction_id():
        """Generate unique transaction ID"""
        import time
        timestamp = str(int(time.time()))
        random_suffix = str(uuid.uuid4())[:8]
        return f"SF_{timestamp}_{random_suffix}"
    
    def update_status(self, new_status, gateway_data=None):
        """Update transaction status with optional gateway data"""
        self.status = new_status
        self.updated_at = datetime.utcnow()
        
        if new_status in ['VALID', 'VALIDATED']:
            self.payment_date = datetime.utcnow()
        
        if gateway_data:
            self.gateway_response = json.dumps(gateway_data)
            
            # Update specific fields from gateway response
            if 'val_id' in gateway_data:
                self.val_id = gateway_data['val_id']
            if 'store_amount' in gateway_data:
                self.store_amount = float(gateway_data['store_amount'])
            if 'card_type' in gateway_data:
                self.card_type = gateway_data['card_type']
            if 'card_no' in gateway_data:
                self.card_no = gateway_data['card_no']
            if 'bank_tran_id' in gateway_data:
                self.bank_tran_id = gateway_data['bank_tran_id']
            if 'risk_level' in gateway_data:
                self.risk_level = int(gateway_data['risk_level'])
            if 'risk_title' in gateway_data:
                self.risk_title = gateway_data['risk_title']
        
        db.session.commit()

class PaymentLog(db.Model):
    __tablename__ = 'payment_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.String(100), db.ForeignKey('payment_transactions.transaction_id'), nullable=False)
    
    # Log details
    action = db.Column(db.String(50), nullable=False)  # 'session_created', 'ipn_received', 'validation_success', etc.
    status = db.Column(db.String(20), nullable=False)
    message = db.Column(db.Text, nullable=True)
    data = db.Column(db.Text, nullable=True)  # JSON data
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # IP tracking
    ip_address = db.Column(db.String(45), nullable=True)
    user_agent = db.Column(db.String(500), nullable=True)
    
    # Relationship
    transaction = db.relationship('PaymentTransaction', backref='logs')
    
    def __repr__(self):
        return f'<PaymentLog {self.transaction_id} - {self.action}>'
    
    @staticmethod
    def log_action(transaction_id, action, status, message=None, data=None, request_obj=None):
        """Create a payment log entry"""
        log_entry = PaymentLog(
            transaction_id=transaction_id,
            action=action,
            status=status,
            message=message,
            data=json.dumps(data) if data else None,
            ip_address=request_obj.remote_addr if request_obj else None,
            user_agent=request_obj.headers.get('User-Agent', '')[:500] if request_obj else None
        )
        db.session.add(log_entry)
        db.session.commit()
        return log_entry

# Coupon Models for Courses and Ebooks
class CourseCoupon(db.Model):
    __tablename__ = 'course_coupons'
    
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    code = db.Column(db.String(50), nullable=False)
    discount_percent = db.Column(db.Float, nullable=False)  # Percentage discount (0-100)
    is_active = db.Column(db.Boolean, default=True)
    usage_limit = db.Column(db.Integer, nullable=True)  # NULL means unlimited
    used_count = db.Column(db.Integer, default=0)
    valid_from = db.Column(db.DateTime, default=datetime.utcnow)
    valid_until = db.Column(db.DateTime, nullable=True)  # NULL means no expiry
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    course = db.relationship('Course', backref='coupons')
    
    # Unique constraint to prevent duplicate coupon codes for same course
    __table_args__ = (db.UniqueConstraint('course_id', 'code', name='unique_course_coupon'),)
    
    def __repr__(self):
        return f'<CourseCoupon {self.code} for Course:{self.course_id}>'
    
    def is_valid(self):
        """Check if coupon is currently valid"""
        now = datetime.utcnow()
        
        # Check if active
        if not self.is_active:
            return False, "Coupon is not active"
        
        # Check validity period
        if self.valid_from and now < self.valid_from:
            return False, "Coupon is not yet valid"
        
        if self.valid_until and now > self.valid_until:
            return False, "Coupon has expired"
        
        # Check usage limit
        if self.usage_limit and self.used_count >= self.usage_limit:
            return False, "Coupon usage limit reached"
        
        return True, "Valid"
    
    def apply_discount(self, original_price):
        """Calculate discounted price"""
        discount_amount = original_price * (self.discount_percent / 100)
        final_price = original_price - discount_amount
        return {
            'original_price': original_price,
            'discount_percent': self.discount_percent,
            'discount_amount': discount_amount,
            'final_price': final_price
        }

class EbookCoupon(db.Model):
    __tablename__ = 'ebook_coupons'
    
    id = db.Column(db.Integer, primary_key=True)
    ebook_id = db.Column(db.Integer, db.ForeignKey('ebook.id'), nullable=False)
    code = db.Column(db.String(50), nullable=False)
    discount_percent = db.Column(db.Float, nullable=False)  # Percentage discount (0-100)
    is_active = db.Column(db.Boolean, default=True)
    usage_limit = db.Column(db.Integer, nullable=True)  # NULL means unlimited
    used_count = db.Column(db.Integer, default=0)
    valid_from = db.Column(db.DateTime, default=datetime.utcnow)
    valid_until = db.Column(db.DateTime, nullable=True)  # NULL means no expiry
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    ebook = db.relationship('Ebook', backref='coupons')
    
    # Unique constraint to prevent duplicate coupon codes for same ebook
    __table_args__ = (db.UniqueConstraint('ebook_id', 'code', name='unique_ebook_coupon'),)
    
    def __repr__(self):
        return f'<EbookCoupon {self.code} for Ebook:{self.ebook_id}>'
    
    def is_valid(self):
        """Check if coupon is currently valid"""
        now = datetime.utcnow()
        
        # Check if active
        if not self.is_active:
            return False, "Coupon is not active"
        
        # Check validity period
        if self.valid_from and now < self.valid_from:
            return False, "Coupon is not yet valid"
        
        if self.valid_until and now > self.valid_until:
            return False, "Coupon has expired"
        
        # Check usage limit
        if self.usage_limit and self.used_count >= self.usage_limit:
            return False, "Coupon usage limit reached"
        
        return True, "Valid"
    
    def apply_discount(self, original_price):
        """Calculate discounted price"""
        discount_amount = original_price * (self.discount_percent / 100)
        final_price = original_price - discount_amount
        return {
            'original_price': original_price,
            'discount_percent': self.discount_percent,
            'discount_amount': discount_amount,
            'final_price': final_price
        }

# Blog model moved to after routes section

# Routes
@app.route('/')
def index():
    # Get featured courses for homepage
    courses = Course.query.order_by(Course.created_at.desc()).limit(6).all()
    
    # Get homepage content for all sections
    hero_content = HomepageContent.get_hero_content()
    courses_content = HomepageContent.get_courses_content()
    features_content = HomepageContent.get_features_content()
    videos_content = HomepageContent.get_videos_content()
    about_content = HomepageContent.get_about_content()
    cta_content = HomepageContent.get_cta_content()
    
    # Use defaults if no content exists for each section
    if not hero_content:
        hero_data = HomepageContent.get_default_hero_content()
    else:
        hero_data = {
            'hero_title': hero_content.hero_title,
            'hero_subtitle': hero_content.hero_subtitle,
            'hero_description': hero_content.hero_description,
            'hero_button_text': hero_content.hero_button_text,
            'hero_button_url': hero_content.hero_button_url,
            'hero_video_button_text': hero_content.hero_video_button_text,
            'hero_stats': hero_content.hero_stats,
            'hero_slider_images': hero_content.hero_slider_images
        }
    
    if not courses_content:
        courses_data = HomepageContent.get_default_courses_content()
    else:
        courses_data = {
            'courses_title': courses_content.courses_title,
            'courses_subtitle': courses_content.courses_subtitle,
            'courses_description': courses_content.courses_description,
            'courses_grid_title': courses_content.courses_grid_title,
            'courses_grid_badge': courses_content.courses_grid_badge,
            'courses_cards': courses_content.courses_cards,
            'courses_mini_slider_title': courses_content.courses_mini_slider_title,
            'courses_mini_slider_subtitle': courses_content.courses_mini_slider_subtitle,
            'courses_mini_slider_images': courses_content.courses_mini_slider_images
        }
    
    if not features_content:
        features_data = HomepageContent.get_default_features_content()
    else:
        features_data = {
            'features_title': features_content.features_title,
            'features_subtitle': features_content.features_subtitle,
            'features_items': features_content.features_items
        }
    
    if not videos_content:
        videos_data = HomepageContent.get_default_videos_content()
    else:
        videos_data = {
            'videos_title': videos_content.videos_title,
            'videos_subtitle': videos_content.videos_subtitle,
            'videos_youtube_link': videos_content.videos_youtube_link,
            'videos_items': videos_content.videos_items
        }
    
    if not about_content:
        about_data = HomepageContent.get_default_about_content()
    else:
        about_data = {
            'about_title': about_content.about_title,
            'about_content': about_content.about_content,
            'about_images': about_content.about_images,
            'about_points': about_content.about_points
        }
    
    if not cta_content:
        cta_data = HomepageContent.get_default_cta_content()
    else:
        cta_data = {
            'cta_title': cta_content.cta_title,
            'cta_content': cta_content.cta_content,
            'cta_button_text': cta_content.cta_button_text,
            'cta_button_url': cta_content.cta_button_url,
            'cta_images': cta_content.cta_images,
            'cta_points': cta_content.cta_points
        }
    
    return render_template('index.html', 
                         courses=courses, 
                         hero_data=hero_data,
                         courses_data=courses_data,
                         features_data=features_data,
                         videos_data=videos_data,
                         about_data=about_data,
                         cta_data=cta_data,
                         now=datetime.utcnow())

@app.route('/join')
def join():
    return render_template('join.html', now=datetime.utcnow())

@app.route('/join/signup', methods=['POST'])
def join_signup():
    # Verify Cloudflare Turnstile
    turnstile_response = request.form.get('cf-turnstile-response')
    if not verify_turnstile(turnstile_response, request.remote_addr):
        flash('Security check failed. Please try again.', 'danger')
        return redirect(url_for('join'))
    
    first_name = request.form.get('first_name')
    last_name = request.form.get('last_name')
    email = request.form.get('email')
    phone_number = request.form.get('phone_number')
    country_code = request.form.get('country_code')
    country = request.form.get('country')
    birth_date_str = request.form.get('birthday')
    birth_date = datetime.strptime(birth_date_str, '%Y-%m-%d').date()
    
    # Calculate age from birthday
    today = datetime.today()
    age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
    
    # Check if user is at least 13 years old
    if age < 13:
        flash('You must be at least 13 years old to register', 'danger')
        return redirect(url_for('join'))
    gender = request.form.get('gender')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    is_admin = request.form.get('is_admin') == 'on'
    
    # Check if passwords match
    if password != confirm_password:
        flash('Passwords do not match', 'danger')
        return redirect(url_for('join'))
    
    # Check if email already exists
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        flash('Email already registered', 'danger')
        return redirect(url_for('join'))
    
    # Check if phone number already exists
    existing_phone = User.query.filter_by(phone_number=phone_number, country_code=country_code).first()
    if existing_phone:
        flash('Phone number already registered', 'danger')
        return redirect(url_for('join'))
    
    # Create username from first and last name
    username = first_name.lower() + last_name.lower()
    # Make sure username is unique
    counter = 1
    base_username = username
    while User.query.filter_by(username=username).first():
        username = base_username + str(counter)
        counter += 1
    
    # Hash password
    hashed_password = generate_password_hash(password)
    
    # Store signup data in session
    session['signup_data'] = {
        'first_name': first_name,
        'last_name': last_name,
        'username': username,
        'email': email,
        'phone_number': phone_number,
        'country_code': country_code,
        'country': country,
        'birth_date': birth_date_str,
        'gender': gender,
        'password': hashed_password,
        'is_admin': is_admin
    }
    
    # Send verification email
    display_name = f"{first_name} {last_name}"
    result = send_verification_code(email, display_name)
    
    if result['success']:
        # Store identifier for email verification
        store_otp_session(email)
        flash('Verification email sent! Please check your email and click the verification link.', 'success')
        # Stay on join page with waiting state instead of redirecting
        return render_template('join.html', 
                             waiting_for_verification=True,
                             email=email,
                             display_name=display_name,
                             now=datetime.utcnow())
    else:
        flash(f'Error sending verification email: {result.get("message", "Unknown error")}', 'danger')
        return redirect(url_for('join'))

@app.route('/verify-otp/<mode>', methods=['GET', 'POST'])
def verify_otp(mode):
    # Check if mode is supported (only signup and reset, not signin)
    if mode not in ['signup', 'reset']:
        flash('Invalid verification mode.', 'danger')
        return redirect(url_for('join'))
        
    if request.method == 'GET':
        if not session.get('otp_phone_number'):
            flash('Session expired. Please try again.', 'danger')
            return redirect(url_for('join'))
            
        # Get the phone number and mask it to show only the last 4 digits
        phone_number = session.get('otp_phone_number')
        masked_phone = mask_phone_number(phone_number)
        
        return render_template('verify_otp.html', mode=mode, phone_number=phone_number, masked_phone=masked_phone, now=datetime.utcnow())
    
    if request.method == 'POST':
        # Verify Cloudflare Turnstile
        turnstile_response = request.form.get('cf-turnstile-response')
        if not verify_turnstile(turnstile_response, request.remote_addr):
            flash('Security check failed. Please try again.', 'danger')
            return redirect(url_for('verify_otp', mode=mode))
        
        otp_code = request.form.get('otp_code')
        phone_number = session.get('otp_phone_number')
        user_identifier = session.get('otp_user_identifier')
        
        if not otp_code or not phone_number or not user_identifier:
            flash('Session expired. Please try again.', 'danger')
            return redirect(url_for('join'))
        
        # Verify OTP code
        result = check_verification_code(phone_number, otp_code)
        
        if result['success'] and result['status'] == 'approved':
            # OTP verified successfully
            session['otp_verified'] = True
            
            if mode == 'signup':
                # Complete registration
                signup_data = session.get('signup_data')
                if not signup_data:
                    flash('Registration data missing. Please try again.', 'danger')
                    clear_otp_session()
                    return redirect(url_for('join'))
                
                birth_date = datetime.strptime(signup_data['birth_date'], '%Y-%m-%d').date()
                
                # Create the user
                new_user = User(
                    first_name=signup_data['first_name'],
                    last_name=signup_data['last_name'],
                    username=signup_data['username'],
                    email=signup_data['email'],
                    phone_number=signup_data['phone_number'],
                    country_code=signup_data['country_code'],
                    country=signup_data['country'],
                    birth_date=birth_date,
                    gender=signup_data['gender'],
                    password=signup_data['password'],
                    is_admin=signup_data['is_admin'],
                    phone_verified=True,
                    email_verified=False
                )
                
                db.session.add(new_user)
                db.session.commit()
                
                # Clean up session
                session.pop('signup_data', None)
                clear_otp_session()
                
                flash('Registration successful! Please sign in.', 'success')
                # Note: redirect_after_login is preserved in session for after signin
                return redirect(url_for('join'))
            
            # REMOVED: signin mode no longer uses OTP verification
            
            elif mode == 'reset':
                # Store in session that the reset is verified
                session['reset_verified'] = True
                return redirect(url_for('reset_password'))
        else:
            flash('Invalid verification code. Please try again.', 'danger')
            return redirect(url_for('verify_otp', mode=mode))
        
        return redirect(url_for('join'))

@app.route('/resend-otp/<mode>', methods=['POST'])
def resend_otp(mode):
    # Check if mode is supported (only signup and reset, not signin)
    if mode not in ['signup', 'reset']:
        flash('Invalid verification mode.', 'danger')
        return redirect(url_for('join'))
        
    # Verify Cloudflare Turnstile
    turnstile_response = request.form.get('cf-turnstile-response')
    if not verify_turnstile(turnstile_response, request.remote_addr):
        flash('Security check failed. Please try again.', 'danger')
        return redirect(url_for('verify_otp', mode=mode))
    
    phone_number = session.get('otp_phone_number')
    if not phone_number:
        flash('Session expired. Please try again.', 'danger')
        return redirect(url_for('join'))
    
    # Resend verification code
    result = send_verification_code(phone_number)
    
    if result['success']:
        flash('Verification code resent.', 'success')
    else:
        flash(f'Error sending verification code: {result.get("message", "Unknown error")}', 'danger')
    
    return redirect(url_for('verify_otp', mode=mode))

@app.route('/join/signin', methods=['POST'])
def join_signin():
    # Verify Cloudflare Turnstile (skip in test mode)
    turnstile_response = request.form.get('cf-turnstile-response')
    if not app.config.get('TESTING') and not verify_turnstile(turnstile_response, request.remote_addr):
        flash('Security check failed. Please try again.', 'danger')
        return redirect(url_for('join'))
    
    login_method = request.form.get('login_method')
    password = request.form.get('password')
    
    user = None
    
    if login_method == 'email':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
    else:  # phone
        phone_number = request.form.get('phone_number')
        country_code = request.form.get('country_code')
        user = User.query.filter_by(phone_number=phone_number, country_code=country_code).first()
    
    # Record login attempt
    login_attempt = LoginAttempt(
        user_id=user.id if user else None,
        ip_address=request.remote_addr,
        user_agent=request.user_agent.string,
        status='pending'
    )
    db.session.add(login_attempt)
    db.session.commit()
    
    if not user:
        login_attempt.status = 'failed'
        db.session.commit()
        flash('Invalid credentials', 'danger')
        return redirect(url_for('join'))
    
    if check_password_hash(user.password, password):
        # Check if user has verified their email
        if not user.email_verified:
            login_attempt.status = 'failed'
            db.session.commit()
            flash('Please verify your email before logging in. Check your inbox for the verification link.', 'warning')
            return redirect(url_for('join'))
        
        # MODIFIED: No OTP required for login, directly log in the user
        session['user_id'] = user.id
        session['is_admin'] = user.is_admin
        
        # Record successful login
        login_attempt.status = 'success'
        db.session.commit()
        
        # Register this device as trusted (optional - for consistency)
        device_token = AuthManager.register_trusted_device(user.id)
        
        # Check if there's a stored redirect URL
        redirect_url = session.pop('redirect_after_login', None)
        
        # Admin users should always go to admin dashboard, regardless of stored redirect
        if user.is_admin:
            redirect_to = url_for('admin_dashboard')
        elif redirect_url:
            # Non-admin users can be redirected to the originally intended page
            redirect_to = redirect_url
        else:
            # Default redirect behavior for non-admin users
            redirect_to = url_for('user_dashboard')
        
        # Create response with redirect
        resp = make_response(redirect(redirect_to))
        
        # Set secure HTTP-only cookie with the device token
        expires = datetime.utcnow() + timedelta(days=30)
        resp.set_cookie(
            'device_token',
            device_token,
            expires=expires,
            httponly=True,
            secure=request.is_secure,
            samesite='Lax'
        )
        
        flash('Login successful!', 'success')
        return resp
    else:
        # Wrong password
        login_attempt.status = 'failed'
        db.session.commit()
        flash('Invalid credentials', 'danger')
        return redirect(url_for('join'))

@app.route('/courses')
def courses():
    # Get page number from query parameter, default to 1
    page = request.args.get('page', 1, type=int)
    per_page = 6  # 6 courses per page
    
    # Get only published courses with pagination
    courses_pagination = Course.query.filter_by(is_published=True)\
        .order_by(Course.created_at.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    courses = courses_pagination.items
    
    return render_template('course.html', 
                         courses=courses, 
                         pagination=courses_pagination,
                         now=datetime.utcnow())

@app.route('/api/video/<int:video_id>/stream')
def stream_video(video_id):
    """Stream video with proper headers for preview"""
    try:
        video = VideoLesson.query.get_or_404(video_id)
        
        # For preview videos, allow access
        if video.is_preview:
            return redirect(video.video_url)
        
        # For non-preview videos, check enrollment
        if not session.get('user_id'):
            return jsonify({'error': 'Authentication required'}), 401
            
        # Check if user is enrolled
        enrollment = CourseEnrollment.query.filter_by(
            user_id=session['user_id'],
            course_id=video.course_id
        ).first()
        
        if not enrollment:
            return jsonify({'error': 'Enrollment required'}), 403
            
        return redirect(video.video_url)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/course/<int:course_id>/preview-videos')
def get_course_preview_videos(course_id):
    """Get free preview videos for a course"""
    try:
        # Get all preview videos for this course
        preview_videos = VideoLesson.query.filter_by(
            course_id=course_id,
            is_preview=True
        ).order_by(VideoLesson.order_index).all()
        
        videos_data = []
        for video in preview_videos:
            videos_data.append({
                'id': video.id,
                'title': video.title,
                'description': video.description,
                'video_url': video.video_url,
                'duration': video.duration,
                'order_index': video.order_index
            })
        
        return jsonify({
            'success': True,
            'videos': videos_data
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/course/<int:course_id>')
def course_details(course_id):
    # Get course details
    course = Course.query.filter_by(id=course_id, is_published=True).first_or_404()
    
    # Check if user is enrolled (if logged in)
    is_enrolled = False
    if session.get('user_id') and not session.get('is_admin'):
        # Check both old and new enrollment systems
        old_enrollment = Enrollment.query.filter_by(
            user_id=session['user_id'],
            course_id=course_id
        ).first()
        
        new_enrollment = CourseEnrollment.query.filter_by(
            user_id=session['user_id'],
            course_id=course_id
        ).first()
        
        is_enrolled = old_enrollment is not None or new_enrollment is not None
    
    return render_template('course_details.html', course=course, is_enrolled=is_enrolled, now=datetime.utcnow())

@app.route('/course/<int:course_id>/purchase')
def course_purchase(course_id):
    course = Course.query.filter_by(id=course_id, is_published=True).first_or_404()
    
    # Check if user is logged in (admins can access purchase pages for testing)
    if not session.get('user_id'):
        # Store the intended redirect URL in session
        session['redirect_after_login'] = url_for('course_purchase', course_id=course_id)
        # Show course info but require login for purchase
        return render_template('course_purchase_login.html', course=course, now=datetime.utcnow())
    
    # Check if already enrolled
    existing_enrollment = Enrollment.query.filter_by(
        user_id=session['user_id'],
        course_id=course_id
    ).first()
    
    if existing_enrollment:
        flash('You are already enrolled in this course', 'info')
        return redirect(url_for('user_courses'))
    
    current_user = User.query.get(session['user_id'])
    return render_template('course_purchase.html', course=course, current_user=current_user, now=datetime.utcnow())

# eBook Routes
@app.route('/ebooks')
def ebooks():
    # Get page number from query parameter, default to 1
    page = request.args.get('page', 1, type=int)
    per_page = 6  # 6 ebooks per page
    
    # Get only published ebooks with pagination
    ebooks_pagination = Ebook.query.filter_by(is_published=True)\
        .order_by(Ebook.created_at.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    ebooks = ebooks_pagination.items
    
    return render_template('ebooks.html', 
                         ebooks=ebooks, 
                         pagination=ebooks_pagination,
                         now=datetime.utcnow())

@app.route('/ebook/<int:ebook_id>')
def ebook_details(ebook_id):
    # Get ebook details
    ebook = Ebook.query.filter_by(id=ebook_id, is_published=True).first_or_404()
    
    # Check if user has purchased (if logged in)
    has_purchased = False
    if session.get('user_id') and not session.get('is_admin'):
        purchase = EbookPurchase.query.filter_by(
            user_id=session['user_id'],
            ebook_id=ebook_id
        ).first()
        has_purchased = purchase is not None
    
    return render_template('ebook_details.html', ebook=ebook, has_purchased=has_purchased, now=datetime.utcnow())

@app.route('/ebook/<int:ebook_id>/purchase')
def ebook_purchase(ebook_id):
    ebook = Ebook.query.filter_by(id=ebook_id, is_published=True).first_or_404()
    
    # Check if user is logged in (admins can access purchase pages for testing)
    if not session.get('user_id'):
        # Store the intended redirect URL in session
        session['redirect_after_login'] = url_for('ebook_purchase', ebook_id=ebook_id)
        # Redirect to join page for purchase
        flash('Please join or login to purchase this eBook.', 'info')
        return redirect(url_for('join'))
    
    # Check if already purchased
    existing_purchase = EbookPurchase.query.filter_by(
        user_id=session['user_id'],
        ebook_id=ebook_id
    ).first()
    
    if existing_purchase:
        flash('You have already purchased this eBook!', 'info')
        return redirect(url_for('user_dashboard') + '#ebooks')
    
    current_user = User.query.get(session['user_id'])
    return render_template('ebook_purchase.html', ebook=ebook, current_user=current_user, now=datetime.utcnow())

@app.route('/ebook/<int:ebook_id>/read')
@login_required
def read_ebook(ebook_id):
    """Ebook reading interface for purchased users"""
    user_id = session.get('user_id')
    
    # Check if user has purchased this ebook
    purchase = EbookPurchase.query.filter_by(user_id=user_id, ebook_id=ebook_id).first()
    if not purchase:
        flash('You need to purchase this eBook to read it.', 'warning')
        return redirect(url_for('ebook_details', ebook_id=ebook_id))
    
    ebook = Ebook.query.get_or_404(ebook_id)
    user = User.query.get(user_id)
    
    # Get total pages for the ebook
    total_pages = 1
    try:
        from pdf2image import convert_from_bytes
        
        # Get PDF content
        pdf_content = None
        if ebook.pdf_url:
            import requests
            response = requests.get(ebook.pdf_url, timeout=30)
            if response.status_code == 200:
                pdf_content = response.content
        elif ebook.pdf_file:
            pdf_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', 'ebooks', ebook.pdf_file)
            if os.path.exists(pdf_path):
                with open(pdf_path, 'rb') as f:
                    pdf_content = f.read()
        
        if pdf_content:
            # Get total page count efficiently
            images = convert_from_bytes(pdf_content, dpi=72, first_page=1, last_page=50)
            if len(images) == 50:
                # If we got 50 pages, try to get more to find actual total
                try:
                    more_images = convert_from_bytes(pdf_content, dpi=72, first_page=51, last_page=200)
                    total_pages = 50 + len(more_images)
                except:
                    total_pages = 50
            else:
                total_pages = len(images)
                
    except Exception as e:
        print(f"Error getting page count: {str(e)}")
        total_pages = 1
    
    # Get user's purchased ebooks for sidebar
    user_purchases = EbookPurchase.query.filter_by(user_id=user_id).all()
    purchased_ebooks = []
    for purchase in user_purchases:
        purchased_ebook = Ebook.query.get(purchase.ebook_id)
        if purchased_ebook and purchased_ebook.is_published:
            purchased_ebooks.append(purchased_ebook)
    
    return render_template('ebook_read.html', 
                         ebook=ebook, 
                         purchased_ebooks=purchased_ebooks,
                         purchase=purchase,
                         user=user,
                         total_pages=total_pages)

# REMOVED DUPLICATE secure_pdf_viewer - see line 2157 for the correct implementation
# @app.route('/secure-pdf-viewer/<int:ebook_id>')
# @login_required
# def secure_pdf_viewer_old(ebook_id):
#     """Ultra-secure PDF viewer - converts PDF to images to prevent saving"""
#     user_id = session.get('user_id')
#     
#     # Verify user has access to this ebook
#     purchase = EbookPurchase.query.filter_by(user_id=user_id, ebook_id=ebook_id).first()
#     if not purchase:
#         return "Access Denied", 403
    
#    ebook = Ebook.query.get_or_404(ebook_id)
#    user = User.query.get(user_id)
    
#    # For security, we'll use a secure viewer that prevents PDF downloading
#    # The PDF will be served through a protected endpoint that converts to images
    
#    # Create secure HTML with image-based PDF viewer to prevent saving
#    secure_html = f"""
#    <!DOCTYPE html>
#    <html>
#    <head>
#        <meta charset="UTF-8">
#        <title>Secure Document Viewer</title>
#        <style>
#            * {{
#                margin: 0;
#                padding: 0;
#                box-sizing: border-box;
#                -webkit-user-select: none !important;
#                -moz-user-select: none !important;
#                user-select: none !important;
#                -webkit-touch-callout: none !important;
#                -webkit-tap-highlight-color: transparent !important;
#            }}
            
#            body {{
#                background: #f8f9fa;
#                overflow-x: hidden;
#                overflow-y: auto;
#                font-family: Arial, sans-serif;
#                position: relative;
#                min-height: 100vh;
#            }}
            
#            #documentContainer {{
#                width: 100%;
#                min-height: 100vh;
#                position: relative;
#                background: white;
#                padding: 20px;
#                max-width: 800px;
#                margin: 0 auto;
#            }}
            
#            .security-notice {{
#                position: fixed;
#                top: 10px;
#                left: 50%;
#                transform: translateX(-50%);
#                background: rgba(255, 0, 0, 0.9);
#                color: white;
#                padding: 8px 15px;
#                border-radius: 20px;
#                font-size: 12px;
#                z-index: 10000;
#                pointer-events: none;
#            }}
            
#            .pdf-controls {{
#                position: fixed;
#                top: 50px;
#                left: 50%;
#                transform: translateX(-50%);
#                background: rgba(0, 0, 0, 0.8);
#                padding: 8px 15px;
#                border-radius: 20px;
#                display: flex;
#                gap: 10px;
#                z-index: 1000;
#                pointer-events: auto;
#            }}
            
#            .pdf-control-btn {{
#                background: rgba(255, 255, 255, 0.9);
#                border: none;
#                width: 35px;
#                height: 35px;
#                border-radius: 50%;
#                cursor: pointer;
#                display: flex;
#                align-items: center;
#                justify-content: center;
#                transition: all 0.3s ease;
#                font-size: 14px;
#                color: #333;
#            }}
            
#            .pdf-control-btn:hover {{
#                background: white;
#                transform: scale(1.1);
#            }}
            
#            .zoom-level {{
#                background: rgba(255, 255, 255, 0.9);
#                border-radius: 15px;
#                padding: 5px 10px;
#                font-size: 12px;
#                color: #333;
#                min-width: 50px;
#                text-align: center;
#            }}
            
#            /* Secure PDF iframe that prevents direct access */
#            #secureFrame {{
#                width: 100%;
#                height: 80vh;
#                border: none;
#                outline: none;
#                border-radius: 10px;
#                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
#                -webkit-user-select: none !important;
#                -moz-user-select: none !important;
#                user-select: none !important;
#                -webkit-touch-callout: none !important;
#                pointer-events: auto;
#            }}
            
#            /* Anti-save protection */
#            @media print {{
#                body {{
#                    display: none !important;
#                }}
#            }}
            
#            /* Hide any download buttons */
#            a[download], 
#            button[onclick*="download"],
#            .download-btn,
#            .save-btn,
#            [href*=".pdf"] {{
#                display: none !important;
#                visibility: hidden !important;
#                opacity: 0 !important;
#            }}
#        </style>
#    </head>
#    <body oncontextmenu="return false;">
#        <div class="header">
#            <a href="/user-dashboard" class="back-button">← Dashboard</a>
#            <div class="book-info">
#                <div class="book-title">{ebook.name}</div>
#                <div class="book-author">by {ebook.author}</div>
#            </div>
#            <div class="security-badge">
#                🔒 Protected
#            </div>
#        </div>
        
#        <div class="pdf-container">
#            <iframe class="pdf-iframe" id="pdfFrame"
#                    src="/secure-pdf-data/{ebook_id}#toolbar=0&navpanes=0&scrollbar=1&view=FitH&zoom=page-width"
#                    frameborder="0"
#                    allowfullscreen
#                    oncontextmenu="return false;"
#                    style="border: none; background: white; width: 100%; height: 100%; border-radius: 8px;">
#            </iframe>
#        </div>
        
#        <!-- Floating Control Panel -->
#        <div class="control-panel">
#            <button class="control-btn" onclick="zoomOut()" title="Zoom Out">
#                <span style="font-size: 20px; line-height: 1;">−</span>
#            </button>
#            <div class="zoom-display" id="zoomDisplay">100%</div>
#            <button class="control-btn" onclick="zoomIn()" title="Zoom In">
#                <span style="font-size: 16px; line-height: 1;">+</span>
#            </button>
#            <button class="control-btn" onclick="resetZoom()" title="Reset Zoom">
#                <span style="font-size: 12px; line-height: 1;">⌂</span>
#            </button>
#            <button class="control-btn" onclick="toggleFullscreen()" title="Fullscreen" id="fullscreenBtn">
#                <span style="font-size: 14px; line-height: 1;">⛶</span>
#            </button>
#        </div>
        
#        <script>
#            let currentZoom = 1.0;
#            const zoomStep = 0.25;
#            const minZoom = 0.5;
#            const maxZoom = 3.0;
            
#            function updateZoomDisplay() {{
#                document.getElementById('zoomDisplay').textContent = Math.round(currentZoom * 100) + '%';
#            }}
            
#            function applyZoom() {{
#                const iframe = document.getElementById('pdfFrame');
#                iframe.style.transform = `scale(${{currentZoom}})`;
#                iframe.style.transformOrigin = 'center top';
                
#                // Adjust container height to accommodate zoom
#                const container = iframe.parentElement;
#                if (currentZoom > 1) {{
#                    container.style.overflowY = 'auto';
#                    iframe.style.height = `${{100 / currentZoom}}%`;
#                }} else {{
#                    container.style.overflowY = 'hidden';
#                    iframe.style.height = '100%';
#                }}
                
#                updateZoomDisplay();
#            }}
            
#            function zoomIn() {{
#                if (currentZoom < maxZoom) {{
#                    currentZoom = Math.min(currentZoom + zoomStep, maxZoom);
#                    applyZoom();
#                }}
#            }}
            
#            function zoomOut() {{
#                if (currentZoom > minZoom) {{
#                    currentZoom = Math.max(currentZoom - zoomStep, minZoom);
#                    applyZoom();
#                }}
#            }}
            
#            function resetZoom() {{
#                currentZoom = 1.0;
#                applyZoom();
#            }}
            
#            function toggleFullscreen() {{
#                const fullscreenBtn = document.getElementById('fullscreenBtn');
                
#                if (!document.fullscreenElement) {{
#                    document.documentElement.requestFullscreen().then(() => {{
#                        fullscreenBtn.innerHTML = '<span style="font-size: 14px; line-height: 1;">⛶</span>';
#                        fullscreenBtn.title = 'Exit Fullscreen';
#                    }}).catch(() => {{
#                        console.log('Fullscreen not supported');
#                    }});
#                }} else {{
#                    document.exitFullscreen().then(() => {{
#                        fullscreenBtn.innerHTML = '<span style="font-size: 14px; line-height: 1;">⛶</span>';
#                        fullscreenBtn.title = 'Fullscreen';
#                    }});
#                }}
#            }}
            
#            // Initialize zoom display
#            updateZoomDisplay();
            
#            // Block any external scripts or API calls
#            const originalFetch = window.fetch;
#            window.fetch = function(...args) {{
#                const url = args[0];
#                if (typeof url === 'string' && (url.includes('alert') || url.includes('notification'))) {{
#                    return Promise.reject('Blocked alert API');
#                }}
#                return originalFetch.apply(this, args);
#            }};
            
#            // Override alert functions
#            window.alert = function() {{ /* Silent */ }};
#            window.confirm = function() {{ return false; }};
#            window.prompt = function() {{ return null; }};
            
#            // Hide any alerts, toolbars, and unwanted elements
#            function hideAlerts() {{
#                // Hide alerts in main document
#                const mainAlerts = document.querySelectorAll('[role="alert"], .alert, .warning, .notification, .toast, .popup, .modal, .overlay, .banner, [class*="alert"], [class*="notification"], [class*="warning"], [class*="popup"], [class*="banner"]');
#                mainAlerts.forEach(element => {{
#                    element.style.display = 'none';
#                    element.style.visibility = 'hidden';
#                    element.style.opacity = '0';
#                    element.style.position = 'absolute';
#                    element.style.left = '-9999px';
#                    element.style.top = '-9999px';
#                    element.remove(); // Completely remove from DOM
#                }});
                
#                // Hide iframe alerts  
#                const iframe = document.getElementById('pdfFrame');
#                if (iframe && iframe.contentDocument) {{
#                    try {{
#                        // Hide any alert elements in iframe
#                        const iframeAlerts = iframe.contentDocument.querySelectorAll('[role="alert"], .alert, .warning, .notification, .toast, .popup, .modal, .overlay, .banner');
#                        iframeAlerts.forEach(alert => {{
#                            alert.style.display = 'none';
#                            alert.style.visibility = 'hidden';
#                            alert.remove();
#                        }});
                        
#                        // Hide PDF.js toolbar if present
#                        const toolbar = iframe.contentDocument.querySelector('#toolbarContainer, .toolbar, #secondaryToolbar');
#                        if (toolbar) {{
#                            toolbar.style.display = 'none';
#                            toolbar.remove();
#                        }}
                        
#                        // Hide any download buttons
#                        const downloadBtns = iframe.contentDocument.querySelectorAll('[title*="Download"], [title*="Save"], button[download]');
#                        downloadBtns.forEach(btn => {{
#                            btn.style.display = 'none';
#                            btn.remove();
#                        }});
                        
#                        // Hide any text containing "PROTECTED DOCUMENT"
#                        const allElements = iframe.contentDocument.querySelectorAll('*');
#                        allElements.forEach(el => {{
#                            if (el.textContent && el.textContent.includes('PROTECTED DOCUMENT')) {{
#                                el.style.display = 'none';
#                                el.remove();
#                            }}
#                        }});
#                    }} catch (e) {{
#                        // Cross-origin restrictions - ignore
#                    }}
#                }}
#            }}
            
#            // Immediate alert hiding on page load
#            document.addEventListener('DOMContentLoaded', function() {{
#                hideAlerts();
#                setTimeout(hideAlerts, 100);
#                setTimeout(hideAlerts, 500);
#            }});
            
#            // Monitor iframe loading
#            document.getElementById('pdfFrame').addEventListener('load', function() {{
#                setTimeout(hideAlerts, 100);
#                setTimeout(hideAlerts, 500);
#                setTimeout(hideAlerts, 1000);
#                setTimeout(hideAlerts, 2000);
#            }});
            
#            // Periodically hide alerts
#            setInterval(hideAlerts, 1000);
            
#            // Mutation observer to catch dynamically added alerts
#            const observer = new MutationObserver(function(mutations) {{
#                mutations.forEach(function(mutation) {{
#                    if (mutation.addedNodes.length > 0) {{
#                        setTimeout(hideAlerts, 50);
#                    }}
#                }});
#            }});
            
#            observer.observe(document.body, {{
#                childList: true,
#                subtree: true
#            }});
            
#            // Hide alerts immediately
#            hideAlerts();
            
#            // Keyboard shortcuts for zoom
#            document.addEventListener('keydown', function(e) {{
#                // Security shortcuts
#                if (e.ctrlKey && (e.key === 's' || e.key === 'p' || e.key === 'S' || e.key === 'P')) {{
#                    e.preventDefault();
#                    return false;
#                }}
#                if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && e.key === 'I')) {{
#                    e.preventDefault();
#                    return false;
#                }}
                
#                // Zoom shortcuts
#                if (e.ctrlKey && e.key === '=' || e.ctrlKey && e.key === '+') {{
#                    e.preventDefault();
#                    zoomIn();
#                }}
#                if (e.ctrlKey && e.key === '-') {{
#                    e.preventDefault();
#                    zoomOut();
#                }}
#                if (e.ctrlKey && e.key === '0') {{
#                    e.preventDefault();
#                    resetZoom();
#                }}
#            }});
            
#            // Block right click
#            document.addEventListener('contextmenu', function(e) {{
#                e.preventDefault();
#                return false;
#            }});
            
#            // Prevent text selection
#            document.addEventListener('selectstart', function(e) {{
#                e.preventDefault();
#                return false;
#            }});
#        </script>
#    </body>
#    </html>
#    """
    
#    # Return secure viewer with headers
#    response = make_response(secure_html)
#    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
#    response.headers['X-Content-Type-Options'] = 'nosniff'
#    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    
#    return response

@app.route('/protected-pdf-stream/<int:ebook_id>')
@login_required
def protected_pdf_stream(ebook_id):
    """Clean PDF viewer without alerts - PDF.js implementation"""
    user_id = session.get('user_id')
    
    # Verify user has access to this ebook
    purchase = EbookPurchase.query.filter_by(user_id=user_id, ebook_id=ebook_id).first()
    if not purchase:
        return "Access Denied", 403
    
    ebook = Ebook.query.get_or_404(ebook_id)
    
    # Create clean PDF viewer with PDF.js - NO ALERTS
    secure_viewer_html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
        <title>{ebook.name} - PDF Reader</title>
        <meta http-equiv="Content-Security-Policy" content="default-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; object-src 'none'; frame-src 'self';">
        <meta name="robots" content="noindex, nofollow, nosnippet, noarchive">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
        <style>
            * {{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }}
            body {{
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                background: #1a1a1a;
                height: 100vh;
                overflow: hidden;
                margin: 0;
                padding: 0;
            }}
            .header {{
                background: linear-gradient(135deg, #2563eb, #1d4ed8);
                color: white;
                padding: 12px 20px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                box-shadow: 0 2px 8px rgba(0,0,0,0.15);
                z-index: 1000;
                position: relative;
            }}
            .back-button {{
                background: rgba(255,255,255,0.15);
                color: white;
                padding: 8px 16px;
                border-radius: 8px;
                text-decoration: none;
                border: 1px solid rgba(255,255,255,0.2);
                cursor: pointer;
                font-size: 14px;
                font-weight: 500;
                transition: all 0.2s ease;
            }}
            .back-button:hover {{
                background: rgba(255,255,255,0.25);
                color: white;
                text-decoration: none;
                transform: translateY(-1px);
            }}
            .book-info {{
                flex: 1;
                text-align: center;
            }}
            .book-title {{
                font-size: 18px;
                font-weight: 600;
                margin-bottom: 2px;
            }}
            .book-author {{
                font-size: 14px;
                opacity: 0.9;
            }}
            .security-badge {{
                background: rgba(34,197,94,0.2);
                color: #dcfce7;
                padding: 6px 12px;
                border-radius: 15px;
                font-size: 12px;
                display: flex;
                align-items: center;
                gap: 5px;
                border: 1px solid rgba(34,197,94,0.3);
            }}
            .pdf-container {{
                height: calc(100vh - 56px);
                background: #2a2a2a;
                position: relative;
                padding: 20px;
                overflow-y: auto;
                display: flex;
                flex-direction: column;
                align-items: center;
            }}
            .page-container {{
                background: white;
                margin-bottom: 20px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.3);
                border-radius: 8px;
                overflow: hidden;
                position: relative;
            }}
            .page-canvas {{
                display: block;
                width: 100%;
                height: auto;
                pointer-events: none;
                user-select: none;
            }}
            .loading-container {{
                display: flex;
                justify-content: center;
                align-items: center;
                height: 200px;
                color: white;
                font-size: 18px;
            }}
            .loading-spinner {{
                border: 3px solid rgba(255,255,255,0.3);
                border-top: 3px solid #2563eb;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                animation: spin 1s linear infinite;
                margin-right: 15px;
            }}
            @keyframes spin {{
                0% {{ transform: rotate(0deg); }}
                100% {{ transform: rotate(360deg); }}
            }}
            .control-panel {{
                position: fixed;
                bottom: 30px;
                left: 50%;
                transform: translateX(-50%);
                background: rgba(0, 0, 0, 0.8);
                backdrop-filter: blur(10px);
                color: white;
                padding: 12px 20px;
                border-radius: 25px;
                display: flex;
                align-items: center;
                gap: 15px;
                z-index: 9999;
                border: 1px solid rgba(255, 255, 255, 0.1);
                max-width: 90%;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            }}
            .control-btn {{
                background: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(255, 255, 255, 0.2);
                color: white;
                padding: 8px 12px;
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.2s ease;
                font-size: 14px;
                min-width: 36px;
                text-align: center;
            }}
            .control-btn:hover {{
                background: rgba(255, 255, 255, 0.2);
                transform: translateY(-1px);
            }}
            .control-divider {{
                width: 1px;
                height: 20px;
                background: rgba(255, 255, 255, 0.3);
                margin: 0 5px;
            }}
            .zoom-display {{
                font-size: 12px;
                color: rgba(255, 255, 255, 0.8);
                min-width: 40px;
                text-align: center;
            }}
            .page-info {{
                font-size: 12px;
                color: rgba(255, 255, 255, 0.8);
                min-width: 60px;
                text-align: center;
            }}
            /* Mobile responsive */
            @media (max-width: 768px) {{
                .header {{
                    padding: 10px 15px;
                }}
                .book-title {{
                    font-size: 16px;
                }}
                .book-author {{
                    font-size: 12px;
                }}
                .control-panel {{
                    bottom: 20px;
                    padding: 10px 15px;
                    gap: 10px;
                }}
                .control-btn {{
                    padding: 6px 10px;
                    font-size: 12px;
                }}
                .pdf-container {{
                    padding: 10px;
                }}
            }}
            @media (max-width: 480px) {{
                .header {{
                    padding: 8px 10px;
                }}
                .book-title {{
                    font-size: 14px;
                }}
                .security-badge {{
                    display: none;
                }}
                .control-panel {{
                    width: calc(100% - 20px);
                    max-width: none;
                }}
            }}
        </style>
    </head>
    <body oncontextmenu="return false;">
        <div class="header">
            <a href="/user-dashboard" class="back-button">← Dashboard</a>
            <div class="book-info">
                <div class="book-title">{ebook.name}</div>
                <div class="book-author">by {ebook.author}</div>
            </div>
            <div class="security-badge">
                🔒 Protected
            </div>
        </div>
        
        <div class="pdf-container" id="pdfContainer">
            <div class="loading-container">
                <div class="loading-spinner"></div>
                Loading document...
            </div>
        </div>
        
        <!-- Floating Control Panel -->
        <div class="control-panel">
            <button class="control-btn" onclick="zoomOut()">
                −
            </button>
            <div class="zoom-display" id="zoomLevel">100%</div>
            <button class="control-btn" onclick="zoomIn()">
                +
            </button>
            <div class="control-divider"></div>
            <div class="page-info" id="pageInfo">0/0</div>
            <div class="control-divider"></div>
            <button class="control-btn" onclick="toggleFullscreen()">
                ⛶
            </button>
        </div>
        
        <script>
            // Disable right-click and keyboard shortcuts
            document.addEventListener('contextmenu', e => e.preventDefault());
            document.addEventListener('keydown', function(e) {{
                if (e.ctrlKey && (e.key === 's' || e.key === 'p' || e.key === 'u')) {{
                    e.preventDefault();
                }}
                if (e.key === 'F12') {{
                    e.preventDefault();
                }}
            }});
            
            // PDF.js setup
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
            
            let pdfDoc = null;
            let currentZoom = 1.0;
            let totalPages = 0;
            
            // Load and render PDF
            async function loadPDF() {{
                try {{
                    const response = await fetch('/secure-pdf-data/{ebook_id}');
                    const arrayBuffer = await response.arrayBuffer();
                    
                    pdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
                    totalPages = pdfDoc.numPages;
                    
                    updatePageInfo();
                    renderAllPages();
                    
                }} catch (error) {{
                    console.error('Error loading PDF:', error);
                    document.getElementById('pdfContainer').innerHTML = '<div class="loading-container" style="color: #ff6b6b;">Error loading document</div>';
                }}
            }}
            
            async function renderAllPages() {{
                const container = document.getElementById('pdfContainer');
                container.innerHTML = '';
                
                for (let pageNum = 1; pageNum <= totalPages; pageNum++) {{
                    const pageContainer = document.createElement('div');
                    pageContainer.className = 'page-container';
                    pageContainer.id = `page-${{pageNum}}`;
                    
                    const canvas = document.createElement('canvas');
                    canvas.className = 'page-canvas';
                    pageContainer.appendChild(canvas);
                    
                    container.appendChild(pageContainer);
                    
                    await renderPage(pageNum, canvas);
                }}
            }}
            
            async function renderPage(pageNum, canvas) {{
                try {{
                    const page = await pdfDoc.getPage(pageNum);
                    const viewport = page.getViewport({{ scale: currentZoom }});
                    
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;
                    
                    const renderContext = {{
                        canvasContext: canvas.getContext('2d'),
                        viewport: viewport
                    }};
                    
                    await page.render(renderContext).promise;
                    
                    // Block canvas operations to prevent saving
                    const originalToDataURL = canvas.toDataURL;
                    canvas.toDataURL = function() {{
                        return 'data:,';
                    }};
                    
                }} catch (error) {{
                    console.error(`Error rendering page ${{pageNum}}:`, error);
                }}
            }}
            
            function updatePageInfo() {{
                document.getElementById('pageInfo').textContent = `${{totalPages}} pages`;
            }}
            
            function zoomIn() {{
                if (currentZoom < 2.0) {{
                    currentZoom += 0.25;
                    updateZoom();
                }}
            }}
            
            function zoomOut() {{
                if (currentZoom > 0.5) {{
                    currentZoom -= 0.25;
                    updateZoom();
                }}
            }}
            
            function updateZoom() {{
                document.getElementById('zoomLevel').textContent = Math.round(currentZoom * 100) + '%';
                renderAllPages();
            }}
            
            function toggleFullscreen() {{
                if (document.fullscreenElement) {{
                    document.exitFullscreen();
                }} else {{
                    document.documentElement.requestFullscreen();
                }}
            }}
            
            // Load PDF when page is ready
            document.addEventListener('DOMContentLoaded', loadPDF);
        </script>
    </body>
    </html>
    """
    
    # Return secure viewer with headers
    response = make_response(secure_viewer_html)
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    
    return response

@app.route('/secure-pdf-data/<int:ebook_id>')
@login_required  
def secure_pdf_data(ebook_id):
    """Serve PDF data with enhanced security headers - direct PDF access blocked"""
    return "Direct PDF access not allowed", 403

@app.route('/test-ebook-debug/<int:ebook_id>')
@login_required  
def test_ebook_debug(ebook_id):
    """Debug endpoint to check ebook data"""
    user_id = session.get('user_id')
    
    # Check purchase
    purchase = EbookPurchase.query.filter_by(user_id=user_id, ebook_id=ebook_id).first()
    if not purchase:
        return f"No purchase found for user {user_id} and ebook {ebook_id}", 403
    
    # Get ebook
    ebook = Ebook.query.get_or_404(ebook_id)
    
    debug_info = {
        'ebook_id': ebook.id,
        'ebook_name': ebook.name,
        'has_pdf_url': bool(ebook.pdf_url),
        'pdf_url': ebook.pdf_url if ebook.pdf_url else 'None',
        'has_pdf_file': bool(ebook.pdf_file),
        'pdf_file': ebook.pdf_file if ebook.pdf_file else 'None',
        'user_id': user_id,
        'purchase_exists': bool(purchase)
    }
    
    # Check file existence if local file
    if ebook.pdf_file:
        pdf_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', 'ebooks', ebook.pdf_file)
        debug_info['pdf_file_path'] = pdf_path
        debug_info['pdf_file_exists'] = os.path.exists(pdf_path)
        if os.path.exists(pdf_path):
            debug_info['pdf_file_size'] = os.path.getsize(pdf_path)
    
    return f'''
    <h2>Ebook Debug Information</h2>
    <pre>{json.dumps(debug_info, indent=2)}</pre>
    <hr>
    <h3>Available Viewers:</h3>
    <a href="/image-pdf-viewer/{ebook_id}">🖼️ Image-Based PDF Viewer (RECOMMENDED - Maximum Security)</a><br><br>
    <a href="/simple-pdf-viewer/{ebook_id}">📄 Simple PDF Viewer (Chrome-friendly)</a><br>
    <a href="/ebook/{ebook_id}/read">📖 Ebook Reader (iframe version)</a><br>
    <a href="/secure-pdf-viewer/{ebook_id}">🔒 Secure PDF Viewer (base64 version)</a><br>
    <a href="/test-direct-pdf/{ebook_id}">🔧 Test Direct PDF (for debugging only)</a><br>
    <hr>
    <h3>Test Individual Page as Image:</h3>
    <a href="/pdf-page-stream/{ebook_id}/1">View Page 1 as Image</a><br>
    <a href="/pdf-page-stream/{ebook_id}/2">View Page 2 as Image</a><br>
    '''

@app.route('/test-direct-pdf/<int:ebook_id>')
@login_required  
def test_direct_pdf(ebook_id):
    """Test direct PDF serving for debugging"""
    user_id = session.get('user_id')
    
    # Check purchase
    purchase = EbookPurchase.query.filter_by(user_id=user_id, ebook_id=ebook_id).first()
    if not purchase:
        return "No purchase found", 403
    
    ebook = Ebook.query.get_or_404(ebook_id)
    
    # Serve PDF directly for testing
    if ebook.pdf_url:
        import requests
        try:
            response = requests.get(ebook.pdf_url, timeout=30)
            if response.status_code == 200:
                pdf_response = Response(response.content, mimetype='application/pdf')
                pdf_response.headers['Content-Disposition'] = 'inline; filename="test.pdf"'
                pdf_response.headers['X-Frame-Options'] = 'SAMEORIGIN'
                pdf_response.headers['Content-Security-Policy'] = "frame-ancestors 'self'"
                return pdf_response
            else:
                return f"PDF URL returned status: {response.status_code}", 404
        except Exception as e:
            return f"Error loading PDF: {str(e)}", 500
    elif ebook.pdf_file:
        pdf_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', 'ebooks', ebook.pdf_file)
        if os.path.exists(pdf_path):
            with open(pdf_path, 'rb') as f:
                pdf_response = Response(f.read(), mimetype='application/pdf')
                pdf_response.headers['Content-Disposition'] = 'inline; filename="test.pdf"'
                pdf_response.headers['X-Frame-Options'] = 'SAMEORIGIN'
                pdf_response.headers['Content-Security-Policy'] = "frame-ancestors 'self'"
                return pdf_response
        else:
            return f"PDF file not found: {pdf_path}", 404
    else:
        return "No PDF available", 404

@app.route('/simple-pdf-viewer/<int:ebook_id>')
@login_required  
def simple_pdf_viewer(ebook_id):
    """Simple PDF viewer that works with Chrome"""
    user_id = session.get('user_id')
    
    # Check purchase
    purchase = EbookPurchase.query.filter_by(user_id=user_id, ebook_id=ebook_id).first()
    if not purchase:
        return "Access Denied", 403
    
    ebook = Ebook.query.get_or_404(ebook_id)
    
    # Create simple HTML viewer
    viewer_html = f'''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{ebook.name} - PDF Viewer</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
        }}
        
        body {{
            background: #2c3e50;
            font-family: Arial, sans-serif;
            overflow: hidden;
        }}
        
        .header {{
            background: #34495e;
            color: white;
            padding: 15px 20px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }}
        
        .pdf-container {{
            width: 100vw;
            height: calc(100vh - 60px);
            background: white;
            position: relative;
        }}
        
        .pdf-embed {{
            width: 100%;
            height: 100%;
            border: none;
        }}
        
        .back-btn {{
            position: fixed;
            top: 20px;
            left: 20px;
            background: #00a651;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            z-index: 1000;
        }}
        
        .back-btn:hover {{
            background: #008a44;
        }}
    </style>
</head>
<body>
    <a href="/user/dashboard#ebooks" class="back-btn">← Back to Library</a>
    
    <div class="header">
        <h2><i class="fas fa-book"></i> {ebook.name}</h2>
    </div>
    
    <div class="pdf-container">
        <embed class="pdf-embed" 
               src="/test-direct-pdf/{ebook_id}" 
               type="application/pdf">
        <p style="padding: 40px; text-align: center; color: #666;">
            Your browser does not support PDF viewing. 
            <a href="/test-direct-pdf/{ebook_id}" target="_blank">Click here to download the PDF</a>
        </p>
    </div>
    
    <script>
        // Basic right-click protection
        document.addEventListener('contextmenu', function(e) {{
            e.preventDefault();
            return false;
        }});
        
        // Block common keyboard shortcuts
        document.addEventListener('keydown', function(e) {{
            if ((e.ctrlKey && ['s', 'p', 'a', 'c'].includes(e.key.toLowerCase())) || e.key === 'F12') {{
                e.preventDefault();
                return false;
            }}
        }});
    </script>
</body>
</html>
    '''
    
    response = make_response(viewer_html)
    response.headers['Content-Type'] = 'text/html; charset=utf-8'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    
    return response

@app.route('/pdf-page-stream/<int:ebook_id>/<int:page>')
@login_required
def pdf_page_stream(ebook_id, page):
    """Stream individual PDF pages as images"""
    user_id = session.get('user_id')
    print(f"PDF route called: ebook_id={ebook_id}, page={page}, user_id={user_id}")
    
    # Verify access
    purchase = EbookPurchase.query.filter_by(user_id=user_id, ebook_id=ebook_id).first()
    if not purchase:
        print(f"Access denied for user {user_id} to ebook {ebook_id}")
        return "Access Denied", 403
    
    ebook = Ebook.query.get_or_404(ebook_id)
    print(f"Ebook found: {ebook.name}, PDF URL: {ebook.pdf_url}")
    
    try:
        from pdf2image import convert_from_bytes
        import io
        from PIL import Image
        import tempfile
        
        # Get PDF content
        pdf_content = None
        if ebook.pdf_url:
            import requests
            response = requests.get(ebook.pdf_url, timeout=30)
            if response.status_code == 200:
                pdf_content = response.content
            else:
                return f"PDF not found (HTTP {response.status_code})", 404
        elif ebook.pdf_file:
            pdf_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', 'ebooks', ebook.pdf_file)
            if os.path.exists(pdf_path):
                with open(pdf_path, 'rb') as f:
                    pdf_content = f.read()
            else:
                return "PDF file not found", 404
        else:
            return "No PDF available", 404
        
        if not pdf_content:
            return "Failed to load PDF content", 500
        
        # Convert PDF to images
        images = convert_from_bytes(pdf_content, dpi=200, first_page=page, last_page=page)
        
        if not images:
            return f"Page {page} not found or could not be converted", 404
        
        # Get the first (and only) image
        img = images[0]
        
        # Convert to PNG bytes
        img_io = io.BytesIO()
        img.save(img_io, 'PNG', optimize=True)
        img_data = img_io.getvalue()
        
        # Create response
        response = Response(img_data, mimetype='image/png')
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, private'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        response.headers['X-Robots-Tag'] = 'noindex, nofollow'
        
        return response
        
    except ImportError:
        return "pdf2image not installed. Please install: pip install pdf2image", 500
    except Exception as e:
        print(f"Error converting PDF page to image: {str(e)}")
        return f"Error processing page: {str(e)}", 500

@app.route('/image-pdf-viewer/<int:ebook_id>')
@login_required
def image_pdf_viewer(ebook_id):
    """PDF viewer that streams pages as images"""
    user_id = session.get('user_id')
    
    # Verify access
    purchase = EbookPurchase.query.filter_by(user_id=user_id, ebook_id=ebook_id).first()
    if not purchase:
        return "Access Denied", 403
    
    ebook = Ebook.query.get_or_404(ebook_id)
    
    # Get total pages using pdf2image
    total_pages = 1
    try:
        from pdf2image import convert_from_bytes
        
        # Get PDF content to count pages
        pdf_content = None
        if ebook.pdf_url:
            import requests
            response = requests.get(ebook.pdf_url, timeout=30)
            if response.status_code == 200:
                pdf_content = response.content
        elif ebook.pdf_file:
            pdf_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', 'ebooks', ebook.pdf_file)
            if os.path.exists(pdf_path):
                with open(pdf_path, 'rb') as f:
                    pdf_content = f.read()
        
        if pdf_content:
            # Convert first few pages to get count (more efficient than converting all)
            images = convert_from_bytes(pdf_content, dpi=72, first_page=1, last_page=50)  # Test first 50 pages
            if len(images) == 50:
                # If we got 50 pages, there might be more - try a higher range
                try:
                    more_images = convert_from_bytes(pdf_content, dpi=72, first_page=51, last_page=200)
                    total_pages = 50 + len(more_images)
                except:
                    total_pages = 50
            else:
                total_pages = len(images)
            
    except Exception as e:
        print(f"Error getting page count: {str(e)}")
    
    # Create image-based PDF viewer
    viewer_html = f'''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{ebook.name} - Secure Reader</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-touch-callout: none;
        }}
        
        body {{
            background: #2c3e50;
            font-family: Arial, sans-serif;
            overflow-x: hidden;
        }}
        
        .header {{
            background: #34495e;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            position: sticky;
            top: 0;
            z-index: 1000;
        }}
        
        .header h2 {{
            margin: 0;
            font-size: 1.2rem;
        }}
        
        .nav-controls {{
            display: flex;
            gap: 10px;
            align-items: center;
        }}
        
        .nav-btn {{
            background: #00a651;
            border: none;
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background 0.3s;
        }}
        
        .nav-btn:hover:not(:disabled) {{
            background: #008a44;
        }}
        
        .nav-btn:disabled {{
            background: #555;
            cursor: not-allowed;
            opacity: 0.6;
        }}
        
        .page-info {{
            background: #2c3e50;
            padding: 8px 16px;
            border-radius: 5px;
            font-size: 0.9rem;
            min-width: 120px;
            text-align: center;
        }}
        
        .page-input {{
            background: #2c3e50;
            border: 1px solid #555;
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            width: 60px;
            text-align: center;
            font-size: 0.9rem;
        }}
        
        .reader-container {{
            min-height: calc(100vh - 80px);
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 20px;
            background: #ecf0f1;
        }}
        
        .page-container {{
            background: white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            border-radius: 10px;
            overflow: hidden;
            position: relative;
            max-width: 900px;
            width: 100%;
        }}
        
        .page-image {{
            width: 100%;
            height: auto;
            display: block;
            pointer-events: none;
            -webkit-user-drag: none;
            -khtml-user-drag: none;
            -moz-user-drag: none;
            -o-user-drag: none;
            user-drag: none;
        }}
        
        .loading {{
            text-align: center;
            padding: 100px 20px;
            color: #7f8c8d;
        }}
        
        .spinner {{
            width: 50px;
            height: 50px;
            border: 4px solid #bdc3c7;
            border-top: 4px solid #00a651;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }}
        
        @keyframes spin {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}
        
        .error {{
            text-align: center;
            padding: 50px 20px;
            color: #e74c3c;
            background: #fff5f5;
            border: 2px dashed #e74c3c;
            border-radius: 10px;
            margin: 20px;
        }}
        
        .back-btn {{
            background: #e74c3c;
            text-decoration: none;
        }}
        
        .back-btn:hover {{
            background: #c0392b;
        }}
        
        /* Security overlay */
        .security-overlay {{
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(231, 76, 60, 0.9);
            color: white;
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            text-align: center;
            font-size: 1.2rem;
        }}
        
        .security-overlay.show {{
            display: flex;
        }}
        
        /* Mobile responsive */
        @media (max-width: 768px) {{
            .header {{
                flex-direction: column;
                gap: 10px;
                padding: 10px;
            }}
            
            .nav-controls {{
                flex-wrap: wrap;
                justify-content: center;
            }}
            
            .reader-container {{
                padding: 10px;
            }}
        }}
    </style>
</head>
<body>
    <!-- Security overlay -->
    <div class="security-overlay" id="securityOverlay">
        <div>
            <h3>🛡️ Content Protected</h3>
            <p>This content is protected and cannot be copied or saved.</p>
        </div>
    </div>
    
    <!-- Header -->
    <div class="header">
        <h2>📖 {ebook.name}</h2>
        <div class="nav-controls">
            <button class="nav-btn" id="firstBtn" onclick="goToPage(1)">⏮️ First</button>
            <button class="nav-btn" id="prevBtn" onclick="previousPage()">⬅️ Prev</button>
            
            <div class="page-info">
                Page <input type="number" class="page-input" id="pageInput" value="1" min="1" max="{total_pages}" onchange="goToInputPage()"> 
                of {total_pages}
            </div>
            
            <button class="nav-btn" id="nextBtn" onclick="nextPage()">Next ➡️</button>
            <button class="nav-btn" id="lastBtn" onclick="goToPage({total_pages})">Last ⏭️</button>
            
            <a href="/user/dashboard#ebooks" class="nav-btn back-btn">❌ Exit</a>
        </div>
    </div>
    
    <!-- Reader -->
    <div class="reader-container">
        <div class="page-container" id="pageContainer">
            <div class="loading" id="loadingDiv">
                <div class="spinner"></div>
                <h3>Loading page...</h3>
                <p>Please wait while we prepare your reading experience</p>
            </div>
            
            <img class="page-image" id="pageImage" style="display: none;" alt="PDF Page">
            
            <div class="error" id="errorDiv" style="display: none;">
                <h3>⚠️ Error Loading Page</h3>
                <p id="errorMessage">Failed to load page content</p>
                <button class="nav-btn" onclick="retryCurrentPage()">🔄 Retry</button>
            </div>
        </div>
    </div>
    
    <script>
        let currentPage = 1;
        const totalPages = {total_pages};
        const ebookId = {ebook_id};
        
        // Security measures
        document.addEventListener('contextmenu', function(e) {{
            e.preventDefault();
            showSecurityMessage();
            return false;
        }});
        
        document.addEventListener('keydown', function(e) {{
            // Block save, print, copy shortcuts
            if ((e.ctrlKey && ['s', 'p', 'a', 'c', 'u'].includes(e.key.toLowerCase())) || 
                e.key === 'F12' || 
                (e.ctrlKey && e.shiftKey && ['i', 'j', 'c'].includes(e.key.toLowerCase()))) {{
                e.preventDefault();
                showSecurityMessage();
                return false;
            }}
            
            // Navigation shortcuts
            if (e.key === 'ArrowRight' || e.key === 'PageDown') {{
                e.preventDefault();
                nextPage();
            }} else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {{
                e.preventDefault();
                previousPage();
            }}
        }});
        
        document.addEventListener('selectstart', function(e) {{
            e.preventDefault();
            return false;
        }});
        
        document.addEventListener('dragstart', function(e) {{
            e.preventDefault();
            return false;
        }});
        
        function showSecurityMessage() {{
            const overlay = document.getElementById('securityOverlay');
            overlay.classList.add('show');
            setTimeout(() => {{
                overlay.classList.remove('show');
            }}, 2000);
        }}
        
        function loadPage(page) {{
            if (page < 1 || page > totalPages) return;
            
            currentPage = page;
            updateControls();
            
            const loadingDiv = document.getElementById('loadingDiv');
            const pageImage = document.getElementById('pageImage');
            const errorDiv = document.getElementById('errorDiv');
            
            // Show loading
            loadingDiv.style.display = 'block';
            pageImage.style.display = 'none';
            errorDiv.style.display = 'none';
            
            // Load page image
            const imageUrl = `/pdf-page-stream/${{ebookId}}/${{page}}?t=${{Date.now()}}`;
            
            pageImage.onload = function() {{
                loadingDiv.style.display = 'none';
                pageImage.style.display = 'block';
                errorDiv.style.display = 'none';
            }};
            
            pageImage.onerror = function() {{
                loadingDiv.style.display = 'none';
                pageImage.style.display = 'none';
                errorDiv.style.display = 'block';
                document.getElementById('errorMessage').textContent = `Failed to load page ${{page}}`;
            }};
            
            pageImage.src = imageUrl;
        }}
        
        function updateControls() {{
            document.getElementById('pageInput').value = currentPage;
            document.getElementById('firstBtn').disabled = currentPage <= 1;
            document.getElementById('prevBtn').disabled = currentPage <= 1;
            document.getElementById('nextBtn').disabled = currentPage >= totalPages;
            document.getElementById('lastBtn').disabled = currentPage >= totalPages;
        }}
        
        function nextPage() {{
            if (currentPage < totalPages) {{
                loadPage(currentPage + 1);
            }}
        }}
        
        function previousPage() {{
            if (currentPage > 1) {{
                loadPage(currentPage - 1);
            }}
        }}
        
        function goToPage(page) {{
            loadPage(page);
        }}
        
        function goToInputPage() {{
            const page = parseInt(document.getElementById('pageInput').value);
            if (page >= 1 && page <= totalPages) {{
                loadPage(page);
            }} else {{
                document.getElementById('pageInput').value = currentPage;
            }}
        }}
        
        function retryCurrentPage() {{
            loadPage(currentPage);
        }}
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {{
            loadPage(1);
        }});
        
        // Prevent back button
        history.pushState(null, null, location.href);
        window.onpopstate = function () {{
            history.go(1);
        }};
    </script>
</body>
</html>
    '''
    
    response = make_response(viewer_html)
    response.headers['Content-Type'] = 'text/html; charset=utf-8'
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    
    return response

@app.route('/secure-pdf-viewer/<int:ebook_id>')
@login_required  
def secure_pdf_viewer(ebook_id):
    """Serve secure PDF viewer that prevents direct downloads"""
    user_id = session.get('user_id')
    
    # Verify user has access
    purchase = EbookPurchase.query.filter_by(user_id=user_id, ebook_id=ebook_id).first()
    if not purchase:
        return "Access Denied", 403
    
    ebook = Ebook.query.get_or_404(ebook_id)
    
    # Get PDF content and convert to base64
    pdf_content = None
    pdf_source = None
    
    if ebook.pdf_url:
        import requests
        try:
            print(f"Loading PDF from URL: {ebook.pdf_url}")
            response = requests.get(ebook.pdf_url, timeout=30)
            if response.status_code == 200:
                import base64
                pdf_content = base64.b64encode(response.content).decode('utf-8')
                pdf_source = f"URL: {ebook.pdf_url}"
                print(f"PDF loaded from URL, size: {len(response.content)} bytes, base64 length: {len(pdf_content)}")
            else:
                print(f"PDF URL returned status: {response.status_code}")
                return f"PDF not found (HTTP {response.status_code})", 404
        except Exception as e:
            print(f"Error loading PDF from URL: {str(e)}")
            return f"Error loading PDF: {str(e)}", 500
    elif ebook.pdf_file:
        # Local file
        pdf_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', 'ebooks', ebook.pdf_file)
        print(f"Loading PDF from file: {pdf_path}")
        if os.path.exists(pdf_path):
            import base64
            with open(pdf_path, 'rb') as f:
                file_content = f.read()
                pdf_content = base64.b64encode(file_content).decode('utf-8')
                pdf_source = f"File: {pdf_path}"
                print(f"PDF loaded from file, size: {len(file_content)} bytes, base64 length: {len(pdf_content)}")
        else:
            print(f"PDF file does not exist: {pdf_path}")
            return f"PDF file not found: {pdf_path}", 404
    else:
        print("No PDF URL or file specified for ebook")
        return "No PDF available", 404
    
    if not pdf_content:
        print("PDF content is empty after processing")
        return "Failed to load PDF - empty content", 500
        
    print(f"PDF successfully processed from {pdf_source}")
    print(f"First 100 chars of base64: {pdf_content[:100]}...")
    
    # Create secure HTML PDF viewer
    viewer_html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure PDF Viewer</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-touch-callout: none;
        }}
        
        body {{
            background: #2c3e50;
            overflow: hidden;
            font-family: Arial, sans-serif;
        }}
        
        #pdfContainer {{
            width: 100vw;
            height: 100vh;
            position: relative;
            background: #34495e;
        }}
        
        #pdfEmbed {{
            width: 100%;
            height: 100%;
            border: none;
            background: white;
        }}
        
        #pdfObject {{
            width: 100%;
            height: 100%;
            border: none;
            background: white;
        }}
        
        .security-overlay {{
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 999999;
            background: transparent;
            pointer-events: none;
        }}
        
        .loading {{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 18px;
            z-index: 1000000;
        }}
        
        /* Hide any PDF controls that might appear */
        embed[type="application/pdf"] {{
            pointer-events: none !important;
        }}
        
        object[type="application/pdf"] {{
            pointer-events: none !important;
        }}
    </style>
</head>
<body>
    <div id="pdfContainer">
        <div class="loading" id="loadingText">Loading secure PDF...</div>
        <object id="pdfObject" type="application/pdf" style="display: none;">
            <embed id="pdfEmbed" type="application/pdf" style="width: 100%; height: 100%;">
            <p>Your browser does not support PDF viewing. Please contact support.</p>
        </object>
        <div class="security-overlay" id="securityOverlay"></div>
    </div>
    
    <script>
        // Block all right-click attempts
        document.addEventListener('contextmenu', function(e) {{
            e.preventDefault();
            e.stopPropagation();
            return false;
        }}, true);
        
        // Block all keyboard shortcuts
        document.addEventListener('keydown', function(e) {{
            // Block Ctrl+S, Ctrl+P, Ctrl+A, Ctrl+C, F12, etc.
            if ((e.ctrlKey && ['s', 'p', 'a', 'c', 'u', 'r'].includes(e.key.toLowerCase())) || 
                e.key === 'F12' || 
                (e.ctrlKey && e.shiftKey && ['i', 'j', 'c'].includes(e.key.toLowerCase()))) {{
                e.preventDefault();
                e.stopPropagation();
                return false;
            }}
        }}, true);
        
        // Advanced protection against devtools (disabled for better UX)
        function protectFromDevtools() {{
            // Disabled aggressive devtools detection to prevent false positives
            // Users with different browser configurations were getting blocked
            console.log('DevTools protection initialized but disabled for better user experience');
        }}
        
        // Load PDF with enhanced security - multiple fallback methods
        function loadSecurePDF() {{
            try {{
                const pdfData = "data:application/pdf;base64,{pdf_content}";
                const embed = document.getElementById('pdfEmbed');
                const object = document.getElementById('pdfObject');
                
                console.log('Loading PDF data, size:', pdfData.length);
                
                // Check if PDF data is valid
                if (!pdfData || pdfData === "data:application/pdf;base64,") {{
                    throw new Error('No PDF content available');
                }}
                
                // Method 1: Try object element first (more reliable)
                object.data = pdfData;
                object.style.display = 'block';
                
                // Method 2: Also set embed as fallback
                embed.src = pdfData;
                
                document.getElementById('loadingText').style.display = 'none';
                
                // Add error handling
                let loadTimeout = setTimeout(function() {{
                    console.warn('PDF load timeout - trying alternative method');
                    // Fallback: try iframe instead
                    tryIframeMethod(pdfData);
                }}, 5000);
                
                // Success handler
                function onPDFLoadSuccess() {{
                    clearTimeout(loadTimeout);
                    console.log('PDF loaded successfully');
                    document.getElementById('loadingText').style.display = 'none';
                    object.style.display = 'block';
                    setupSecurity();
                }}
                
                // Error handler
                function onPDFLoadError() {{
                    clearTimeout(loadTimeout);
                    console.error('PDF load failed - trying iframe fallback');
                    tryIframeMethod(pdfData);
                }}
                
                // Try to detect successful load
                setTimeout(function() {{
                    // Check if object has loaded content
                    try {{
                        if (object.contentDocument || (object.offsetHeight > 100)) {{
                            onPDFLoadSuccess();
                        }} else {{
                            onPDFLoadError();
                        }}
                    }} catch (e) {{
                        // Cross-origin restrictions mean it's probably loaded
                        onPDFLoadSuccess();
                    }}
                }}, 2000);
                
            }} catch (error) {{
                console.error('PDF loading error:', error);
                document.getElementById('loadingText').textContent = 'Failed to load PDF: ' + error.message;
                document.getElementById('loadingText').style.display = 'block';
            }}
        }}
        
        // Fallback iframe method
        function tryIframeMethod(pdfData) {{
            console.log('Trying iframe fallback method');
            const container = document.getElementById('pdfContainer');
            
            // Remove object and create iframe
            const object = document.getElementById('pdfObject');
            if (object) object.style.display = 'none';
            
            const iframe = document.createElement('iframe');
            iframe.src = pdfData;
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            iframe.style.border = 'none';
            iframe.style.background = 'white';
            iframe.onload = function() {{
                console.log('PDF loaded via iframe');
                document.getElementById('loadingText').style.display = 'none';
                setupSecurity();
            }};
            iframe.onerror = function() {{
                console.error('Iframe method also failed');
                document.getElementById('loadingText').textContent = 'Unable to display PDF in this browser';
            }};
            
            container.appendChild(iframe);
        }}
        
        // Setup security overlay
        function setupSecurity() {{
            const overlay = document.getElementById('securityOverlay');
            
            // Smart overlay management for scrolling
            overlay.addEventListener('wheel', function(e) {{
                // Allow scroll but block right-clicks
                overlay.style.pointerEvents = 'none';
                setTimeout(() => {{
                    overlay.style.pointerEvents = 'auto';
                }}, 100);
            }}, {{ passive: true }});
            
            overlay.addEventListener('mousedown', function(e) {{
                if (e.button === 2) {{
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                }}
                // Allow other interactions but re-enable protection quickly
                overlay.style.pointerEvents = 'none';
                setTimeout(() => {{
                    overlay.style.pointerEvents = 'auto';
                }}, 50);
            }}, true);
            
            overlay.style.pointerEvents = 'auto';
        }}
        
        // Initialize everything
        document.addEventListener('DOMContentLoaded', function() {{
            protectFromDevtools();
            setTimeout(loadSecurePDF, 500);
        }});
        
        // Prevent print
        window.addEventListener('beforeprint', function(e) {{
            e.preventDefault();
            return false;
        }});
        
        // Block selection
        document.addEventListener('selectstart', function(e) {{
            e.preventDefault();
            return false;
        }});
        
        // Block drag
        document.addEventListener('dragstart', function(e) {{
            e.preventDefault();
            return false;
        }});
    </script>
</body>
</html>'''
    
    # Create response with security headers
    response = make_response(viewer_html)
    response.headers['Content-Type'] = 'text/html; charset=utf-8'
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, private, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    response.headers['X-Robots-Tag'] = 'noindex, nofollow, nosnippet, noarchive, noimageindex'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['Content-Security-Policy'] = "default-src 'self' 'unsafe-inline' data:; frame-ancestors 'self'; object-src 'self' data:"
    
    return response


@app.route('/api/report-download-attempt', methods=['POST'])
@login_required
def report_download_attempt():
    """Report attempted downloads for monitoring"""
    try:
        user_id = session.get('user_id')
        data = request.get_json()
        
        # Log the attempt (in a real system, you'd save this to database)
        print(f"⚠️ VIDEO DOWNLOAD ATTEMPT DETECTED: User {user_id}, Course: {data.get('course_id')}, Video: {data.get('video_id')}, Time: {data.get('timestamp')}")
        
        # You could implement account warnings/suspensions here
        # For now, just log and return success
        
        return jsonify({'success': True, 'message': 'Attempt logged'})
        
    except Exception as e:
        print(f"Error logging download attempt: {e}")
        return jsonify({'success': False, 'message': 'Failed to log attempt'})

@app.route('/api/security-log', methods=['POST'])
@login_required  
def log_security_event():
    """Enhanced security event logging endpoint"""
    try:
        user_id = session.get('user_id')
        data = request.get_json()
        
        # Log security event with comprehensive details
        event_info = {
            'user_id': user_id,
            'event_type': data.get('event_type', 'unknown'),
            'ebook_id': data.get('ebook_id'),
            'ebook_name': data.get('ebook_name'),
            'pdf_source': data.get('pdf_source'),
            'timestamp': data.get('timestamp'),
            'user_agent': data.get('user_agent'),
            'page_url': data.get('page_url'),
            'screen_resolution': data.get('screen_resolution'),
            'viewport_size': data.get('viewport_size'),
            'reading_time': data.get('reading_time'),
            'additional_data': data.get('additional_data', {})
        }
        
        # In a production system, you would save this to a security_logs table
        print(f"🔒 SECURITY EVENT LOGGED: {event_info['event_type']}")
        print(f"   User: {user_id}")
        print(f"   eBook: {event_info['ebook_name']} (ID: {event_info['ebook_id']})")
        print(f"   Details: {event_info}")
        
        return jsonify({'success': True, 'message': 'Security event logged'})
        
    except Exception as e:
        print(f"Error logging security event: {e}")
        return jsonify({'success': False, 'message': 'Failed to log security event'})

@app.route('/api/report-ebook-download-attempt', methods=['POST'])
@login_required
def report_ebook_download_attempt():
    """Report attempted ebook downloads for monitoring"""
    try:
        user_id = session.get('user_id')
        data = request.get_json()
        
        # Log the attempt (in a real system, you'd save this to database)
        print(f"⚠️ EBOOK DOWNLOAD ATTEMPT DETECTED: User {user_id}, eBook: {data.get('ebook_id')}, Time: {data.get('timestamp')}, User Agent: {data.get('user_agent')}")
        
        # You could implement account warnings/suspensions here
        # For now, just log and return success
        
        return jsonify({'success': True, 'message': 'eBook download attempt logged'})
        
    except Exception as e:
        print(f"Error logging ebook download attempt: {e}")
        return jsonify({'success': False, 'message': 'Failed to log attempt'})

@app.route('/about')
def about():
    # Get about page content for all sections
    main_about_content = AboutPageContent.get_main_about_content()
    mission_content = AboutPageContent.get_mission_content()
    team_content = AboutPageContent.get_team_content()
    
    # Use defaults if no content exists for each section
    if not main_about_content:
        main_about_data = AboutPageContent.get_default_main_about_content()
    else:
        main_about_data = {
            'main_about_title': main_about_content.main_about_title,
            'main_about_subtitle': main_about_content.main_about_subtitle,
            'main_about_content': main_about_content.main_about_content,
            'main_about_images': main_about_content.main_about_images,
            'main_about_features': main_about_content.main_about_features
        }
    
    if not mission_content:
        mission_data = AboutPageContent.get_default_mission_content()
    else:
        mission_data = {
            'mission_title': mission_content.mission_title,
            'mission_content': mission_content.mission_content,
            'mission_vision_title': mission_content.mission_vision_title,
            'mission_vision_content': mission_content.mission_vision_content,
            'mission_points': mission_content.mission_points,
            'vision_points': mission_content.vision_points
        }
    
    if not team_content:
        team_data = AboutPageContent.get_default_team_content()
    else:
        team_data = {
            'team_title': team_content.team_title,
            'team_subtitle': team_content.team_subtitle,
            'team_members': team_content.team_members
        }
    
    return render_template('about.html', 
                         main_about_data=main_about_data,
                         mission_data=mission_data,
                         team_data=team_data,
                         now=datetime.utcnow())

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    """Handle contact form submission and display contact page"""
    if request.method == 'POST':
        try:
            # Verify Cloudflare Turnstile
            turnstile_response = request.form.get('cf-turnstile-response')
            if not verify_turnstile(turnstile_response, request.remote_addr):
                flash('Security check failed. Please try again.', 'error')
                return render_template('contact.html', now=datetime.utcnow())
            
            # Get form data
            first_name = request.form.get('first_name', '').strip()
            last_name = request.form.get('last_name', '').strip()
            email = request.form.get('email', '').strip()
            subject = request.form.get('subject', '').strip()
            message = request.form.get('message', '').strip()
            
            # Validate form data
            if not all([first_name, last_name, email, subject, message]):
                flash('All fields are required. Please fill out the complete form.', 'error')
                return render_template('contact.html', now=datetime.utcnow())
            
            # Create new contact message
            contact_message = ContactMessage(
                first_name=first_name,
                last_name=last_name,
                email=email,
                subject=subject,
                message=message,
                submitted_at=datetime.utcnow()
            )
            
            # Save to database
            db.session.add(contact_message)
            db.session.commit()
            
            flash('Thank you for your message! We\'ll get back to you within 24 hours.', 'success')
            return redirect(url_for('contact'))
            
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while sending your message. Please try again.', 'error')
            return render_template('contact.html', now=datetime.utcnow())
    
    return render_template('contact.html', now=datetime.utcnow())

@app.route('/privacy-policy')
def privacy_policy():
    policy = PolicyContent.get_or_create_default('privacy_policy')
    return render_template('privacy_policy.html', policy=policy, now=datetime.utcnow())

@app.route('/terms-of-service')
def terms_of_service():
    policy = PolicyContent.get_or_create_default('terms_of_service')
    return render_template('terms_of_service.html', policy=policy, now=datetime.utcnow())

@app.route('/refund-policy')
def refund_policy():
    policy = PolicyContent.get_or_create_default('refund_policy')
    return render_template('refund_policy.html', policy=policy, now=datetime.utcnow())

@app.route('/cookie-policy')
def cookie_policy():
    policy = PolicyContent.get_or_create_default('cookie_policy')
    return render_template('cookie_policy.html', policy=policy, now=datetime.utcnow())

# Blog model
class Blog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    summary = db.Column(db.String(500), nullable=True)
    content = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=True)
    image = db.Column(db.String(120), nullable=True)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    author = db.relationship('User', backref='blogs')
    date = db.Column(db.DateTime, default=datetime.utcnow)
    read_time = db.Column(db.String(20), nullable=True)
    tags = db.Column(db.String(200), nullable=True)

# Site Settings model
class SiteSettings(db.Model):
    """Model for storing website settings like logo, footer, social links"""
    id = db.Column(db.Integer, primary_key=True)
    setting_name = db.Column(db.String(50), nullable=False)  # 'general', 'footer', 'social', 'contact'
    
    # Logo settings
    logo = db.Column(db.String(200), nullable=True)  # Logo filename
    logo_alt = db.Column(db.String(200), nullable=True)  # Logo alt text
    
    # Footer settings
    footer_description = db.Column(db.Text, nullable=True)  # Footer description text
    
    # Social media links (JSON string)
    social_links = db.Column(db.Text, nullable=True)  # JSON string for social media URLs
    
    # Contact information (JSON string)
    contact_info = db.Column(db.Text, nullable=True)  # JSON string for contact details
    
    # Meta fields
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationship
    admin = db.relationship('User', backref='site_settings')
    
    def __repr__(self):
        return f'<SiteSettings {self.setting_name}>'
    
    @staticmethod
    def get_general_settings():
        """Get active general settings (logo, etc.)"""
        return SiteSettings.query.filter_by(setting_name='general', is_active=True).first()
    
    @staticmethod
    def get_footer_settings():
        """Get active footer settings"""
        return SiteSettings.query.filter_by(setting_name='footer', is_active=True).first()
    
    @staticmethod
    def get_social_settings():
        """Get active social media settings"""
        return SiteSettings.query.filter_by(setting_name='social', is_active=True).first()
    
    @staticmethod
    def get_contact_settings():
        """Get active contact settings"""
        return SiteSettings.query.filter_by(setting_name='contact', is_active=True).first()
    
    @staticmethod
    def get_all_settings():
        """Get all active settings combined"""
        settings = {
            'logo': 'logo.png',
            'logo_alt': 'Skill Finesse Logo',
            'footer_description': 'Skill Finesse is a premier online learning platform dedicated to empowering individuals with the skills they need to succeed in today\'s competitive world.',
            'social_links': {
                'facebook': 'https://www.facebook.com/Skillfinesse',
                'twitter': '#',
                'instagram': 'https://www.instagram.com/skill.finesse/',
                'linkedin': 'https://www.linkedin.com/in/masud-ashraf-taha-61242a1a9/',
                'youtube': '',
                'github': ''
            },
            'contact_info': {
                'address': 'E-14/X, ICT Tower (14th Floor), Agargaon, Dhaka - 1207, Bangladesh',
                'phone': '+8801786661453',
                'email': 'info@skillfinesse.com'
            }
        }
        
        # Override with database values if they exist
        general_settings = SiteSettings.get_general_settings()
        if general_settings:
            if general_settings.logo:
                settings['logo'] = general_settings.logo
            if general_settings.logo_alt:
                settings['logo_alt'] = general_settings.logo_alt
        
        footer_settings = SiteSettings.get_footer_settings()
        if footer_settings and footer_settings.footer_description:
            settings['footer_description'] = footer_settings.footer_description
        
        social_settings = SiteSettings.get_social_settings()
        if social_settings and social_settings.social_links:
            try:
                settings['social_links'] = json.loads(social_settings.social_links)
            except (ValueError, TypeError):
                pass
        
        contact_settings = SiteSettings.get_contact_settings()
        if contact_settings and contact_settings.contact_info:
            try:
                settings['contact_info'] = json.loads(contact_settings.contact_info)
            except (ValueError, TypeError):
                pass
        
        return settings
    
    @staticmethod
    def get_default_settings():
        """Get default site settings"""
        return {
            'logo': 'logo.png',
            'logo_alt': 'Skill Finesse Logo',
            'footer_description': 'Skill Finesse is a premier online learning platform dedicated to empowering individuals with the skills they need to succeed in today\'s competitive world.',
            'social_links': {
                'facebook': 'https://www.facebook.com/Skillfinesse',
                'twitter': '#',
                'instagram': 'https://www.instagram.com/skill.finesse/',
                'linkedin': 'https://www.linkedin.com/in/masud-ashraf-taha-61242a1a9/',
                'youtube': '',
                'github': ''
            },
            'contact_info': {
                'address': 'E-14/X, ICT Tower (14th Floor), Agargaon, Dhaka - 1207, Bangladesh',
                'phone': '+8801786661453',
                'email': 'info@skillfinesse.com'
            }
        }

# Update template context processor to use SiteSettings model
@app.context_processor  
def inject_site_settings():
    """Make site settings available to all templates"""
    try:
        site_settings = SiteSettings.get_all_settings()
        return {'site_settings': site_settings}
    except Exception as e:
        # Return defaults if database error
        default_settings = {
            'logo': 'logo.png',
            'logo_alt': 'Skill Finesse Logo',
            'footer_description': 'Skill Finesse is a premier online learning platform.',
            'social_links': {
                'facebook': '#',
                'twitter': '#',
                'instagram': '#',
                'linkedin': '#',
                'youtube': '',
                'github': ''
            },
            'contact_info': {
                'address': 'Contact us for more information',
                'phone': '',
                'email': ''
            }
        }
        return {'site_settings': default_settings}

# About Page Content model
class AboutPageContent(db.Model):
    """Model for storing about page section content"""
    id = db.Column(db.Integer, primary_key=True)
    section_name = db.Column(db.String(50), nullable=False)  # 'main_about', 'mission', 'team'
    
    # Main About Section fields
    main_about_title = db.Column(db.Text, nullable=True)
    main_about_subtitle = db.Column(db.Text, nullable=True)
    main_about_content = db.Column(db.Text, nullable=True)  # HTML content
    main_about_images = db.Column(db.Text, nullable=True)  # JSON string for images
    main_about_features = db.Column(db.Text, nullable=True)  # JSON string for feature cards
    
    # Mission Section fields
    mission_title = db.Column(db.Text, nullable=True)
    mission_content = db.Column(db.Text, nullable=True)  # HTML content
    mission_vision_title = db.Column(db.Text, nullable=True)
    mission_vision_content = db.Column(db.Text, nullable=True)  # HTML content
    mission_points = db.Column(db.Text, nullable=True)  # JSON string for mission points
    vision_points = db.Column(db.Text, nullable=True)  # JSON string for vision points
    
    # Team Section fields
    team_title = db.Column(db.Text, nullable=True)
    team_subtitle = db.Column(db.Text, nullable=True)
    team_members = db.Column(db.Text, nullable=True)  # JSON string for team members
    
    # Meta fields
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationship
    admin = db.relationship('User', backref='about_page_contents')
    
    def __repr__(self):
        return f'<AboutPageContent {self.section_name}>'
    
    @staticmethod
    def get_main_about_content():
        """Get active main about section content"""
        return AboutPageContent.query.filter_by(section_name='main_about', is_active=True).first()
    
    @staticmethod
    def get_mission_content():
        """Get active mission section content"""
        return AboutPageContent.query.filter_by(section_name='mission', is_active=True).first()
    
    @staticmethod
    def get_team_content():
        """Get active team section content"""
        return AboutPageContent.query.filter_by(section_name='team', is_active=True).first()
    
    @staticmethod
    def get_default_main_about_content():
        """Get default main about section content"""
        import json
        return {
            'main_about_title': 'Empowering Careers Through Quality Education',
            'main_about_subtitle': 'Since 2020',
            'main_about_content': '''<p>Skill Finesse is a premier online learning platform dedicated to providing high-quality, accessible education to learners worldwide. Our mission is to bridge the gap between education and employment by offering courses that are relevant, practical, and aligned with industry demands.</p>
            <p>With a team of expert instructors who are leaders in their respective fields, we deliver comprehensive courses that combine theoretical knowledge with practical applications, ensuring our students are well-prepared for real-world challenges.</p>''',
            'main_about_images': json.dumps([
                {
                    'image': 'about_us_section_1.png',
                    'alt': 'Happy Student',
                    'caption': 'Ready to Begin?',
                    'description': 'Join our community of learners today'
                }
            ]),
            'main_about_features': json.dumps([
                {
                    'icon': 'fas fa-book',
                    'title': 'Expert Curriculum',
                    'description': 'Designed by industry experts'
                },
                {
                    'icon': 'fas fa-project-diagram',
                    'title': 'Hands-on Projects',
                    'description': 'Real-world case studies'
                },
                {
                    'icon': 'fas fa-graduation-cap',
                    'title': 'Learning Paths',
                    'description': 'Personalized for all skill levels'
                },
                {
                    'icon': 'fas fa-headset',
                    'title': 'Dedicated Support',
                    'description': 'From instructors and community'
                }
            ])
        }
    
    @staticmethod
    def get_default_mission_content():
        """Get default mission section content"""
        import json
        return {
            'mission_title': 'Our Mission & Vision',
            'mission_content': '''<p>To democratize education by providing accessible, high-quality learning experiences that help individuals acquire in-demand skills, advance their careers, and achieve their full potential in an ever-evolving digital landscape.</p>''',
            'mission_vision_title': 'Our Vision',
            'mission_vision_content': '''<p>To become the leading platform for skill development in Bangladesh and beyond, creating a global community of lifelong learners equipped with the knowledge and abilities needed to thrive in a rapidly changing world.</p>''',
            'mission_points': json.dumps([
                'Provide accessible education to learners worldwide',
                'Bridge the gap between education and employment',
                'Offer courses aligned with industry demands',
                'Ensure students are well-prepared for real-world challenges'
            ]),
            'vision_points': json.dumps([
                'Create a global community of lifelong learners',
                'Continuously innovate and improve our educational offerings',
                'Adapt to emerging trends and technologies',
                'Empower individuals to achieve their career goals'
            ])
        }
    
    @staticmethod
    def get_default_team_content():
        """Get default team section content"""
        import json
        return {
            'team_title': 'Meet Our Team',
            'team_subtitle': 'Dedicated professionals committed to your success',
            'team_members': json.dumps([
                {
                    'image': 'instructor_1.png',
                    'name': 'John Doe',
                    'position': 'Founder & CEO',
                    'social_links': {
                        'linkedin': '#',
                        'twitter': '#',
                        'facebook': '#'
                    }
                },
                {
                    'image': 'instructor_2.png',
                    'name': 'Jane Smith',
                    'position': 'Chief Technology Officer',
                    'social_links': {
                        'linkedin': '#',
                        'twitter': '#',
                        'github': '#'
                    }
                },
                {
                    'image': 'instructor_3.png',
                    'name': 'David Wilson',
                    'position': 'Lead Instructor',
                    'social_links': {
                        'linkedin': '#',
                        'twitter': '#',
                        'youtube': '#'
                    }
                },
                {
                    'image': 'instructor_4.png',
                    'name': 'Sarah Johnson',
                    'position': 'Head of Content',
                    'social_links': {
                        'linkedin': '#',
                        'twitter': '#',
                        'instagram': '#'
                    }
                }
            ])
        }

# Homepage Content model
class HomepageContent(db.Model):
    """Model for storing homepage section content"""
    id = db.Column(db.Integer, primary_key=True)
    section_name = db.Column(db.String(50), nullable=False)  # 'hero', 'courses_showcase', 'features', 'videos', 'about', 'cta'
    
    # Hero Section fields
    hero_title = db.Column(db.Text, nullable=True)
    hero_subtitle = db.Column(db.Text, nullable=True)
    hero_description = db.Column(db.Text, nullable=True)
    hero_button_text = db.Column(db.String(50), nullable=True)
    hero_button_url = db.Column(db.String(200), nullable=True)
    hero_video_button_text = db.Column(db.String(50), nullable=True)
    hero_stats = db.Column(db.Text, nullable=True)  # JSON string for stats data
    hero_slider_images = db.Column(db.Text, nullable=True)  # JSON string for slider images
    
    # Courses Showcase fields
    courses_title = db.Column(db.Text, nullable=True)
    courses_subtitle = db.Column(db.Text, nullable=True)
    courses_description = db.Column(db.Text, nullable=True)
    courses_grid_title = db.Column(db.String(100), nullable=True)
    courses_grid_badge = db.Column(db.String(50), nullable=True)
    courses_cards = db.Column(db.Text, nullable=True)  # JSON string for course cards
    courses_mini_slider_title = db.Column(db.String(100), nullable=True)
    courses_mini_slider_subtitle = db.Column(db.Text, nullable=True)
    courses_mini_slider_images = db.Column(db.Text, nullable=True)  # JSON string for mini slider images
    
    # Features Section fields
    features_title = db.Column(db.Text, nullable=True)
    features_subtitle = db.Column(db.Text, nullable=True)
    features_items = db.Column(db.Text, nullable=True)  # JSON string for feature items
    
    # Video Showcase Section fields
    videos_title = db.Column(db.Text, nullable=True)
    videos_subtitle = db.Column(db.Text, nullable=True)
    videos_youtube_link = db.Column(db.String(500), nullable=True)
    videos_items = db.Column(db.Text, nullable=True)  # JSON string for video items
    
    # About Section fields
    about_title = db.Column(db.Text, nullable=True)
    about_content = db.Column(db.Text, nullable=True)  # HTML content
    about_images = db.Column(db.Text, nullable=True)  # JSON string for about images
    about_points = db.Column(db.Text, nullable=True)  # JSON string for about points
    
    # CTA Section fields
    cta_title = db.Column(db.Text, nullable=True)
    cta_content = db.Column(db.Text, nullable=True)  # HTML content
    cta_button_text = db.Column(db.String(100), nullable=True)
    cta_button_url = db.Column(db.String(200), nullable=True)
    cta_images = db.Column(db.Text, nullable=True)  # JSON string for CTA images
    cta_points = db.Column(db.Text, nullable=True)  # JSON string for CTA points
    
    # Meta fields
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationship
    admin = db.relationship('User', backref='homepage_contents')
    
    def __repr__(self):
        return f'<HomepageContent {self.section_name}>'
    
    @staticmethod
    def get_hero_content():
        """Get active hero section content"""
        return HomepageContent.query.filter_by(section_name='hero', is_active=True).first()
    
    @staticmethod
    def get_courses_content():
        """Get active courses showcase content"""
        return HomepageContent.query.filter_by(section_name='courses_showcase', is_active=True).first()
    
    @staticmethod
    def get_features_content():
        """Get active features section content"""
        return HomepageContent.query.filter_by(section_name='features', is_active=True).first()
    
    @staticmethod
    def get_videos_content():
        """Get active videos section content"""
        return HomepageContent.query.filter_by(section_name='videos', is_active=True).first()
    
    @staticmethod
    def get_about_content():
        """Get active about section content"""
        return HomepageContent.query.filter_by(section_name='about', is_active=True).first()
    
    @staticmethod
    def get_cta_content():
        """Get active CTA section content"""
        return HomepageContent.query.filter_by(section_name='cta', is_active=True).first()
    
    @staticmethod
    def get_default_hero_content():
        """Get default hero section content"""
        import json
        return {
            'hero_title': 'Begin Your <span>Learning Journey</span> Today',
            'hero_subtitle': 'Transform Your Career with Expert-Led Courses',
            'hero_description': 'Join thousands of students who have transformed their careers with our professional courses tailored to industry demands.',
            'hero_button_text': 'Get Started Now',
            'hero_button_url': '/register',
            'hero_video_button_text': 'Watch Video',
            'hero_stats': json.dumps([
                {'number': '50+', 'label': 'Professional Courses'},
                {'number': '15k+', 'label': 'Active Students'},
                {'number': '98%', 'label': 'Success Rate'},
                {'number': '24/7', 'label': 'Learning Support'}
            ]),
            'hero_slider_images': json.dumps([
                {
                    'image': 'slider_1.jpg',
                    'title': 'Elevate Your <span class="highlight">Skills</span>',
                    'description': 'Transform your career with expert-led courses',
                    'button_text': 'Explore Courses'
                },
                {
                    'image': 'slider_2.jpeg',
                    'title': 'Learn from <span class="highlight">Experts</span>',
                    'description': 'Gain knowledge from industry professionals',
                    'button_text': 'Discover Programs'
                },
                {
                    'image': 'slider_3.jpeg',
                    'title': 'Flexible <span class="highlight">Learning</span>',
                    'description': 'Learn at your own pace, anytime, anywhere',
                    'button_text': 'Join Now'
                },
                {
                    'image': 'slider_4.jpeg',
                    'title': 'Career <span class="highlight">Success</span>',
                    'description': 'Acquire in-demand skills for your future',
                    'button_text': 'Get Started'
                }
            ])
        }
    
    @staticmethod
    def get_default_courses_content():
        """Get default courses showcase content"""
        import json
        return {
            'courses_title': 'Your Learning Journey Starts Here',
            'courses_subtitle': 'Discover Quality Education',
            'courses_description': 'Choose from our comprehensive collection of courses designed to boost your career.',
            'courses_grid_title': 'All Featured Online Courses',
            'courses_grid_badge': 'Enrollment Open!',
            'courses_cards': json.dumps([
                {
                    'image': 'free_course_cover_1.png',
                    'title': 'Class 6-7-8',
                    'description': 'Primary education courses'
                },
                {
                    'image': 'free_course_cover_2.png',
                    'title': 'Class 9-10',
                    'description': 'Secondary education courses'
                },
                {
                    'image': 'free_course_cover_3.png',
                    'title': 'SSC 25',
                    'description': 'SSC exam preparation'
                },
                {
                    'image': 'free_course_cover_4.png',
                    'title': 'HSC 25-26',
                    'description': 'HSC exam preparation'
                }
            ]),
            'courses_mini_slider_title': 'Learn Skills Your Way',
            'courses_mini_slider_subtitle': 'Personalized learning paths for your career growth',
            'courses_mini_slider_images': json.dumps([
                {
                    'image': 'premium_course_1.png',
                    'alt': 'Web Development'
                },
                {
                    'image': 'premium_course_2.png',
                    'alt': 'Data Science'
                },
                {
                    'image': 'premium_course_3.png',
                    'alt': 'Mobile App Development'
                },
                {
                    'image': 'premium_course_4.png',
                    'alt': 'UX/UI Design'
                }
            ])
        }
    
    @staticmethod
    def get_default_features_content():
        """Get default features section content"""
        import json
        return {
            'features_title': 'Why Choose Skill Finesse',
            'features_subtitle': 'Discover the benefits that set us apart from other learning platforms',
            'features_items': json.dumps([
                {
                    'icon': 'fas fa-graduation-cap',
                    'title': 'Expert Instructors',
                    'description': 'Learn from industry professionals with years of real-world experience who are passionate about teaching.'
                },
                {
                    'icon': 'fas fa-laptop-code',
                    'title': 'Practical Learning',
                    'description': 'Apply your knowledge through hands-on projects and real-world case studies to build your portfolio.'
                },
                {
                    'icon': 'fas fa-certificate',
                    'title': 'Recognized Certificates',
                    'description': 'Earn certificates that demonstrate your competence and boost your credentials to employers.'
                },
                {
                    'icon': 'fas fa-comments',
                    'title': 'Community Support',
                    'description': 'Join a thriving community of learners to network, collaborate, and grow together.'
                },
                {
                    'icon': 'fas fa-clock',
                    'title': 'Flexible Schedule',
                    'description': 'Learn at your own pace with 24/7 access to course content from any device, anywhere.'
                },
                {
                    'icon': 'fas fa-sync-alt',
                    'title': 'Updated Content',
                    'description': 'Stay current with regularly updated courses that reflect the latest trends and technologies.'
                }
            ])
        }
    
    @staticmethod
    def get_default_videos_content():
        """Get default videos section content"""
        import json
        return {
            'videos_title': 'Featured Videos',
            'videos_subtitle': 'Watch our most popular videos and learn from expert demonstrations',
            'videos_youtube_link': 'https://www.youtube.com/@SkillFinesse',
            'videos_items': json.dumps([
                {
                    'embed_id': 'CFhh_mi-0NQ',
                    'title': 'Uttara University Skill Finesse Ambassador Activation Program',
                    'category': 'Ambassador Program',
                    'description': 'Learn about our ambassador program and how it helps students develop leadership skills.',
                    'upload_date': 'May 2025'
                },
                {
                    'embed_id': 'kcWbnAC85tc',
                    'title': 'Real-Time Object Tracking & Speed Measurement with Flask',
                    'category': 'Technical Tutorial',
                    'description': 'Discover how to implement real-time object tracking and speed measurement using Flask, Tkinter & OpenCV.',
                    'upload_date': 'April 2025'
                },
                {
                    'embed_id': 'eF9WjDSKJG8',
                    'title': 'Learn| Earn| Thrive Podcast: Sadid\'s Journey Success',
                    'category': 'Success Story',
                    'description': 'Listen to Sadid\'s inspiring journey of earning over 150,000+ টাকা through skills learned with Skill Finesse.',
                    'upload_date': 'March 2025'
                }
            ])
        }
    
    @staticmethod
    def get_default_about_content():
        """Get default about section content"""
        import json
        return {
            'about_title': 'About Skill Finesse',
            'about_content': 'Skill Finesse is a premier online learning platform dedicated to providing high-quality, accessible education to learners worldwide. Our mission is to bridge the gap between education and employment by offering courses that are relevant, practical, and aligned with industry demands.',
            'about_images': json.dumps([
                {
                    'image': 'contact_form_section.png',
                    'alt': 'Contact Us',
                    'caption': 'Ready to Begin?',
                    'description': 'Join our community of learners today'
                }
            ]),
            'about_points': json.dumps([
                {
                    'icon': 'fas fa-book-reader',
                    'title': 'Expert Curriculum',
                    'description': 'Designed by industry experts'
                },
                {
                    'icon': 'fas fa-project-diagram',
                    'title': 'Hands-on Projects',
                    'description': 'Real-world case studies'
                },
                {
                    'icon': 'fas fa-user-graduate',
                    'title': 'Learning Paths',
                    'description': 'Personalized for all skill levels'
                },
                {
                    'icon': 'fas fa-headset',
                    'title': 'Dedicated Support',
                    'description': 'From instructors and community'
                }
            ])
        }
    
    @staticmethod
    def get_default_cta_content():
        """Get default CTA section content"""
        import json
        return {
            'cta_title': 'Ready to Transform Your Career?',
            'cta_content': 'Take the first step toward your professional growth with Skill Finesse. Our platform offers comprehensive courses designed to help you succeed.',
            'cta_button_text': 'Get Started Today',
            'cta_button_url': '/register',
            'cta_images': json.dumps([
                {
                    'image': 'about_us_section_1.png',
                    'alt': 'Success Story 1'
                },
                {
                    'image': 'about_us_section_2.png',
                    'alt': 'Success Story 2'
                }
            ]),
            'cta_points': json.dumps([
                {
                    'icon': 'fas fa-certificate',
                    'title': 'Recognized Certification',
                    'description': 'Industry-recognized credentials'
                },
                {
                    'icon': 'fas fa-users',
                    'title': 'Community Access',
                    'description': 'Network with like-minded professionals'
                },
                {
                    'icon': 'fas fa-file-alt',
                    'title': 'Premium Resources',
                    'description': 'Access to exclusive learning materials'
                },
                {
                    'icon': 'fas fa-laptop-code',
                    'title': 'Hands-on Projects',
                    'description': 'Build your portfolio with real projects'
                }
            ])
        }

# Policy Content Model
class PolicyContent(db.Model):
    """Model for storing policy content like Privacy Policy, Terms of Service, etc."""
    id = db.Column(db.Integer, primary_key=True)
    policy_type = db.Column(db.String(50), nullable=False, unique=True)  # privacy_policy, terms_of_service, etc.
    title = db.Column(db.String(200), nullable=False)
    last_updated = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationship
    admin = db.relationship('User', backref='policy_contents')
    
    def __repr__(self):
        return f'<PolicyContent {self.policy_type}>'
    
    @staticmethod
    def get_or_create_default(policy_type):
        """Get existing policy or create default content"""
        policy = PolicyContent.query.filter_by(policy_type=policy_type).first()
        if not policy:
            # Create default content
            default_content = PolicyContent.get_default_content(policy_type)
            if default_content:
                # Find an admin user to assign as creator
                admin_user = User.query.filter_by(is_admin=True).first()
                if admin_user:
                    policy = PolicyContent(
                        policy_type=policy_type,
                        title=default_content['title'],
                        last_updated=default_content['last_updated'],
                        content=default_content['content'],
                        admin_id=admin_user.id
                    )
                    db.session.add(policy)
                    db.session.commit()
        return policy
    
    @staticmethod
    def get_default_content(policy_type):
        """Get default content for each policy type"""
        defaults = {
            'privacy_policy': {
                'title': 'Privacy Policy',
                'last_updated': 'May 10, 2025',
                'content': '''<div class="policy-highlight">
    <p>At Skill Finesse, we are committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy outlines how we collect, use, and safeguard your data when you use our services.</p>
</div>

<h2>1. Information We Collect</h2>
<p>We collect information you provide directly to us, such as when you create an account, enroll in a course, or contact us for support. This may include:</p>
<ul>
    <li>Name and contact information</li>
    <li>Email address</li>
    <li>Account credentials</li>
    <li>Payment information</li>
    <li>Course enrollment and progress data</li>
    <li>Communication preferences</li>
</ul>

<h2>2. How We Use Your Information</h2>
<p>We use the information we collect to:</p>
<ul>
    <li>Provide, maintain, and improve our services</li>
    <li>Process transactions and send you related information</li>
    <li>Send you technical notices, updates, security alerts, and support messages</li>
    <li>Respond to your comments, questions, and customer service requests</li>
    <li>Communicate with you about courses, offers, promotions, and news</li>
    <li>Monitor and analyze trends, usage, and activities</li>
    <li>Detect, investigate, and prevent fraudulent transactions</li>
</ul>

<h2>3. Information Sharing and Disclosure</h2>
<p>We do not sell, trade, or rent your personal information to third parties. We may share your information in the following circumstances:</p>
<ul>
    <li>With instructors whose courses you enroll in</li>
    <li>With service providers who perform services on our behalf</li>
    <li>To comply with legal obligations</li>
    <li>To protect and defend our rights and property</li>
    <li>With your consent or at your direction</li>
</ul>

<h2>4. Data Security</h2>
<p>We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the Internet is 100% secure, and we cannot guarantee absolute security.</p>

<h2>5. Your Rights and Choices</h2>
<p>You have the right to:</p>
<ul>
    <li>Access and update your account information</li>
    <li>Request deletion of your personal data</li>
    <li>Opt-out of marketing communications</li>
    <li>Request a copy of your personal information</li>
    <li>Lodge a complaint with a supervisory authority</li>
</ul>

<h2>6. Cookies and Tracking Technologies</h2>
<p>We use cookies and similar tracking technologies to track activity on our website and hold certain information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.</p>

<h2>7. Children's Privacy</h2>
<p>Our services are not directed to individuals under the age of 13. We do not knowingly collect personal information from children under 13. If we become aware that we have collected personal information from a child under 13, we will take steps to delete such information.</p>

<h2>8. International Data Transfers</h2>
<p>Your information may be transferred to and maintained on computers located outside of your state, province, country, or other governmental jurisdiction where the data protection laws may differ from those of your jurisdiction.</p>

<h2>9. Changes to This Privacy Policy</h2>
<p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date.</p>

<div class="policy-highlight">
    <p>If you have any questions about this Privacy Policy, please contact us at privacy@skillfinesse.com</p>
</div>'''
            },
            'refund_policy': {
                'title': 'Refund Policy',
                'last_updated': 'July 5, 2025',
                'content': '''<div class="no-refund-alert">
    <p>Refund Policy – Please Read Before Enrolling</p>
</div>

<p>At Skill Finesse, we are committed to delivering high-quality educational content and providing an exceptional learning experience. Before enrolling in any of our courses, please carefully read and understand our <span class="important-text">No Refund Policy</span>:</p>

<h2>1. No Refunds After Purchase</h2>
<p>All course purchases are <span class="important-text">final</span>. We do <span class="important-text">not offer refunds</span> for any course once the payment has been processed. This applies to all learners, under all circumstances, including:</p>
<ul>
    <li>Change of mind after purchase</li>
    <li>Inability to complete or attend the course</li>
    <li>Lack of technical knowledge or equipment</li>
    <li>Misunderstanding of course content or structure</li>
</ul>

<h2>2. Course Details Available Before Purchase</h2>
<p>We encourage all users to <span class="important-text">review the course curriculum, previews, instructor information, and FAQs</span> before making a purchase decision. If you have any questions, our support team is available to help.</p>

<h2>3. Exceptional Circumstances</h2>
<p>While we maintain a strict no refund policy, we reserve the right to <span class="important-text">review exceptional cases</span>. (When a learner mistakenly purchased a course instead of another course of Skill Finesse)</p>

<h2>4. Acceptance of Policy</h2>
<p>By enrolling in our courses, you acknowledge that you have read, understood, and agreed to our No Refund Policy.</p>

<div class="policy-highlight">
    <p>For any questions about our Refund Policy or to request review of exceptional circumstances, please contact our support team through the official channels listed on our website.</p>
</div>'''
            },
            'terms_of_service': {
                'title': 'Terms of Service',
                'last_updated': 'July 5, 2025',
                'content': '''<div class="policy-highlight">
    <p>These Terms & Conditions ("Terms") govern your use of our website www.skillfinesse.com and services between Shikho Technologies Limited and its users.</p>
</div>

<h2>1. Agreement Overview</h2>
<p>These Terms & Conditions ("Terms") of (a) use of our website www.skillfinesse.com ("Website"), Website/products ("Services") or (b) any modes of registrations or usage of products, including through SD cards, tablets or other storage/transmitting device are between Shikho Technologies Limited ("Company/We/Us/Our") and its users ("User/You/Your").</p>

<p>These Terms constitute an electronic record in accordance with the provisions of the ICT Act 2006 and the Information Technology (Intermediaries guidelines) Rules, 2011 thereunder, as amended from time to time.</p>

<h2>2. Acceptance and Compliance</h2>
<p>Please read the Terms and the privacy policy of the Company ("Privacy Policy") with respect to registration with us, the use of the Application, Website, Services and products carefully before using the Application, Website, Services or products. In the event of any discrepancy between the Terms and any other policies with respect to the Application or Website or Services or products, the provisions of the Terms shall prevail.</p>

<p>Your use/access/browsing of the Application or Website or the Services or products or registration (with or without payment/with or without subscription) through any means shall signify Your acceptance of the Terms and Your agreement to be legally bound by the same.</p>

<p>If You do not agree with the Terms or the Privacy Policy, please do not use the Application or Website or avail the Services or products. Any access to our Services/Application/products through registrations/subscription is non transferable.</p>

<h2>3. Permitted Use and Restrictions</h2>
<p>It is prohibited to use our products, services, website, and application for any purpose other than personal or non-commercial. It is prohibited to use the application, website, services, or products for any purpose except personal ones. The following rules apply to your use of this application, website, and our services for personal and non-commercial purposes:</p>

<ul>
    <li><strong>i)</strong> You may not copy, modify, translate, display, distribute, or perform any information or software obtained from the Application and / or our Website and/or Services/Products or remove any copyright, trademark registration, or other proprietary notices from the contents of the Application and / or and / or our Website and/or Services/Products.</li>
    <li><strong>ii)</strong> You are prohibited from using this application, our website, and our products and services for commercial purposes, including but not limited to selling, advertising, or promoting the application or any of our products or services, asking for contributions or donations, or using public forums for commercial purposes.</li>
</ul>

<h2>4. User Information and Feedback</h2>
<p>Your information, provided about the Application, will be considered non-confidential. Applications can use the information whatever they choose. In addition, you represent and warrant by sending feedback that (i) your feedback does not contain confidential or patent information from you or third parties; (ii) the Company is not obligated or implied to maintain confidentiality regarding feedback; (iii) the Application could be similar to the feedback already being considered or under development;</p>

<h2>5. Limitation of Liability</h2>
<p>The Company is not liable for anything published by other users, including inappropriate or harmful content. It is important to be careful when visiting the Application.</p>

<div class="policy-highlight">
    <p>For any questions about these Terms of Service, please contact us through our official channels listed on our website.</p>
</div>'''
            },
            'cookie_policy': {
                'title': 'Cookie Policy',
                'last_updated': 'May 10, 2025',
                'content': '''<div class="policy-highlight">
    <p>This Cookie Policy explains how Skill Finesse uses cookies and similar technologies to recognize you when you visit our website. It explains what these technologies are and why we use them, as well as your rights to control our use of them.</p>
</div>

<h2>1. What Are Cookies?</h2>
<p>Cookies are small data files that are placed on your computer or mobile device when you visit a website. Cookies are widely used by website owners in order to make their websites work, or to work more efficiently, as well as to provide reporting information.</p>

<p>Cookies set by the website owner (in this case, Skill Finesse) are called "first-party cookies." Cookies set by parties other than the website owner are called "third-party cookies." Third-party cookies enable third-party features or functionality to be provided on or through the website (e.g., advertising, interactive content, and analytics).</p>

<h2>2. Why Do We Use Cookies?</h2>
<p>We use first- and third-party cookies for several reasons. Some cookies are required for technical reasons in order for our website to operate, and we refer to these as "essential" or "strictly necessary" cookies. Other cookies enable us to track and target the interests of our users to enhance the experience on our website. Third parties serve cookies through our website for advertising, analytics, and other purposes.</p>

<h2>3. Types of Cookies We Use</h2>
<table class="cookie-table">
    <thead>
        <tr>
            <th>Type of Cookie</th>
            <th>Purpose</th>
            <th>Duration</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><strong>Essential Cookies</strong></td>
            <td>These cookies are strictly necessary to provide you with services available through our website and to use some of its features, such as access to secure areas.</td>
            <td>Session</td>
        </tr>
        <tr>
            <td><strong>Performance Cookies</strong></td>
            <td>These cookies are used to enhance the performance and functionality of our website but are non-essential. They help us understand how visitors interact with our website.</td>
            <td>Persistent</td>
        </tr>
        <tr>
            <td><strong>Functionality Cookies</strong></td>
            <td>These cookies enable personalized features such as remembering your preferences, login details, and language selection.</td>
            <td>Persistent</td>
        </tr>
        <tr>
            <td><strong>Analytics Cookies</strong></td>
            <td>These cookies help us understand how our website is being used, how effective marketing campaigns are, and help us customize our website for you.</td>
            <td>Persistent</td>
        </tr>
        <tr>
            <td><strong>Advertising Cookies</strong></td>
            <td>These cookies are used to make advertising messages more relevant to you. They perform functions like preventing the same ad from continuously reappearing.</td>
            <td>Persistent</td>
        </tr>
    </tbody>
</table>

<h2>4. How Can You Control Cookies?</h2>
<p>You have the right to decide whether to accept or reject cookies. You can exercise your cookie rights by setting your preferences in the Cookie Consent Manager. The Cookie Consent Manager allows you to select which categories of cookies you accept or reject. Essential cookies cannot be rejected as they are strictly necessary to provide you with services.</p>

<p>You can also set or amend your web browser controls to accept or refuse cookies. If you choose to reject cookies, you may still use our website though your access to some functionality and areas of our website may be restricted.</p>

<h3>4.1 Browser Controls</h3>
<p>Most web browsers allow some control of most cookies through the browser settings. To find out more about cookies, including how to see what cookies have been set, visit:</p>
<ul>
    <li><a href="https://www.aboutcookies.org" target="_blank">www.aboutcookies.org</a></li>
    <li><a href="https://www.allaboutcookies.org" target="_blank">www.allaboutcookies.org</a></li>
</ul>

<h3>4.2 Disabling Cookies</h3>
<p>You can typically remove and reject cookies from our website by changing your browser settings. To do this, follow the instructions provided by your browser (usually located within the "settings," "help," "tools," or "edit" facility). Many browsers are set to accept cookies until you change your settings.</p>

<h2>5. Cookies We Use</h2>
<p>The specific types of first- and third-party cookies served through our website and the purposes they perform are described below:</p>

<h3>5.1 Essential Cookies</h3>
<ul>
    <li><strong>Session ID Cookie:</strong> Maintains your session state across page requests</li>
    <li><strong>Security Cookie:</strong> Helps protect against Cross-Site Request Forgery (CSRF) attacks</li>
    <li><strong>Authentication Cookie:</strong> Identifies you when you're logged in to our website</li>
</ul>

<h3>5.2 Analytics Cookies</h3>
<ul>
    <li><strong>Google Analytics:</strong> Helps us understand how visitors interact with our website</li>
    <li><strong>Performance Monitoring:</strong> Tracks website performance and loading times</li>
</ul>

<h3>5.3 Functionality Cookies</h3>
<ul>
    <li><strong>Language Preference:</strong> Remembers your language selection</li>
    <li><strong>User Preferences:</strong> Stores your preferences like layout and theme</li>
    <li><strong>Recently Viewed:</strong> Keeps track of courses you've recently viewed</li>
</ul>

<h2>6. Third-Party Cookies</h2>
<p>In addition to our own cookies, we may also use various third-party cookies to report usage statistics of our website, deliver advertisements on and through our website, and so on. These third parties may include:</p>
<ul>
    <li>Google Analytics</li>
    <li>Facebook Pixel</li>
    <li>LinkedIn Insight Tag</li>
    <li>YouTube</li>
</ul>

<h2>7. Updates to This Cookie Policy</h2>
<p>We may update this Cookie Policy from time to time to reflect changes to the cookies we use or for other operational, legal, or regulatory reasons. Please revisit this Cookie Policy regularly to stay informed about our use of cookies and related technologies.</p>

<h2>8. More Information</h2>
<p>If you have any questions about our use of cookies or other technologies, please contact us:</p>

<div class="policy-highlight">
    <p>Email: privacy@skillfinesse.com<br>
    Address: 123 Learning Street, Education City, EC 12345<br>
    Phone: +1 (555) 123-4567</p>
</div>'''
            }
        }
        return defaults.get(policy_type)

@app.route('/blog')
def blog():
    # Get query parameters
    page = request.args.get('page', 1, type=int)
    per_page = 6  # Show 6 blogs per page
    category = request.args.get('category')
    search = request.args.get('search')
    tag = request.args.get('tag')
    
    # Start with base query
    query = Blog.query
    
    # Apply filters if provided
    if category:
        query = query.filter_by(category=category)
    if search:
        query = query.filter(Blog.title.contains(search) | Blog.content.contains(search))
    if tag:
        query = query.filter(Blog.tags.contains(tag))
    
    # Order by date, newest first
    query = query.order_by(Blog.date.desc())
    
    # Get paginated results
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    blogs = pagination.items
    
    # If no blogs in database, we'll use demo data
    if not blogs:
        blogs = None
    
    # Get recent posts for sidebar and featured section
    recent_posts = Blog.query.order_by(Blog.date.desc()).limit(3).all()
    
    # Get categories for sidebar with post count
    categories = db.session.query(Blog.category, db.func.count(Blog.id).label('count')).\
                  group_by(Blog.category).order_by(db.desc('count')).all()
    
    # Get popular tags for tag cloud
    all_tags = []
    for blog in Blog.query.all():
        if blog.tags:
            blog_tags = [tag.strip() for tag in blog.tags.split(',')]
            all_tags.extend(blog_tags)
    
    # Count tag occurrences and get top tags
    from collections import Counter
    tag_counter = Counter(all_tags)
    popular_tags = [{'name': tag, 'count': count} for tag, count in tag_counter.most_common(12)]
    
    return render_template('blog.html', blogs=blogs, pagination=pagination, 
                           recent_posts=recent_posts, now=datetime.utcnow(),
                           category=category, search=search, tag=tag,
                           categories=categories, popular_tags=popular_tags)

@app.route('/blog/<int:blog_id>')
def blog_single(blog_id):
    # Get blog post from database
    blog = Blog.query.get_or_404(blog_id)
    
    # Get admin user for author display
    admin_user = User.query.filter_by(is_admin=True).first()
    
    # Get related posts by category
    related_posts = Blog.query.filter(Blog.category == blog.category, Blog.id != blog.id).order_by(Blog.date.desc()).limit(2).all()
    
    # If not enough related posts by category, get recent posts
    if len(related_posts) < 2:
        more_posts = Blog.query.filter(Blog.id != blog.id).order_by(Blog.date.desc()).limit(2 - len(related_posts)).all()
        related_posts.extend(more_posts)
    
    return render_template('blog_single.html', blog=blog, related_posts=related_posts, admin_user=admin_user, now=datetime.utcnow())

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        # Verify Cloudflare Turnstile
        turnstile_response = request.form.get('cf-turnstile-response')
        if not verify_turnstile(turnstile_response, request.remote_addr):
            flash('Security check failed. Please try again.', 'danger')
            return redirect(url_for('join'))
        
        # Get reset method and corresponding data
        reset_method = request.form.get('reset_method', 'email')
        user = None
        search_type = reset_method
        
        if reset_method == 'email':
            # Email reset
            email = request.form.get('email', '').strip()
            if not email:
                flash('Please enter your email address.', 'danger')
                return redirect(url_for('join'))
            
            user = User.query.filter_by(email=email).first()
            search_identifier = email
            
        else:  # phone reset
            # Phone reset
            phone_number = request.form.get('phone_number', '').strip()
            country_code = request.form.get('country_code', '').strip()
            
            if not phone_number or not country_code:
                flash('Please enter your complete phone number.', 'danger')
                return redirect(url_for('join'))
            
            # Search by phone number and country code
            user = User.query.filter_by(phone_number=phone_number, country_code=country_code).first()
            search_identifier = f"{country_code}{phone_number}"
        
        if user:
            print(f"🔍 Found user by {search_type}: {user.email} (searched with: {search_identifier})")
            
            # Always send password reset link to user's email address
            print(f"📧 Attempting to send password reset to: {user.email}")
            result = send_password_reset_code(user.email)
            
            print(f"📧 Password reset result: {result}")
            
            if result['success']:
                print(f"✅ Password reset email sent to: {user.email}")
                
                # Don't store user info in session for security
                # Firebase will handle the reset token verification
                
                if search_type == 'phone':
                    flash(f'Password reset link has been sent to the email address associated with your phone number: {user.email}', 'info')
                else:
                    flash(f'Password reset link has been sent to {user.email}', 'info')
                    
                return redirect(url_for('join'))
            else:
                flash(f'Error sending reset email: {result.get("message", "Unknown error")}', 'danger')
                return redirect(url_for('join'))
        else:
            # Don't reveal whether account exists for security
            print(f"❌ No user found by {search_type}: {search_identifier}")
            if search_type == 'phone':
                flash('If an account with that phone number exists, a password reset link has been sent to the associated email address.', 'info')
            else:
                flash('If an account with that email address exists, a password reset link has been sent.', 'info')
            
            return redirect(url_for('join'))
    
    return redirect(url_for('join'))

@app.route('/verify-email/<mode>')
def verify_email(mode):
    """Display email verification pending page"""
    if mode not in ['signup', 'reset']:
        flash('Invalid verification mode.', 'danger')
        return redirect(url_for('join'))
    
    email = session.get('verification_email') or session.get('otp_identifier')
    if not email:
        flash('Session expired. Please try again.', 'danger')
        return redirect(url_for('join'))
    
    masked_email_display = mask_email(email)
    
    return render_template('verify_email.html', 
                         mode=mode, 
                         email=email,
                         masked_email=masked_email_display,
                         now=datetime.utcnow())



@app.route('/verify-email-complete')
def verify_email_complete():
    """Handle Firebase email verification completion"""
    # Debug: Print all URL parameters
    print(f"🔍 All URL parameters: {dict(request.args)}")
    
    # Firebase may redirect here with different parameters after processing
    # Check for common Firebase redirect parameters
    auth_success = request.args.get('success')
    auth_error = request.args.get('error')
    mode = request.args.get('mode')
    
    # Get the token from URL parameters (Firebase will add it)
    token = request.args.get('oobCode')
    
    # Also try alternative parameter names that Firebase might use
    if not token:
        token = request.args.get('oob_code')
    if not token:
        token = request.args.get('code')
    if not token:
        token = request.args.get('token')
    
    print(f"🔍 oobCode: {token}")
    print(f"🔍 mode: {mode}")
    print(f"🔍 success: {auth_success}")
    print(f"🔍 error: {auth_error}")
    
    # Handle Firebase's processed result first
    if auth_success == 'true' or auth_success == '1':
        print("✅ Firebase reports verification successful")
        # Try to get email from session or other sources
        email = session.get('verification_email') or session.get('signup_data', {}).get('email')
        if email:
            existing_user = User.query.filter_by(email=email).first()
            if existing_user:
                existing_user.email_verified = True
                db.session.commit()
                session['user_id'] = existing_user.id
                session['user_type'] = 'admin' if existing_user.is_admin else 'user'
                flash('Email verified successfully! Welcome back.', 'success')
                
                if existing_user.is_admin:
                    return redirect(url_for('admin_dashboard'))
                else:
                    return redirect(url_for('dashboard'))
        
        flash('Email verified successfully! Please log in.', 'success')
        return redirect(url_for('join'))
    
    if auth_error:
        print(f"❌ Firebase reports error: {auth_error}")
        flash(f'Email verification failed: {auth_error}', 'danger')
        return redirect(url_for('join'))
    
    # If we have an oobCode, try to process it ourselves
    if not token:
        print("❌ No oobCode found in URL parameters")
        # Show more detailed error message
        available_params = list(request.args.keys())
        print(f"❌ Available parameters: {available_params}")
        flash(f'Invalid verification link. Missing verification code. Available parameters: {available_params}', 'danger')
        return redirect(url_for('join'))
    
    try:
        # Verify the email using Firebase
        from firebase_auth import verify_email_token
        
        print(f"🔍 Verifying email with oobCode: {token[:20]}...")
        
        verification_result = verify_email_token(token)
        
        if verification_result.get('success'):
            email = verification_result.get('email')
            print(f"✅ Email verified successfully: {email}")
            
            # Check if user already exists in our database
            existing_user = User.query.filter_by(email=email).first()
            
            if existing_user:
                # User exists, mark as email verified and log them in
                print(f"👤 Found existing user: {existing_user.username}")
                existing_user.email_verified = True
                db.session.commit()
                
                session['user_id'] = existing_user.id
                session['user_type'] = 'admin' if existing_user.is_admin else 'user'
                flash('Email verified successfully! Welcome back.', 'success')
                
                if existing_user.is_admin:
                    return redirect(url_for('admin_dashboard'))
                else:
                    return redirect(url_for('dashboard'))
            
            # Check if we have signup data in session
            elif session.get('signup_data'):
                signup_data = session.get('signup_data')
                
                try:
                    # Create the user account now that email is verified
                    birth_date = datetime.strptime(signup_data['birth_date'], '%Y-%m-%d').date()
                    
                    new_user = User(
                        first_name=signup_data['first_name'],
                        last_name=signup_data['last_name'],
                        username=signup_data['username'],
                        email=signup_data['email'],
                        phone_number=signup_data['phone_number'],
                        country_code=signup_data['country_code'],
                        country=signup_data['country'],
                        birth_date=birth_date,
                        gender=signup_data['gender'],
                        password=signup_data['password'],
                        is_admin=signup_data['is_admin'],
                        phone_verified=False,  # Email verified, but phone not required anymore
                        email_verified=True  # User created after email verification
                    )
                    
                    db.session.add(new_user)
                    db.session.commit()
                    
                    # Clear signup data
                    session.pop('signup_data', None)
                    clear_otp_session()
                    
                    # Log the user in
                    session['user_id'] = new_user.id
                    session['user_type'] = 'admin' if new_user.is_admin else 'user'
                    
                    flash('Account created successfully! Welcome to Skill Finesse.', 'success')
                    
                    # Redirect based on user type
                    if new_user.is_admin:
                        return redirect(url_for('admin_dashboard'))
                    else:
                        return redirect(url_for('dashboard'))
                        
                except Exception as e:
                    db.session.rollback()
                    flash(f'Error creating account: {str(e)}', 'danger')
                    return redirect(url_for('join'))
            
            else:
                # No signup data, user might be verifying existing account
                print("⚠️  No signup data found, but email verified")
                flash('Email verified! Please log in to continue.', 'success')
                return redirect(url_for('join'))
        
        else:
            error_msg = verification_result.get('error', 'Unknown error')
            print(f"❌ Email verification failed: {error_msg}")
            
            if 'expired' in error_msg.lower():
                flash('Verification link has expired. Please request a new one.', 'warning')
            elif 'used' in error_msg.lower():
                flash('Verification link has already been used.', 'info')
            else:
                flash('Invalid verification link. Please try again.', 'danger')
            
            return redirect(url_for('join'))
    
    except Exception as e:
        print(f"❌ Verification error: {e}")
        flash('Verification failed. Please try again.', 'danger')
        return redirect(url_for('join'))
    
    # For general email verification (not during signup)
    flash('Email verified successfully!', 'success')
    return redirect(url_for('join'))

@app.route('/reset-password-complete', methods=['GET', 'POST'])
def reset_password_complete():
    """Handle Firebase password reset completion"""
    
    if request.method == 'GET':
        # Debug: Print all URL parameters
        print(f"🔍 Password Reset - All URL parameters: {dict(request.args)}")
        
        # Get the oobCode from URL parameters (Firebase will add it)
        oob_code = request.args.get('oobCode')
        mode = request.args.get('mode')
        
        # Also try alternative parameter names
        if not oob_code:
            oob_code = request.args.get('oob_code')
        if not oob_code:
            oob_code = request.args.get('code')
        if not oob_code:
            oob_code = request.args.get('token')
        
        print(f"🔍 oobCode: {oob_code}")
        print(f"🔍 mode: {mode}")
        
        if not oob_code:
            print("❌ No oobCode found in URL parameters")
            available_params = list(request.args.keys())
            print(f"❌ Available parameters: {available_params}")
            flash('Invalid password reset link. Missing reset code.', 'danger')
            return redirect(url_for('join'))
        
        try:
            # Verify the reset code and get email
            from firebase_auth import verify_password_reset_code
            
            print(f"🔍 Verifying password reset code: {oob_code[:20]}...")
            
            verification_result = verify_password_reset_code(oob_code)
            
            if verification_result.get('success'):
                email = verification_result.get('email', 'your email')
                print(f"✅ Password reset code accepted")
                
                # Store reset info in session for form submission
                session['reset_oob_code'] = oob_code
                session['reset_email'] = email
                
                # Show password reset form
                # Note: The actual email will be determined when the password is reset
                return render_template('reset_password_form.html', 
                                     email='',  # Don't show email yet since we don't know it
                                     show_email=False,  # Hide email field
                                     now=datetime.utcnow())
            else:
                error_msg = verification_result.get('error', 'Unknown error')
                print(f"❌ Password reset verification failed: {error_msg}")
                
                if 'expired' in error_msg.lower():
                    flash('Password reset link has expired. Please request a new one.', 'warning')
                elif 'used' in error_msg.lower():
                    flash('Password reset link has already been used.', 'info')
                else:
                    flash(f'Password reset failed: {error_msg}', 'danger')
                
                return redirect(url_for('join'))
                
        except Exception as e:
            print(f"❌ Password reset verification error: {e}")
            flash('Password reset verification failed. Please try again.', 'danger')
            return redirect(url_for('join'))
    
    elif request.method == 'POST':
        # Handle password reset form submission
        oob_code = session.get('reset_oob_code')
        email = session.get('reset_email')
        
        if not oob_code:
            flash('Session expired. Please click the reset link again.', 'danger')
            return redirect(url_for('join'))
        
        # Verify Cloudflare Turnstile
        turnstile_response = request.form.get('cf-turnstile-response')
        if not verify_turnstile(turnstile_response, request.remote_addr):
            flash('Security check failed. Please try again.', 'danger')
            return render_template('reset_password_form.html', 
                                 email=email,
                                 now=datetime.utcnow())
        
        new_password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if not new_password or not confirm_password:
            flash('Please fill in both password fields.', 'danger')
            return render_template('reset_password_form.html', 
                                 email=email,
                                 now=datetime.utcnow())
        
        if new_password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return render_template('reset_password_form.html', 
                                 email=email,
                                 now=datetime.utcnow())
        
        if len(new_password) < 8:
            flash('Password must be at least 8 characters long.', 'danger')
            return render_template('reset_password_form.html', 
                                 email=email,
                                 now=datetime.utcnow())
        
        try:
            # Complete password reset with Firebase
            from firebase_auth import complete_password_reset
            
            print(f"🔧 Attempting password reset with oobCode: {oob_code[:20]}...")
            print(f"🔧 Session email: {email}")
            
            reset_result = complete_password_reset(oob_code, new_password)
            
            print(f"🔧 Reset result: {reset_result}")
            
            if reset_result.get('success'):
                # Get the actual email from the reset result
                actual_email = reset_result.get('email', email)
                print(f"✅ Password reset completed for: {actual_email}")
                
                # Update password in our database too
                user = User.query.filter_by(email=actual_email).first()
                if user:
                    print(f"📝 Updating password for user: {user.email}")
                    user.password = generate_password_hash(new_password)
                    db.session.commit()
                    print(f"✅ Database password updated for: {actual_email}")
                else:
                    print(f"❌ User not found in database: {actual_email}")
                
                # Clear session data
                session.pop('reset_oob_code', None)
                session.pop('reset_email', None)
                
                flash('Password reset successful! You can now log in with your new password.', 'success')
                return redirect(url_for('join'))
            else:
                error_msg = reset_result.get('error', 'Unknown error')
                print(f"❌ Password reset failed: {error_msg}")
                flash('Password reset failed. Please try again.', 'danger')
                return render_template('reset_password_form.html', 
                                     email=email,
                                     now=datetime.utcnow())
                
        except Exception as e:
            print(f"❌ Password reset completion error: {e}")
            flash('Password reset failed. Please try again.', 'danger')
            return render_template('reset_password_form.html', 
                                 email=email,
                                 now=datetime.utcnow())

@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    # Check if user has verified OTP
    if not session.get('reset_verified') or not session.get('reset_user_id'):
        flash('Please complete verification first.', 'danger')
        return redirect(url_for('join'))
    
    if request.method == 'GET':
        return render_template('reset_password.html', now=datetime.utcnow())
    
    if request.method == 'POST':
        # Verify Cloudflare Turnstile
        turnstile_response = request.form.get('cf-turnstile-response')
        if not verify_turnstile(turnstile_response, request.remote_addr):
            flash('Security check failed. Please try again.', 'danger')
            return redirect(url_for('reset_password'))
        
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('reset_password'))
        
        # Update user's password
        user_id = session.get('reset_user_id')
        user = User.query.get(user_id)
        
        if not user:
            flash('User not found.', 'danger')
            return redirect(url_for('join'))
        
        # Hash and update password
        hashed_password = generate_password_hash(password)
        user.password = hashed_password
        db.session.commit()
        
        # Clean up session
        session.pop('reset_verified', None)
        session.pop('reset_user_id', None)
        clear_otp_session()
        
        flash('Password reset successful! Please sign in with your new password.', 'success')
        return redirect(url_for('join'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    # Redirect to join page
    return redirect(url_for('join'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    # Redirect to join page
    return redirect(url_for('join'))

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('is_admin', None)
    return redirect(url_for('index'))

# Admin routes
@app.route('/admin/get-courses', methods=['GET'])
def admin_get_courses():
    """Get all courses for user assignment"""
    try:
        # Check admin authentication for AJAX requests
        if not session.get('user_id') or not session.get('is_admin'):
            return jsonify({'success': False, 'message': 'Admin authentication required'}), 401
        
        courses = Course.query.all()
        course_list = [{
            'id': course.id,
            'title': course.title,
            'price': float(course.price),
            'category': course.category,
            'image': course.image,
            'instructor_name': course.instructor_name,
            'is_published': course.is_published
        } for course in courses]
        
        return jsonify({
            'success': True,
            'courses': course_list
        })
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error loading courses: {str(e)}'})

@app.route('/admin/get-ebooks', methods=['GET'])
def admin_get_ebooks():
    """Get all ebooks for user assignment"""
    try:
        # Check admin authentication for AJAX requests
        if not session.get('user_id') or not session.get('is_admin'):
            return jsonify({'success': False, 'message': 'Admin authentication required'}), 401
        
        ebooks = Ebook.query.all()
        ebook_list = [{
            'id': ebook.id,
            'title': ebook.name,  # Ebook model uses 'name' field
            'price': float(ebook.price),
            'status': 'Published' if ebook.is_published else 'Draft',
            'cover_image': ebook.cover_image,
            'author': ebook.author,
            'is_published': ebook.is_published
        } for ebook in ebooks]
        
        return jsonify({
            'success': True,
            'ebooks': ebook_list
        })
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error loading ebooks: {str(e)}'})

@app.route('/admin/users/create', methods=['POST'])
@admin_required
def admin_create_user():
    """Create a new user from admin panel"""
    try:
        first_name = request.form.get('first_name', '').strip()
        last_name = request.form.get('last_name', '').strip()
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        phone_number = request.form.get('phone_number', '').strip()
        country_code = request.form.get('country_code', '+880').strip()
        country = request.form.get('country', 'Bangladesh').strip()
        birth_date = request.form.get('birth_date')
        gender = request.form.get('gender', 'Other').strip()
        password = request.form.get('password', '').strip()
        is_admin = request.form.get('is_admin') == 'true'
        
        # Validation
        if not all([first_name, last_name, username, email, password]):
            return jsonify({'success': False, 'message': 'All required fields must be filled'})
        
        # Check if user already exists
        if User.query.filter_by(email=email).first():
            return jsonify({'success': False, 'message': 'User with this email already exists'})
        
        if User.query.filter_by(username=username).first():
            return jsonify({'success': False, 'message': 'Username already taken'})
        
        # Parse birth date
        try:
            if birth_date:
                birth_date = datetime.strptime(birth_date, '%Y-%m-%d').date()
            else:
                birth_date = datetime.strptime('1990-01-01', '%Y-%m-%d').date()
        except ValueError:
            birth_date = datetime.strptime('1990-01-01', '%Y-%m-%d').date()
        
        # Create new user
        new_user = User(
            first_name=first_name,
            last_name=last_name,
            username=username,
            email=email,
            phone_number=phone_number,
            country_code=country_code,
            country=country,
            birth_date=birth_date,
            gender=gender,
            password=generate_password_hash(password),
            is_admin=is_admin,
            email_verified=False
        )
        
        db.session.add(new_user)
        db.session.flush()  # Get the user ID without committing
        
        # Handle course assignments
        selected_courses = request.form.getlist('courses[]')
        for course_id in selected_courses:
            try:
                course_id = int(course_id)
                course = Course.query.get(course_id)
                if course:
                    enrollment = CourseEnrollment(
                        user_id=new_user.id,
                        course_id=course_id,
                        enrolled_at=datetime.utcnow(),
                        progress_percentage=0.0,
                        is_completed=False
                    )
                    db.session.add(enrollment)
            except (ValueError, TypeError):
                continue
        
        # Handle ebook assignments
        selected_ebooks = request.form.getlist('ebooks[]')
        for ebook_id in selected_ebooks:
            try:
                ebook_id = int(ebook_id)
                ebook = Ebook.query.get(ebook_id)
                if ebook:
                    purchase = EbookPurchase(
                        user_id=new_user.id,
                        ebook_id=ebook_id,
                        purchased_at=datetime.utcnow(),
                        total_paid=ebook.price
                    )
                    db.session.add(purchase)
            except (ValueError, TypeError):
                continue
        
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': f'User {first_name} {last_name} created successfully!',
            'user': {
                'id': new_user.id,
                'name': f'{new_user.first_name} {new_user.last_name}',
                'email': new_user.email,
                'is_admin': new_user.is_admin,
                'created_at': new_user.created_at.strftime('%b %d, %Y') if new_user.created_at else 'Today'
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error creating user: {str(e)}'})

@app.route('/admin/users/<int:user_id>/delete', methods=['DELETE'])
@admin_required
def admin_delete_user(user_id):
    """Delete a user from admin panel"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'success': False, 'message': 'User not found'}), 404
        
        # Don't allow deleting the current admin
        if user.id == session['user_id']:
            return jsonify({'success': False, 'message': 'Cannot delete your own account'}), 400
        
        user_name = f"{user.first_name} {user.last_name}"
        
        # Delete all related records manually to avoid foreign key constraint violations
        print(f"🗑️ Deleting user {user_name} (ID: {user_id}) and all related records...")
        
        # Delete course enrollments
        CourseEnrollment.query.filter_by(user_id=user_id).delete()
        print(f"   ✅ Deleted CourseEnrollment records")
        
        # Delete ebook purchases 
        EbookPurchase.query.filter_by(user_id=user_id).delete()
        print(f"   ✅ Deleted EbookPurchase records")
        
        # Delete video lesson progress
        LessonProgress.query.filter_by(user_id=user_id).delete()
        print(f"   ✅ Deleted LessonProgress records")
        
        # Delete old enrollment records (if any)
        Enrollment.query.filter_by(user_id=user_id).delete()
        print(f"   ✅ Deleted Enrollment records")
        
        # Delete payment transactions
        PaymentTransaction.query.filter_by(user_id=user_id).delete()
        print(f"   ✅ Deleted PaymentTransaction records")
        
        # Delete messages (these should have CASCADE but let's be safe)
        Message.query.filter_by(user_id=user_id).delete()
        print(f"   ✅ Deleted Message records")
        
        # Delete the user
        db.session.delete(user)
        db.session.commit()
        
        print(f"   ✅ User {user_name} deleted successfully!")
        
        return jsonify({'success': True, 'message': f'User {user_name} deleted successfully!'})
        
    except Exception as e:
        db.session.rollback()
        print(f"   ❌ Error deleting user: {str(e)}")
        return jsonify({'success': False, 'message': f'Error deleting user: {str(e)}'})

@app.route('/admin/users/<int:user_id>', methods=['GET'])
def admin_get_user(user_id):
    """Get user details for editing"""
    try:
        # Check admin authentication for AJAX requests
        if not session.get('user_id') or not session.get('is_admin'):
            return jsonify({'success': False, 'message': 'Admin authentication required'}), 401
        
        print(f"🔍 Admin requesting user details for user ID: {user_id}")
        user = User.query.get(user_id)
        if not user:
            print(f"❌ User with ID {user_id} not found")
            return jsonify({'success': False, 'message': 'User not found'}), 404
        
        print(f"✅ User found: {user.first_name} {user.last_name}")
        
        user_data = {
            'id': user.id,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'username': user.username,
            'email': user.email,
            'phone_number': user.phone_number,
            'country_code': user.country_code,
            'country': user.country,
            'birth_date': user.birth_date.strftime('%Y-%m-%d') if user.birth_date else '',
            'gender': user.gender,
            'is_admin': user.is_admin
        }
        
        print(f"🔍 Returning user data: {user_data}")
        return jsonify({'success': True, 'user': user_data})
        
    except Exception as e:
        print(f"❌ Error loading user {user_id}: {str(e)}")
        return jsonify({'success': False, 'message': f'Error loading user: {str(e)}'})

@app.route('/admin/users/<int:user_id>/purchases', methods=['GET'])
def admin_get_user_purchases(user_id):
    """Get user's current course enrollments and ebook purchases"""
    try:
        # Check admin authentication for AJAX requests
        if not session.get('user_id') or not session.get('is_admin'):
            return jsonify({'success': False, 'message': 'Admin authentication required'}), 401
        
        user = User.query.get(user_id)
        if not user:
            print(f"❌ User {user_id} not found for purchases")
            return jsonify({'success': False, 'message': 'User not found'}), 404
        
        print(f"🛒 Loading purchases for user: {user.first_name} {user.last_name}")
        
        # Get user's course enrollments
        enrolled_courses = [enrollment.course_id for enrollment in user.course_enrollments]
        print(f"🛒 User has {len(enrolled_courses)} course enrollments: {enrolled_courses}")
        
        # Get user's ebook purchases
        purchased_ebooks = [purchase.ebook_id for purchase in user.ebook_purchases]
        print(f"🛒 User has {len(purchased_ebooks)} ebook purchases: {purchased_ebooks}")
        
        return jsonify({
            'success': True,
            'courses': enrolled_courses,
            'ebooks': purchased_ebooks
        })
        
    except Exception as e:
        print(f"❌ Error loading user {user_id} purchases: {str(e)}")
        return jsonify({'success': False, 'message': f'Error loading user purchases: {str(e)}'})

@app.route('/admin/users/<int:user_id>/update', methods=['POST'])
@admin_required
def admin_update_user(user_id):
    """Update user details"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'success': False, 'message': 'User not found'}), 404
        
        # Get form data
        first_name = request.form.get('first_name', '').strip()
        last_name = request.form.get('last_name', '').strip()
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        phone_number = request.form.get('phone_number', '').strip()
        country = request.form.get('country', 'Bangladesh').strip()
        birth_date = request.form.get('birth_date')
        gender = request.form.get('gender', 'Other').strip()
        password = request.form.get('password', '').strip()
        is_admin = request.form.get('is_admin') == 'true'
        
        # Validation
        if not all([first_name, last_name, username, email]):
            return jsonify({'success': False, 'message': 'All required fields must be filled'})
        
        # Check for duplicates (excluding current user)
        if User.query.filter(User.email == email, User.id != user_id).first():
            return jsonify({'success': False, 'message': 'User with this email already exists'})
        
        if User.query.filter(User.username == username, User.id != user_id).first():
            return jsonify({'success': False, 'message': 'Username already taken'})
        
        # Parse birth date
        try:
            if birth_date:
                birth_date = datetime.strptime(birth_date, '%Y-%m-%d').date()
            else:
                birth_date = user.birth_date  # Keep existing if not provided
        except ValueError:
            birth_date = user.birth_date
        
        # Update user fields
        user.first_name = first_name
        user.last_name = last_name
        user.username = username
        user.email = email
        user.phone_number = phone_number
        user.country = country
        user.birth_date = birth_date
        user.gender = gender
        user.is_admin = is_admin
        
        # Update password if provided
        if password:
            user.password = generate_password_hash(password)
        
        # Handle course enrollment updates
        selected_courses = set(request.form.getlist('courses[]'))
        current_courses = set(str(enrollment.course_id) for enrollment in user.course_enrollments)
        
        # Remove courses that are no longer selected
        for enrollment in list(user.course_enrollments):
            if str(enrollment.course_id) not in selected_courses:
                db.session.delete(enrollment)
        
        # Add new course enrollments
        for course_id_str in selected_courses:
            if course_id_str not in current_courses:
                try:
                    course_id = int(course_id_str)
                    course = Course.query.get(course_id)
                    if course:
                        enrollment = CourseEnrollment(
                            user_id=user.id,
                            course_id=course_id,
                            enrolled_at=datetime.utcnow(),
                            progress_percentage=0.0,
                            is_completed=False
                        )
                        db.session.add(enrollment)
                except (ValueError, TypeError):
                    continue
        
        # Handle ebook purchase updates
        selected_ebooks = set(request.form.getlist('ebooks[]'))
        current_ebooks = set(str(purchase.ebook_id) for purchase in user.ebook_purchases)
        
        # Remove ebook purchases that are no longer selected
        for purchase in list(user.ebook_purchases):
            if str(purchase.ebook_id) not in selected_ebooks:
                db.session.delete(purchase)
        
        # Add new ebook purchases
        for ebook_id_str in selected_ebooks:
            if ebook_id_str not in current_ebooks:
                try:
                    ebook_id = int(ebook_id_str)
                    ebook = Ebook.query.get(ebook_id)
                    if ebook:
                        purchase = EbookPurchase(
                            user_id=user.id,
                            ebook_id=ebook_id,
                            purchased_at=datetime.utcnow(),
                            total_paid=ebook.price
                        )
                        db.session.add(purchase)
                except (ValueError, TypeError):
                    continue
        
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': f'User {first_name} {last_name} updated successfully!',
            'user': {
                'id': user.id,
                'name': f'{user.first_name} {user.last_name}',
                'email': user.email,
                'is_admin': user.is_admin
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error updating user: {str(e)}'})

@app.route('/test_about_cache.html')
def test_about_cache():
    """Test page to check About Section upload without cache issues"""
    with open(os.path.join(os.path.dirname(__file__), 'test_about_cache.html'), 'r') as f:
        return f.read()

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    
    courses = Course.query.filter_by(admin_id=session['user_id']).all()
    users = User.query.filter_by(is_admin=False).all()
    blogs = Blog.query.order_by(Blog.date.desc()).all()
    contact_messages = ContactMessage.query.order_by(ContactMessage.submitted_at.desc()).all()
    ebooks = Ebook.query.filter_by(admin_id=session['user_id']).all()
    ebook_purchases = EbookPurchase.query.all()
    current_user = User.query.get(session['user_id'])
    
    # Calculate real dashboard stats
    total_users = User.query.filter_by(is_admin=False).count()
    total_courses = Course.query.count()
    
    # Get new users today
    today = datetime.now().date()
    new_users_today = User.query.filter(
        User.created_at >= today,
        User.is_admin == False
    ).count()
    
    return render_template('admin/dashboard.html', 
                         courses=courses, 
                         users=users, 
                         blogs=blogs, 
                         contact_messages=contact_messages, 
                         ebooks=ebooks, 
                         ebook_purchases=ebook_purchases, 
                         current_user=current_user, 
                         now=datetime.utcnow(),
                         total_users=total_users,
                         total_courses=total_courses,
                         new_users_today=new_users_today)

# Admin Profile Management Routes
@app.route('/admin/upload-profile-picture', methods=['POST'])
@admin_required
def upload_profile_picture():
    """Upload admin profile picture"""
    try:
        if 'profile_picture' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No image file provided'
            })
        
        file = request.files['profile_picture']
        if file.filename == '':
            return jsonify({
                'success': False,
                'message': 'No file selected'
            })
        
        # Check file type
        allowed_extensions = {'png', 'jpg', 'jpeg', 'webp'}
        file_extension = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
        
        if file_extension not in allowed_extensions:
            return jsonify({
                'success': False,
                'message': 'Invalid file type. Allowed: PNG, JPG, JPEG, WEBP'
            })
        
        # Check file size (2MB max)
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > 2 * 1024 * 1024:  # 2MB
            return jsonify({
                'success': False,
                'message': 'File size exceeds 2MB limit'
            })
        
        # Generate unique filename
        current_user = User.query.get(session['user_id'])
        unique_filename = f"admin_profile_{uuid.uuid4().hex[:8]}_{secure_filename(file.filename)}"
        
        # Create uploads directory if it doesn't exist
        upload_dir = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', 'profiles')
        os.makedirs(upload_dir, exist_ok=True)
        
        # Save file
        upload_path = os.path.join(upload_dir, unique_filename)
        file.save(upload_path)
        
        # Update user profile picture path in database
        current_user.profile_picture = unique_filename
        db.session.commit()
        
        picture_url = url_for('static', filename=f'uploads/profiles/{unique_filename}')
        
        return jsonify({
            'success': True,
            'message': 'Profile picture uploaded successfully',
            'picture_url': picture_url
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Upload failed: {str(e)}'
        })

@app.route('/admin/reset-profile-picture', methods=['POST'])
@admin_required
def reset_profile_picture():
    """Reset admin profile picture to default"""
    try:
        # Reset user's profile picture to None (will use default)
        current_user = User.query.get(session['user_id'])
        current_user.profile_picture = None
        db.session.commit()
        
        default_picture_url = url_for('static', filename='images/admin_profile.png')
        
        return jsonify({
            'success': True,
            'message': 'Profile picture reset to default',
            'picture_url': default_picture_url
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Reset failed: {str(e)}'
        })

@app.route('/admin/update-profile', methods=['POST'])
@admin_required
def update_profile():
    """Update admin profile information"""
    try:
        current_user = User.query.get(session['user_id'])
        
        # Update profile fields
        current_user.first_name = request.form.get('first_name', current_user.first_name)
        current_user.last_name = request.form.get('last_name', current_user.last_name)
        
        # Update phone number if provided
        phone = request.form.get('phone')
        if phone:
            current_user.phone_number = phone
        
        # Update country if provided
        country = request.form.get('country')
        if country:
            current_user.country = country
        
        # Note: timezone handling would require a new field in the User model
        # For now, we'll just ignore it
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Profile updated successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Update failed: {str(e)}'
        })

@app.route('/admin/change-password', methods=['POST'])
@admin_required
def change_password():
    """Change admin password"""
    try:
        current_user = User.query.get(session['user_id'])
        
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate current password
        if not check_password_hash(current_user.password, current_password):
            return jsonify({
                'success': False,
                'message': 'Current password is incorrect'
            })
        
        # Check if new passwords match
        if new_password != confirm_password:
            return jsonify({
                'success': False,
                'message': 'New passwords do not match'
            })
        
        # Update password
        current_user.password = generate_password_hash(new_password)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Password changed successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Password change failed: {str(e)}'
        })

# Site Settings Management Routes
@app.route('/admin/get-site-settings')
@admin_required
def get_site_settings():
    """Get current site settings"""
    try:
        site_settings = SiteSettings.get_all_settings()
        return jsonify({
            'success': True,
            'settings': site_settings
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error loading site settings: {str(e)}'
        })

@app.route('/admin/get-default-site-settings')
@admin_required
def get_default_site_settings():
    """Get default site settings"""
    try:
        default_settings = SiteSettings.get_default_settings()
        return jsonify({
            'success': True,
            'settings': default_settings
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error loading default settings: {str(e)}'
        })

@app.route('/admin/upload-site-image', methods=['POST'])
@admin_required
def upload_site_image():
    """Upload images for site settings"""
    try:
        if 'image' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No image file provided'
            })
        
        file = request.files['image']
        if file.filename == '':
            return jsonify({
                'success': False,
                'message': 'No file selected'
            })
        
        # Check file type
        allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
        file_extension = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
        
        if file_extension not in allowed_extensions:
            return jsonify({
                'success': False,
                'message': 'Invalid file type. Allowed: PNG, JPG, JPEG, GIF, WEBP'
            })
        
        # Check file size (500KB max for logos)
        max_size = 500 * 1024  # 500KB
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > max_size:
            return jsonify({
                'success': False,
                'message': 'Image size must be less than 500KB'
            })
        
        # Generate unique filename
        unique_filename = f"site_{uuid.uuid4().hex[:8]}_{secure_filename(file.filename)}"
        
        # Save file
        upload_path = os.path.join(LOCAL_STATIC_FOLDER, 'images', unique_filename)
        file.save(upload_path)
        
        return jsonify({
            'success': True,
            'filename': unique_filename,
            'message': 'Image uploaded successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Upload failed: {str(e)}'
        })

@app.route('/admin/save-site-settings', methods=['POST'])
@admin_required
def save_site_settings():
    """Save site settings"""
    try:
        section = request.form.get('section')
        admin_id = session['user_id']
        
        if section == 'logo':
            # Deactivate existing logo settings
            SiteSettings.query.filter_by(setting_name='general', is_active=True).update({'is_active': False})
            
            # Create new logo settings
            logo_settings = SiteSettings(
                setting_name='general',
                logo=request.form.get('logo'),
                logo_alt=request.form.get('logo_alt'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(logo_settings)
            
        elif section == 'footer':
            # Deactivate existing footer settings
            SiteSettings.query.filter_by(setting_name='footer', is_active=True).update({'is_active': False})
            
            # Create new footer settings
            footer_settings = SiteSettings(
                setting_name='footer',
                footer_description=request.form.get('footer_description'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(footer_settings)
            
        elif section == 'social':
            # Deactivate existing social settings
            SiteSettings.query.filter_by(setting_name='social', is_active=True).update({'is_active': False})
            
            # Create new social settings
            social_settings = SiteSettings(
                setting_name='social',
                social_links=request.form.get('social_links'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(social_settings)
            
        elif section == 'contact':
            # Deactivate existing contact settings
            SiteSettings.query.filter_by(setting_name='contact', is_active=True).update({'is_active': False})
            
            # Create new contact settings
            contact_settings = SiteSettings(
                setting_name='contact',
                contact_info=request.form.get('contact_info'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(contact_settings)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'{section.capitalize()} settings saved successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error saving settings: {str(e)}'
        })

@app.route('/admin/reset-site-settings', methods=['POST'])
@admin_required
def reset_site_settings():
    """Reset site settings to defaults"""
    try:
        # Deactivate all existing settings
        SiteSettings.query.update({'is_active': False})
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'All site settings reset to defaults successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error resetting settings: {str(e)}'
        })

@app.route('/admin/courses', methods=['GET'])
def admin_courses():
    if not session.get('user_id') or not session.get('is_admin'):
        return redirect(url_for('login'))
    
    courses = Course.query.filter_by(admin_id=session['user_id']).all()
    current_user = User.query.get(session['user_id'])
    return render_template('admin/courses.html', courses=courses, current_user=current_user, now=datetime.utcnow())

@app.route('/admin/course/add', methods=['GET', 'POST'])
def admin_add_course():
    if not session.get('user_id') or not session.get('is_admin'):
        return redirect(url_for('login'))
    
    current_user = User.query.get(session['user_id'])
    
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        price = float(request.form.get('price'))
        
        # Handle image upload
        image = request.files.get('image')
        image_filename = None
        
        if image and image.filename:
            image_filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{image.filename}"
            image.save(os.path.join(LOCAL_STATIC_FOLDER, 'uploads', image_filename))
        
        new_course = Course(
            title=title,
            description=description,
            price=price,
            image=image_filename,
            admin_id=session['user_id'],
            is_published=True  # Auto-publish courses created through admin
        )
        
        db.session.add(new_course)
        db.session.commit()
        
        flash('Course added successfully!', 'success')
        return redirect(url_for('admin_courses'))
    
    return render_template('admin/add_course.html', current_user=current_user, now=datetime.utcnow())

@app.route('/admin/course/edit/<int:course_id>', methods=['GET', 'POST'])
def admin_edit_course(course_id):
    if not session.get('user_id') or not session.get('is_admin'):
        return redirect(url_for('login'))
    
    course = Course.query.get_or_404(course_id)
    current_user = User.query.get(session['user_id'])
    
    if course.admin_id != session['user_id']:
        flash('Unauthorized', 'danger')
        return redirect(url_for('admin_courses'))
    
    if request.method == 'POST':
        course.title = request.form.get('title')
        course.description = request.form.get('description')
        course.price = float(request.form.get('price'))
        
        # Handle image upload
        image = request.files.get('image')
        
        if image and image.filename:
            # Delete old image if exists
            if course.image:
                old_image_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', course.image)
                if os.path.exists(old_image_path):
                    os.remove(old_image_path)
            
            image_filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{image.filename}"
            image.save(os.path.join(LOCAL_STATIC_FOLDER, 'uploads', image_filename))
            course.image = image_filename
        
        db.session.commit()
        
        flash('Course updated successfully!', 'success')
        return redirect(url_for('admin_courses'))
    
    return render_template('admin/edit_course.html', course=course, current_user=current_user, now=datetime.utcnow())

# Course Creation Route
@app.route('/admin/courses/create', methods=['GET', 'POST'])
def admin_create_course():
    if not session.get('user_id') or not session.get('is_admin'):
        if request.method == 'GET':
            return redirect(url_for('login'))
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    current_user = User.query.get(session['user_id'])
    
    # Handle GET request - redirect to admin dashboard
    if request.method == 'GET':
        return redirect(url_for('admin_dashboard'))
    
    # Handle POST request - create course
    try:
        title = request.form.get('title')
        description = request.form.get('description')
        price = float(request.form.get('price', 0))
        category = request.form.get('category')
        custom_category = request.form.get('custom_category')
        # Public discount handling
        public_discount_percent = request.form.get('public_discount_percent')
        public_discount_percent = float(public_discount_percent) if public_discount_percent else 0
        # Multiple private coupons handling (same format as ebook creation)
        coupons_data = {}
        for key in request.form.keys():
            if key.startswith('coupons[') and key.endswith('][code]'):
                coupon_index = key.split('[')[1].split(']')[0]
                coupons_data[coupon_index] = {
                    'code': request.form.get(key),
                    'discount_percent': request.form.get(f'coupons[{coupon_index}][discount_percent]'),
                    'usage_limit': request.form.get(f'coupons[{coupon_index}][usage_limit]'),
                    'valid_from': request.form.get(f'coupons[{coupon_index}][valid_from]'),
                    'valid_until': request.form.get(f'coupons[{coupon_index}][valid_until]'),
                    'is_active': f'coupons[{coupon_index}][is_active]' in request.form
                }
        instructor_name = request.form.get('instructor_name')
        about_course = request.form.get('about_course')
        what_youll_learn = request.form.get('what_youll_learn')
        course_requirements = request.form.get('course_requirements')
        instructor_bio = request.form.get('instructor_bio')
        
        # Use custom category if "Other" is selected and custom_category is provided
        if category == "Other" and custom_category:
            category = custom_category
        
        # Handle course image upload to Bunny CDN
        image = request.files.get('image')
        image_filename = None
        
        if image and image.filename:
            try:
                from bunny_cdn import bunny_cdn
                
                # Upload course image to Bunny CDN
                upload_result = bunny_cdn.upload_course_file(image, image.filename, 'image')
                
                if upload_result['success']:
                    # Store the Bunny CDN filename
                    image_filename = upload_result['filename']
                    print(f"✅ Course image uploaded to Bunny CDN: {upload_result['url']}")
                else:
                    print(f"❌ Failed to upload course image to Bunny CDN: {upload_result['error']}")
                    # Fallback to local storage
                    uploads_dir = os.path.join(LOCAL_STATIC_FOLDER, 'uploads')
                    if not os.path.exists(uploads_dir):
                        os.makedirs(uploads_dir)
                    
                    image_filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{secure_filename(image.filename)}"
                    image.save(os.path.join(uploads_dir, image_filename))
                    
            except Exception as e:
                print(f"❌ Error uploading course image to Bunny CDN: {str(e)}")
                # Fallback to local storage
                uploads_dir = os.path.join(LOCAL_STATIC_FOLDER, 'uploads')
                if not os.path.exists(uploads_dir):
                    os.makedirs(uploads_dir)
                
                image_filename = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{secure_filename(image.filename)}"
                image.save(os.path.join(uploads_dir, image_filename))
        
        # Handle instructor image upload to Bunny CDN
        instructor_image = request.files.get('instructor_image')
        instructor_image_filename = None
        
        if instructor_image and instructor_image.filename:
            try:
                from bunny_cdn import bunny_cdn
                
                # Upload instructor image to Bunny CDN
                upload_result = bunny_cdn.upload_course_file(instructor_image, instructor_image.filename, 'image')
                
                if upload_result['success']:
                    # Store the Bunny CDN filename
                    instructor_image_filename = upload_result['filename']
                    print(f"✅ Instructor image uploaded to Bunny CDN: {upload_result['url']}")
                else:
                    print(f"❌ Failed to upload instructor image to Bunny CDN: {upload_result['error']}")
                    # Fallback to local storage
                    uploads_dir = os.path.join(LOCAL_STATIC_FOLDER, 'uploads')
                    if not os.path.exists(uploads_dir):
                        os.makedirs(uploads_dir)
                    
                    instructor_image_filename = f"instructor_{datetime.now().strftime('%Y%m%d%H%M%S')}_{secure_filename(instructor_image.filename)}"
                    instructor_image.save(os.path.join(uploads_dir, instructor_image_filename))
                    
            except Exception as e:
                print(f"❌ Error uploading instructor image to Bunny CDN: {str(e)}")
                # Fallback to local storage
                uploads_dir = os.path.join(LOCAL_STATIC_FOLDER, 'uploads')
                if not os.path.exists(uploads_dir):
                    os.makedirs(uploads_dir)
                
                instructor_image_filename = f"instructor_{datetime.now().strftime('%Y%m%d%H%M%S')}_{secure_filename(instructor_image.filename)}"
                instructor_image.save(os.path.join(uploads_dir, instructor_image_filename))
        
        # Check if this is a draft
        is_draft = request.form.get('is_draft', 'false').lower() == 'true'
        
        # Calculate discounted price if public discount is set
        discounted_price = price * (100 - public_discount_percent) / 100 if public_discount_percent > 0 else price
        
        new_course = Course(
            title=title,
            description=description,
            price=price,
            discount_percent=public_discount_percent,
            discounted_price=discounted_price,
            image=image_filename,
            category=category,
            instructor_name=instructor_name,
            instructor_image=instructor_image_filename,
            about_course=about_course,
            what_youll_learn=what_youll_learn,
            course_requirements=course_requirements,
            instructor_bio=instructor_bio,
            admin_id=session['user_id'],
            is_published=not is_draft  # If it's a draft, is_published is False
        )
        
        db.session.add(new_course)
        db.session.flush()  # Flush to get the course ID
        
        # Create private coupons
        for coupon_data in coupons_data.values():
            if coupon_data['code'] and coupon_data['discount_percent']:
                try:
                    # Parse datetime fields if provided
                    valid_from = None
                    valid_until = None
                    
                    if coupon_data.get('valid_from') and coupon_data['valid_from'].strip():
                        try:
                            valid_from = datetime.strptime(coupon_data['valid_from'], '%Y-%m-%dT%H:%M')
                            print(f"Course Create - Parsed valid_from: {coupon_data['valid_from']} -> {valid_from}")
                        except Exception as e:
                            print(f"Course Create - Error parsing valid_from '{coupon_data['valid_from']}': {e}")
                            valid_from = None
                    
                    if coupon_data.get('valid_until') and coupon_data['valid_until'].strip():
                        try:
                            valid_until = datetime.strptime(coupon_data['valid_until'], '%Y-%m-%dT%H:%M')
                            print(f"Course Create - Parsed valid_until: {coupon_data['valid_until']} -> {valid_until}")
                        except Exception as e:
                            print(f"Course Create - Error parsing valid_until '{coupon_data['valid_until']}': {e}")
                            valid_until = None
                    
                    new_coupon = CourseCoupon(
                        course_id=new_course.id,
                        code=coupon_data['code'].upper(),
                        discount_percent=int(coupon_data['discount_percent']),
                        usage_limit=int(coupon_data['usage_limit']) if coupon_data.get('usage_limit') else None,
                        valid_from=valid_from,
                        valid_until=valid_until,
                        is_active=coupon_data.get('is_active', True)
                    )
                    db.session.add(new_coupon)
                    print(f"Course Create - Created coupon: {coupon_data['code']} with dates: {valid_from} to {valid_until}")
                except Exception as coupon_error:
                    print(f"Error creating coupon {coupon_data['code']}: {coupon_error}")
                    continue
        
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Course created successfully!', 'course_id': new_course.id})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/courses/list')
def admin_courses_list():
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        status = request.args.get('status')
        current_admin_id = session['user_id']
        
        print(f"🔍 Admin courses list requested by admin ID: {current_admin_id}")
        
        # Show only courses created by current admin
        query = Course.query.filter_by(admin_id=current_admin_id)
        
        print(f"🔍 Query: {query}")
        all_courses_count = Course.query.count()
        print(f"🔍 Total courses in database: {all_courses_count}")
        admin_courses_count = query.count()
        print(f"🔍 Courses for admin {current_admin_id}: {admin_courses_count}")
        
        if status == 'published':
            query = query.filter_by(is_published=True)
        elif status == 'draft':
            query = query.filter_by(is_published=False)
        
        courses = query.order_by(Course.created_at.desc()).all()
        
        courses_data = []
        for course in courses:
            courses_data.append({
                'id': course.id,
                'title': course.title,
                'description': course.description,
                'price': course.price,
                'image': course.image,
                'category': course.category,
                'coupon': course.coupon,
                'coupon_discount': course.coupon_discount,
                'discount_percent': course.discount_percent or 0,
                'discounted_price': course.discounted_price or course.price,
                'instructor_name': course.instructor_name,
                'instructor_image': course.instructor_image,
                'about_course': course.about_course,
                'what_youll_learn': course.what_youll_learn,
                'course_requirements': course.course_requirements,
                'instructor_bio': course.instructor_bio,
                'is_published': course.is_published,
                'created_at': course.created_at.isoformat(),
                'enrollments_count': len(course.enrollments)
            })
        
        print(f"🔍 Returning {len(courses_data)} courses to frontend")
        return jsonify({'success': True, 'courses': courses_data})
        
    except Exception as e:
        print(f"❌ Error in admin_courses_list: {str(e)}")
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/courses/<int:course_id>')
def admin_get_course(course_id):
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        # Allow any admin to edit any course
        course = Course.query.filter_by(id=course_id).first()
        
        if not course:
            return jsonify({'success': False, 'message': 'Course not found'}), 404
        
        # Get associated coupons
        coupons = CourseCoupon.query.filter_by(course_id=course.id).all()
        coupons_data = []
        for coupon in coupons:
            coupons_data.append({
                'id': coupon.id,
                'code': coupon.code,
                'discount_percent': coupon.discount_percent,
                'usage_limit': coupon.usage_limit,
                'usage_count': coupon.used_count,
                'valid_from': coupon.valid_from.strftime('%Y-%m-%dT%H:%M') if coupon.valid_from else None,
                'valid_until': coupon.valid_until.strftime('%Y-%m-%dT%H:%M') if coupon.valid_until else None,
                'is_active': coupon.is_active
            })
        
        course_data = {
            'id': course.id,
            'title': course.title,
            'description': course.description,
            'price': course.price,
            'discount_percent': getattr(course, 'discount_percent', 0),
            'discounted_price': getattr(course, 'discounted_price', course.price),
            'image': course.image,
            'category': course.category,
            'instructor_name': course.instructor_name,
            'instructor_image': course.instructor_image,
            'about_course': course.about_course,
            'what_youll_learn': course.what_youll_learn,
            'course_requirements': course.course_requirements,
            'instructor_bio': course.instructor_bio,
            'is_published': course.is_published,
            'created_at': course.created_at.isoformat(),
            'enrollments_count': len(course.enrollments),
            'coupons': coupons_data
        }
        
        return jsonify({'success': True, 'course': course_data})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/admin/courses/<int:course_id>/update', methods=['POST'])
def admin_update_course(course_id):
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        # Allow any admin to edit any course
        course = Course.query.filter_by(id=course_id).first()
        
        if not course:
            return jsonify({'success': False, 'message': 'Course not found'}), 404
        
        # Update course fields
        course.title = request.form.get('title')
        course.description = request.form.get('description')
        course.price = float(request.form.get('price', 0))
        category = request.form.get('category')
        custom_category = request.form.get('custom_category')
        
        # Use custom category if "Other" is selected and custom_category is provided
        if category == "Other" and custom_category:
            course.category = custom_category
        else:
            course.category = category
        
        # Public discount handling
        public_discount_percent = request.form.get('public_discount_percent')
        public_discount_percent = float(public_discount_percent) if public_discount_percent else 0
        # Multiple private coupons handling (same format as ebook creation)
        coupons_data = {}
        for key in request.form.keys():
            if key.startswith('coupons[') and key.endswith('][code]'):
                coupon_index = key.split('[')[1].split(']')[0]
                coupons_data[coupon_index] = {
                    'code': request.form.get(key),
                    'discount_percent': request.form.get(f'coupons[{coupon_index}][discount_percent]'),
                    'usage_limit': request.form.get(f'coupons[{coupon_index}][usage_limit]'),
                    'valid_from': request.form.get(f'coupons[{coupon_index}][valid_from]'),
                    'valid_until': request.form.get(f'coupons[{coupon_index}][valid_until]'),
                    'is_active': f'coupons[{coupon_index}][is_active]' in request.form
                }
            
        # Calculate discounted price if public discount is set
        discounted_price = course.price * (100 - public_discount_percent) / 100 if public_discount_percent > 0 else course.price
        course.discount_percent = public_discount_percent
        course.discounted_price = discounted_price
        
        course.instructor_name = request.form.get('instructor_name')
        course.about_course = request.form.get('about_course')
        course.what_youll_learn = request.form.get('what_youll_learn')
        course.course_requirements = request.form.get('course_requirements')
        course.instructor_bio = request.form.get('instructor_bio')
        
        # Handle course image upload to Bunny CDN
        image = request.files.get('image')
        
        if image and image.filename:
            try:
                from bunny_cdn import bunny_cdn
                
                # Upload course image to Bunny CDN courses folder
                upload_result = bunny_cdn.upload_course_file(image, image.filename, 'image')
                
                if upload_result['success']:
                    # Store the Bunny CDN filename
                    course.image = upload_result['filename']
                    print(f"✅ Course image uploaded to Bunny CDN: {upload_result['url']}")
                else:
                    print(f"❌ Failed to upload course image to Bunny CDN: {upload_result['error']}")
                    # Fallback - just store the filename reference
                    course.image = f"{course.id}_{int(time.time())}.{image.filename.split('.')[-1]}"
                    
            except Exception as e:
                print(f"❌ Error uploading course image to Bunny CDN: {str(e)}")
                # Fallback - just store the filename reference
                import time
                course.image = f"{course.id}_{int(time.time())}.{image.filename.split('.')[-1]}" 
        
        # Handle instructor image upload to Bunny CDN
        instructor_image = request.files.get('instructor_image')
        
        if instructor_image and instructor_image.filename:
            try:
                from bunny_cdn import bunny_cdn
                
                # Upload instructor image to Bunny CDN courses folder
                upload_result = bunny_cdn.upload_course_file(instructor_image, instructor_image.filename, 'image')
                
                if upload_result['success']:
                    # Store the Bunny CDN filename
                    course.instructor_image = upload_result['filename']
                    print(f"✅ Instructor image uploaded to Bunny CDN: {upload_result['url']}")
                else:
                    print(f"❌ Failed to upload instructor image to Bunny CDN: {upload_result['error']}")
                    # Fallback - just store the filename reference
                    course.instructor_image = f"instructor_{int(time.time())}.{instructor_image.filename.split('.')[-1]}"
                    
            except Exception as e:
                print(f"❌ Error uploading instructor image to Bunny CDN: {str(e)}")
                # Fallback - just store the filename reference  
                import time
                course.instructor_image = f"instructor_{int(time.time())}.{instructor_image.filename.split('.')[-1]}" 
        
        # Check if this is a draft update
        is_draft = request.form.get('is_draft', 'false').lower() == 'true'
        if 'is_draft' in request.form:
            course.is_published = not is_draft
        
        # Delete existing coupons for this course
        CourseCoupon.query.filter_by(course_id=course.id).delete()
        
        # Create new private coupons
        for coupon_data in coupons_data.values():
            if coupon_data['code'] and coupon_data['discount_percent']:
                try:
                    # Parse datetime fields if provided
                    valid_from = None
                    valid_until = None
                    
                    if coupon_data.get('valid_from') and coupon_data['valid_from'].strip():
                        try:
                            valid_from = datetime.strptime(coupon_data['valid_from'], '%Y-%m-%dT%H:%M')
                            print(f"Course Update - Parsed valid_from: {coupon_data['valid_from']} -> {valid_from}")
                        except Exception as e:
                            print(f"Course Update - Error parsing valid_from '{coupon_data['valid_from']}': {e}")
                            valid_from = None
                    
                    if coupon_data.get('valid_until') and coupon_data['valid_until'].strip():
                        try:
                            valid_until = datetime.strptime(coupon_data['valid_until'], '%Y-%m-%dT%H:%M')
                            print(f"Course Update - Parsed valid_until: {coupon_data['valid_until']} -> {valid_until}")
                        except Exception as e:
                            print(f"Course Update - Error parsing valid_until '{coupon_data['valid_until']}': {e}")
                            valid_until = None
                    
                    new_coupon = CourseCoupon(
                        course_id=course.id,
                        code=coupon_data['code'].upper(),
                        discount_percent=int(coupon_data['discount_percent']),
                        usage_limit=int(coupon_data['usage_limit']) if coupon_data.get('usage_limit') else None,
                        valid_from=valid_from,
                        valid_until=valid_until,
                        is_active=coupon_data.get('is_active', True)
                    )
                    db.session.add(new_coupon)
                except Exception as coupon_error:
                    print(f"Error creating course coupon {coupon_data['code']}: {coupon_error}")
                    continue
        
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Course updated successfully!'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/courses/<int:course_id>/publish', methods=['POST'])
def admin_publish_course(course_id):
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        # Allow any admin to edit any course
        course = Course.query.filter_by(id=course_id).first()
        
        if not course:
            return jsonify({'success': False, 'message': 'Course not found'}), 404
        
        course.is_published = True
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Course published successfully!'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/courses/<int:course_id>/unpublish', methods=['POST'])
def admin_unpublish_course(course_id):
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        # Allow any admin to edit any course
        course = Course.query.filter_by(id=course_id).first()
        
        if not course:
            return jsonify({'success': False, 'message': 'Course not found'}), 404
        
        course.is_published = False
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Course unpublished successfully!'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/courses/<int:course_id>/delete', methods=['DELETE'])
def admin_delete_course(course_id):
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        # Allow any admin to edit any course
        course = Course.query.filter_by(id=course_id).first()
        
        if not course:
            return jsonify({'success': False, 'message': 'Course not found'}), 404
        
        # Store image info before deletion
        course_image = course.image
        instructor_image = course.instructor_image
        
        # Delete enrollments first to avoid foreign key issues
        db.session.execute(db.text('DELETE FROM course_enrollment WHERE course_id = :course_id'), {'course_id': course_id})
        
        # Delete the course using raw SQL to avoid relationship issues
        db.session.execute(db.text('DELETE FROM course WHERE id = :course_id'), {'course_id': course_id})
        
        # Delete associated images if they exist
        if course_image:
            image_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', course_image)
            if os.path.exists(image_path):
                os.remove(image_path)
        
        if instructor_image:
            instructor_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', instructor_image)
            if os.path.exists(instructor_path):
                os.remove(instructor_path)
        
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Course deleted successfully!'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/courses/api')
def admin_courses_api():
    """API endpoint to get courses in JSON format for course upload section"""
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        courses = Course.query.filter_by(admin_id=session['user_id']).all()
        courses_data = []
        
        for course in courses:
            courses_data.append({
                'id': course.id,
                'title': course.title,
                'description': course.description,
                'price': course.price,
                'category': course.category,
                'is_published': course.is_published,
                'created_at': course.created_at.strftime('%Y-%m-%d') if course.created_at else None,
                'enrollments_count': len(course.enrollments) if hasattr(course, 'enrollments') else 0
            })
        
        return jsonify({
            'success': True,
            'courses': courses_data
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/admin/courses/stats')
def admin_course_stats():
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        total_courses = Course.query.filter_by(admin_id=session['user_id']).count()
        published_courses = Course.query.filter_by(admin_id=session['user_id'], is_published=True).count()
        draft_courses = Course.query.filter_by(admin_id=session['user_id'], is_published=False).count()
        
        # Get total enrollments for admin's courses
        admin_courses = Course.query.filter_by(admin_id=session['user_id']).all()
        total_enrollments = sum(len(course.enrollments) for course in admin_courses)
        
        stats = {
            'total': total_courses,
            'published': published_courses,
            'drafts': draft_courses,
            'enrollments': total_enrollments
        }
        
        return jsonify({'success': True, 'stats': stats})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Discount and Coupon Management API Routes
@app.route('/admin/ebooks/list')
def admin_ebooks_list():
    """API endpoint to get ebooks in format expected by discount_coupon.html"""
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        current_admin_id = session['user_id']
        
        # Show only ebooks created by current admin
        ebooks = Ebook.query.filter_by(admin_id=current_admin_id).order_by(Ebook.created_at.desc()).all()
        
        ebooks_data = []
        for ebook in ebooks:
            ebooks_data.append({
                'id': ebook.id,
                'name': ebook.name,  # Ebook model uses 'name' field
                'author': ebook.author,
                'description': ebook.description,
                'price': ebook.price,
                'cover_image': ebook.cover_image,
                'discount_percent': ebook.discount_percent or 0,
                'discounted_price': ebook.discounted_price or ebook.price,
                'is_published': ebook.is_published,
                'created_at': ebook.created_at.isoformat(),
                'category': ebook.category
            })
        
        return jsonify({'success': True, 'ebooks': ebooks_data})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/courses/<int:course_id>/discount', methods=['POST'])
def admin_update_course_discount(course_id):
    """Update public discount for a course"""
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        course = Course.query.get(course_id)
        if not course:
            return jsonify({'success': False, 'message': 'Course not found'}), 404
        
        discount_percent = float(request.form.get('discount_percent', 0))
        
        if discount_percent < 0 or discount_percent > 100:
            return jsonify({'success': False, 'message': 'Discount must be between 0 and 100'}), 400
        
        course.discount_percent = discount_percent
        if discount_percent > 0:
            course.discounted_price = course.price * (1 - discount_percent / 100)
        else:
            course.discounted_price = course.price
        
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Course discount updated successfully',
            'discounted_price': course.discounted_price
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/ebooks/<int:ebook_id>/discount', methods=['POST'])
def admin_update_ebook_discount(ebook_id):
    """Update public discount for an ebook"""
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        ebook = Ebook.query.get(ebook_id)
        if not ebook:
            return jsonify({'success': False, 'message': 'Ebook not found'}), 404
        
        discount_percent = float(request.form.get('discount_percent', 0))
        
        if discount_percent < 0 or discount_percent > 100:
            return jsonify({'success': False, 'message': 'Discount must be between 0 and 100'}), 400
        
        ebook.discount_percent = discount_percent
        if discount_percent > 0:
            ebook.discounted_price = ebook.price * (1 - discount_percent / 100)
        else:
            ebook.discounted_price = ebook.price
        
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Ebook discount updated successfully',
            'discounted_price': ebook.discounted_price
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/courses/<int:course_id>/coupons', methods=['POST'])
def admin_create_course_coupon(course_id):
    """Create a new coupon for a course"""
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        course = Course.query.get(course_id)
        if not course:
            return jsonify({'success': False, 'message': 'Course not found'}), 404
        
        data = request.get_json()
        code = data.get('code', '').strip().upper()
        discount_percent = float(data.get('discount_percent', 0))
        usage_limit = data.get('usage_limit')
        valid_until = data.get('valid_until')
        
        if not code:
            return jsonify({'success': False, 'message': 'Coupon code is required'}), 400
        
        if discount_percent <= 0 or discount_percent > 100:
            return jsonify({'success': False, 'message': 'Discount must be between 1 and 100'}), 400
        
        # Check if coupon code already exists for this course
        existing_coupon = CourseCoupon.query.filter_by(course_id=course_id, code=code).first()
        if existing_coupon:
            return jsonify({'success': False, 'message': 'Coupon code already exists for this course'}), 400
        
        # Create new coupon
        coupon = CourseCoupon(
            course_id=course_id,
            code=code,
            discount_percent=discount_percent,
            usage_limit=int(usage_limit) if usage_limit else None,
            valid_until=datetime.fromisoformat(valid_until) if valid_until else None
        )
        
        db.session.add(coupon)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Coupon created successfully',
            'coupon': {
                'id': coupon.id,
                'code': coupon.code,
                'discount_percent': coupon.discount_percent,
                'is_active': coupon.is_active,
                'usage_limit': coupon.usage_limit,
                'used_count': coupon.used_count,
                'valid_from': coupon.valid_from.isoformat(),
                'valid_until': coupon.valid_until.isoformat() if coupon.valid_until else None
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/ebooks/<int:ebook_id>/coupons', methods=['POST'])
def admin_create_ebook_coupon(ebook_id):
    """Create a new coupon for an ebook"""
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        ebook = Ebook.query.get(ebook_id)
        if not ebook:
            return jsonify({'success': False, 'message': 'Ebook not found'}), 404
        
        data = request.get_json()
        code = data.get('code', '').strip().upper()
        discount_percent = float(data.get('discount_percent', 0))
        usage_limit = data.get('usage_limit')
        valid_until = data.get('valid_until')
        
        if not code:
            return jsonify({'success': False, 'message': 'Coupon code is required'}), 400
        
        if discount_percent <= 0 or discount_percent > 100:
            return jsonify({'success': False, 'message': 'Discount must be between 1 and 100'}), 400
        
        # Check if coupon code already exists for this ebook
        existing_coupon = EbookCoupon.query.filter_by(ebook_id=ebook_id, code=code).first()
        if existing_coupon:
            return jsonify({'success': False, 'message': 'Coupon code already exists for this ebook'}), 400
        
        # Create new coupon
        coupon = EbookCoupon(
            ebook_id=ebook_id,
            code=code,
            discount_percent=discount_percent,
            usage_limit=int(usage_limit) if usage_limit else None,
            valid_until=datetime.fromisoformat(valid_until) if valid_until else None
        )
        
        db.session.add(coupon)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Coupon created successfully',
            'coupon': {
                'id': coupon.id,
                'code': coupon.code,
                'discount_percent': coupon.discount_percent,
                'is_active': coupon.is_active,
                'usage_limit': coupon.usage_limit,
                'used_count': coupon.used_count,
                'valid_from': coupon.valid_from.isoformat(),
                'valid_until': coupon.valid_until.isoformat() if coupon.valid_until else None
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/coupons/<int:coupon_id>/edit', methods=['PUT'])
def admin_edit_coupon(coupon_id):
    """Edit an existing coupon (works for both course and ebook coupons)"""
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        coupon_type = data.get('type')  # 'course' or 'ebook'
        
        if coupon_type == 'course':
            coupon = CourseCoupon.query.get(coupon_id)
        elif coupon_type == 'ebook':
            coupon = EbookCoupon.query.get(coupon_id)
        else:
            return jsonify({'success': False, 'message': 'Invalid coupon type'}), 400
        
        if not coupon:
            return jsonify({'success': False, 'message': 'Coupon not found'}), 404
        
        # Update coupon fields
        if 'discount_percent' in data:
            discount_percent = float(data['discount_percent'])
            if discount_percent <= 0 or discount_percent > 100:
                return jsonify({'success': False, 'message': 'Discount must be between 1 and 100'}), 400
            coupon.discount_percent = discount_percent
        
        if 'is_active' in data:
            coupon.is_active = bool(data['is_active'])
        
        if 'usage_limit' in data:
            coupon.usage_limit = int(data['usage_limit']) if data['usage_limit'] else None
        
        if 'valid_until' in data:
            coupon.valid_until = datetime.fromisoformat(data['valid_until']) if data['valid_until'] else None
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Coupon updated successfully',
            'coupon': {
                'id': coupon.id,
                'code': coupon.code,
                'discount_percent': coupon.discount_percent,
                'is_active': coupon.is_active,
                'usage_limit': coupon.usage_limit,
                'used_count': coupon.used_count,
                'valid_from': coupon.valid_from.isoformat(),
                'valid_until': coupon.valid_until.isoformat() if coupon.valid_until else None
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/coupons/<int:coupon_id>/delete', methods=['DELETE'])
def admin_delete_coupon(coupon_id):
    """Delete a coupon (works for both course and ebook coupons)"""
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        coupon_type = request.args.get('type')  # 'course' or 'ebook'
        
        if coupon_type == 'course':
            coupon = CourseCoupon.query.get(coupon_id)
        elif coupon_type == 'ebook':
            coupon = EbookCoupon.query.get(coupon_id)
        else:
            return jsonify({'success': False, 'message': 'Invalid coupon type'}), 400
        
        if not coupon:
            return jsonify({'success': False, 'message': 'Coupon not found'}), 404
        
        db.session.delete(coupon)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Coupon deleted successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/chat')
def admin_chat():
    if not session.get('user_id') or not session.get('is_admin'):
        return redirect(url_for('login'))
    
    users = User.query.filter_by(is_admin=False).all()
    current_user = User.query.get(session['user_id'])
    return render_template('admin/chat.html', users=users, current_user=current_user, now=datetime.utcnow())

@app.route('/admin/chat/<int:user_id>')
def admin_chat_user(user_id):
    if not session.get('user_id') or not session.get('is_admin'):
        return redirect(url_for('login'))
    
    user = User.query.get_or_404(user_id)
    current_user = User.query.get(session['user_id'])
    messages = Message.query.filter(
        ((Message.user_id == user_id) & (Message.admin_id == session['user_id'])) |
        ((Message.user_id == session['user_id']) & (Message.admin_id == user_id))
    ).order_by(Message.timestamp).all()
    
    return render_template('admin/chat_user.html', user=user, messages=messages, current_user=current_user, now=datetime.utcnow())

@app.route('/admin/send_message', methods=['POST'])
def admin_send_message():
    if not session.get('user_id') or not session.get('is_admin'):
        return jsonify({'error': 'Unauthorized'}), 401
    
    user_id = request.form.get('user_id')
    content = request.form.get('content')
    
    if not user_id or not content:
        return jsonify({'error': 'Missing data'}), 400
    
    message = Message(
        content=content,
        user_id=session['user_id'],
        admin_id=user_id,
        is_from_admin=True
    )
    
    db.session.add(message)
    db.session.commit()
    
    return jsonify({
        'id': message.id,
        'content': message.content,
        'timestamp': message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
        'is_from_admin': True
    })

# Alert management routes
@app.route('/admin/get-current-alert')
@admin_required
def get_current_alert():
    """Get the current active alert"""
    alert = Alert.query.filter_by(is_active=True).order_by(Alert.updated_at.desc()).first()
    
    if alert:
        return jsonify({
            'success': True,
            'alert': {
                'id': alert.id,
                'message': alert.message,
                'background_color': alert.background_color,
                'text_color': alert.text_color,
                'is_active': alert.is_active,
                'created_at': alert.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'updated_at': alert.updated_at.strftime('%Y-%m-%d %H:%M:%S')
            }
        })
    else:
        return jsonify({
            'success': True,
            'alert': None
        })

@app.route('/admin/save-alert', methods=['POST'])
@admin_required
def save_alert():
    """Save or update an alert"""
    try:
        message = request.form.get('message', '').strip()
        background_color = request.form.get('background_color', '#00a651')  # Website primary green
        text_color = request.form.get('text_color', '#ffffff')  # White text
        is_active = request.form.get('is_active') == 'on'
        
        if not message:
            return jsonify({'success': False, 'message': 'Alert message is required'})
        
        # Deactivate all existing alerts first
        Alert.query.update({'is_active': False})
        
        # Create new alert
        new_alert = Alert(
            message=message,
            background_color=background_color,
            text_color=text_color,
            is_active=is_active,
            admin_id=session['user_id']
        )
        
        db.session.add(new_alert)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Alert saved successfully',
            'alert_id': new_alert.id
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error saving alert: {str(e)}'
        })

@app.route('/admin/clear-alert', methods=['POST'])
@admin_required
def clear_alert():
    """Clear all active alerts"""
    try:
        # Deactivate all alerts
        Alert.query.update({'is_active': False})
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Alert cleared successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error clearing alert: {str(e)}'
        })

@app.route('/api/get-active-alert')
def get_active_alert():
    """Public API to get the current active alert for website display"""
    alert = Alert.query.filter_by(is_active=True).order_by(Alert.updated_at.desc()).first()
    
    if alert:
        return jsonify({
            'success': True,
            'alert': {
                'message': alert.message,
                'background_color': alert.background_color,
                'text_color': alert.text_color
            }
        })
    else:
        return jsonify({
            'success': False,
            'alert': None
        })

# Dashboard route - redirects to appropriate dashboard based on user role
@app.route('/dashboard')
@login_required
def dashboard():
    """Generic dashboard route that redirects to appropriate dashboard"""
    user = User.query.get(session['user_id'])
    if user.is_admin:
        return redirect(url_for('admin_dashboard'))
    else:
        return redirect(url_for('user_dashboard'))

# User routes
@app.route('/user/dashboard')
@login_required
def user_dashboard():
    user = User.query.get(session['user_id'])
    # The dashboard template uses JavaScript to fetch data from API endpoints
    # No need to query enrollments and ebook_purchases here as they're not used
    return render_template('user/dashboard.html', user=user, now=datetime.utcnow())

@app.route('/user/change-password', methods=['POST'])
@login_required
def user_change_password():
    """Allow user to change password from dashboard"""
    try:
        user = User.query.get(session['user_id'])
        if not user:
            return jsonify({'success': False, 'message': 'User not found'}), 404
        
        # Get form data
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Validate input
        if not current_password or not new_password or not confirm_password:
            return jsonify({'success': False, 'message': 'All fields are required'}), 400
        
        # Check current password
        if not check_password_hash(user.password, current_password):
            return jsonify({'success': False, 'message': 'Current password is incorrect'}), 400
        
        # Check new passwords match
        if new_password != confirm_password:
            return jsonify({'success': False, 'message': 'New passwords do not match'}), 400
        
        # Validate new password strength
        if len(new_password) < 8:
            return jsonify({'success': False, 'message': 'Password must be at least 8 characters long'}), 400
        
        # Update password in database
        user.password = generate_password_hash(new_password)
        db.session.commit()
        
        print(f"✅ Password changed for user: {user.email}")
        
        return jsonify({
            'success': True, 
            'message': 'Password changed successfully'
        })
        
    except Exception as e:
        print(f"❌ Error changing password: {e}")
        return jsonify({'success': False, 'message': 'An error occurred'}), 500

@app.route('/user/upload-profile-picture', methods=['POST'])
@login_required
def user_upload_profile_picture():
    """Upload user profile picture"""
    try:
        if 'profile_picture' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No image file provided'
            })
        
        file = request.files['profile_picture']
        if file.filename == '':
            return jsonify({
                'success': False,
                'message': 'No file selected'
            })
        
        # Check file type
        allowed_extensions = {'png', 'jpg', 'jpeg', 'webp'}
        file_extension = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
        
        if file_extension not in allowed_extensions:
            return jsonify({
                'success': False,
                'message': 'Invalid file type. Allowed: PNG, JPG, JPEG, WEBP'
            })
        
        # Check file size (2MB max)
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > 2 * 1024 * 1024:  # 2MB
            return jsonify({
                'success': False,
                'message': 'File size exceeds 2MB limit'
            })
        
        # Generate unique filename
        current_user = User.query.get(session['user_id'])
        unique_filename = f"user_profile_{current_user.id}_{uuid.uuid4().hex[:8]}_{secure_filename(file.filename)}"
        
        # Create uploads directory if it doesn't exist
        upload_dir = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', 'profiles')
        os.makedirs(upload_dir, exist_ok=True)
        
        # Save file
        upload_path = os.path.join(upload_dir, unique_filename)
        file.save(upload_path)
        
        # Update user profile picture path in database
        current_user.profile_picture = unique_filename
        db.session.commit()
        
        picture_url = url_for('static', filename=f'uploads/profiles/{unique_filename}')
        
        return jsonify({
            'success': True,
            'message': 'Profile picture uploaded successfully',
            'picture_url': picture_url
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Upload failed: {str(e)}'
        })

@app.route('/user/reset-profile-picture', methods=['POST'])
@login_required
def user_reset_profile_picture():
    """Reset user profile picture to default"""
    try:
        # Reset user's profile picture to None (will use default)
        current_user = User.query.get(session['user_id'])
        current_user.profile_picture = None
        db.session.commit()
        
        default_picture_url = url_for('static', filename='images/default-user.svg')
        
        return jsonify({
            'success': True,
            'message': 'Profile picture reset to default',
            'picture_url': default_picture_url
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Reset failed: {str(e)}'
        })

@app.route('/user/profile/edit', methods=['GET', 'POST'])
@login_required
def user_edit_profile():
    """Edit user profile information"""
    user = User.query.get(session['user_id'])
    
    if request.method == 'POST':
        try:
            # Update profile fields
            user.first_name = request.form.get('first_name', '').strip()
            user.last_name = request.form.get('last_name', '').strip()
            user.username = request.form.get('username', '').strip()
            user.email = request.form.get('email', '').strip()
            user.phone_number = request.form.get('phone_number', '').strip()
            user.country_code = request.form.get('country_code', '').strip()
            user.country = request.form.get('country', '').strip()
            user.gender = request.form.get('gender', '').strip()
            
            # Parse birth date
            birth_date_str = request.form.get('birth_date')
            if birth_date_str:
                user.birth_date = datetime.strptime(birth_date_str, '%Y-%m-%d').date()
            
            # Validation
            if not all([user.first_name, user.last_name, user.username, user.email]):
                return jsonify({'success': False, 'message': 'All required fields must be filled'})
            
            # Check if username/email is taken by another user
            existing_user = User.query.filter(User.username == user.username, User.id != user.id).first()
            if existing_user:
                return jsonify({'success': False, 'message': 'Username already taken'})
            
            existing_user = User.query.filter(User.email == user.email, User.id != user.id).first()
            if existing_user:
                return jsonify({'success': False, 'message': 'Email already in use'})
            
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Profile updated successfully'
            })
            
        except Exception as e:
            db.session.rollback()
            return jsonify({
                'success': False,
                'message': f'Update failed: {str(e)}'
            })
    
    # GET request - return profile data
    return jsonify({
        'success': True,
        'user': {
            'first_name': user.first_name,
            'last_name': user.last_name,
            'username': user.username,
            'email': user.email,
            'phone_number': user.phone_number,
            'country_code': user.country_code,
            'country': user.country,
            'gender': user.gender,
            'birth_date': user.birth_date.strftime('%Y-%m-%d') if user.birth_date else '',
            'profile_picture': url_for('static', filename=f'uploads/profiles/{user.profile_picture}') if user.profile_picture else url_for('static', filename='images/default-user.svg')
        }
    })

@app.route('/user/security', methods=['GET'])
@login_required
def user_security():
    """Show security settings page with trusted devices"""
    user = User.query.get(session['user_id'])
    trusted_devices = TrustedDevice.query.filter_by(user_id=user.id).order_by(TrustedDevice.last_used.desc()).all()
    
    return render_template('user/security.html', 
                           user=user, 
                           trusted_devices=trusted_devices, 
                           now=datetime.utcnow())

@app.route('/user/security/revoke-device/<int:device_id>', methods=['POST'])
@login_required
def revoke_device(device_id):
    """Revoke a trusted device"""
    device = TrustedDevice.query.get_or_404(device_id)
    
    # Ensure user owns this device
    if device.user_id != session['user_id']:
        flash('You do not have permission to revoke this device', 'danger')
        return redirect(url_for('user_security'))
    
    # Delete the device
    db.session.delete(device)
    db.session.commit()
    
    flash('Device has been removed from trusted devices', 'success')
    return redirect(url_for('user_security'))

@app.route('/user/security/revoke-all-devices', methods=['POST'])
@login_required
def revoke_all_devices():
    """Revoke all trusted devices"""
    # Revoke all devices
    AuthManager.revoke_all_devices(session['user_id'])
    
    # Remove the device token cookie
    resp = make_response(redirect(url_for('user_security')))
    resp.delete_cookie('device_token')
    
    flash('All devices have been removed from trusted devices', 'success')
    return resp

@app.route('/user/courses')
@login_required
def user_courses():
    
    courses = Course.query.all()
    enrollments = Enrollment.query.filter_by(user_id=session['user_id']).all()
    enrolled_course_ids = [enrollment.course_id for enrollment in enrollments]
    current_user = User.query.get(session['user_id'])
    
    return render_template('user/courses.html', courses=courses, enrolled_course_ids=enrolled_course_ids, current_user=current_user, now=datetime.utcnow())

@app.route('/api/user/purchased-ebooks')
@login_required
def get_user_purchased_ebooks():
    """Get user's purchased ebooks"""
    try:
        user_id = session['user_id']
        print(f"📖 API CALL: Getting ebooks for user {user_id}")
        
        # Get purchases with ebook data - show all purchased ebooks regardless of published status
        purchases = db.session.query(EbookPurchase)\
            .join(Ebook)\
            .filter(EbookPurchase.user_id == user_id)\
            .all()
        
        print(f"📖 FOUND {len(purchases)} ebook purchases for user {user_id}")
        
        purchased_ebooks = []
        for purchase in purchases:
            ebook = purchase.ebook  # This gets the ebook through the existing relationship
            
            purchased_ebooks.append({
                'id': ebook.id,
                'name': ebook.name,
                'author': ebook.author,
                'description': ebook.description,
                'category': ebook.category,
                'cover_image': ebook.cover_image,
                'pdf_file': ebook.pdf_file,
                'price': ebook.price,
                'purchased_at': purchase.purchased_at.strftime('%Y-%m-%d %H:%M'),
                'total_paid': purchase.total_paid
            })
        
        return jsonify({
            'success': True,
            'ebooks': purchased_ebooks
        })
        
    except Exception as e:
        print(f"Error getting user purchased ebooks: {str(e)}")
        return jsonify({
            'success': False,
            'message': f'Error loading ebooks: {str(e)}'
        }), 500

@app.route('/api/user/enrolled-courses')
@login_required
def get_user_enrolled_courses():
    """Get user's enrolled courses with progress data"""
    try:
        user_id = session['user_id']
        
        # Get enrollments with course data - show all purchased courses regardless of published status
        enrollments = db.session.query(CourseEnrollment)\
            .join(Course)\
            .filter(CourseEnrollment.user_id == user_id)\
            .all()
        
        enrolled_courses = []
        for enrollment in enrollments:
            course = enrollment.course
            
            # Get all videos for this course
            videos = VideoLesson.query.filter_by(course_id=course.id)\
                .order_by(VideoLesson.order_index)\
                .all()
            
            # Calculate overall progress
            total_videos = len(videos)
            completed_videos = 0
            total_watched_duration = 0
            total_course_duration = 0
            
            for video in videos:
                # Get user's progress for this video
                progress = LessonProgress.query.filter_by(
                    user_id=user_id,
                    lesson_id=video.id
                ).first()
                
                if progress:
                    total_watched_duration += progress.watched_duration or 0
                    if progress.is_completed:
                        completed_videos += 1
                
                total_course_duration += video.duration or 0
            
            # Calculate completion percentage
            completion_percentage = 0
            if total_videos > 0:
                completion_percentage = round((completed_videos / total_videos) * 100)
            
            # Determine status
            status = 'Not Started'
            if completion_percentage == 100:
                status = 'Completed'
            elif completion_percentage > 0:
                status = 'In Progress'
            
            enrolled_courses.append({
                'id': course.id,
                'title': course.title,
                'description': course.description,
                'image': course.image,
                'instructor': course.instructor_name,
                'total_videos': total_videos,
                'completed_videos': completed_videos,
                'completion_percentage': completion_percentage,
                'status': status,
                'enrolled_at': enrollment.enrolled_at.strftime('%Y-%m-%d'),
                'last_accessed': enrollment.last_accessed_at.strftime('%Y-%m-%d %H:%M') if enrollment.last_accessed_at else None,
                'has_videos': total_videos > 0
            })
        
        return jsonify({
            'success': True,
            'courses': enrolled_courses
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/user/enroll/<int:course_id>', methods=['GET', 'POST'])
def user_enroll(course_id):
    if not session.get('user_id') or session.get('is_admin'):
        if request.method == 'POST':
            return jsonify({'success': False, 'message': 'Please log in to enroll'}), 401
        return redirect(url_for('login'))
    
    course = Course.query.filter_by(id=course_id, is_published=True).first_or_404()
    
    # Check if already enrolled
    existing_enrollment = Enrollment.query.filter_by(
        user_id=session['user_id'],
        course_id=course_id
    ).first()
    
    if existing_enrollment:
        if request.method == 'POST':
            return jsonify({'success': False, 'message': 'Already enrolled'}), 400
        flash('You are already enrolled in this course', 'info')
        return redirect(url_for('user_courses'))
    
    if request.method == 'POST':
        # Handle enrollment from purchase page
        try:
            data = request.get_json() or {}
            coupon = data.get('coupon', '')
            discount = data.get('discount', 0)
            total_paid = data.get('total_paid', course.price)
            
            # Validate coupon if provided
            if coupon and course.coupon:
                if coupon.upper() != course.coupon.upper():
                    return jsonify({'success': False, 'message': 'Invalid coupon code'}), 400
                if discount != course.coupon_discount:
                    return jsonify({'success': False, 'message': 'Invalid discount amount'}), 400
            
            # Create enrollment
            new_enrollment = Enrollment(
                user_id=session['user_id'],
                course_id=course_id
            )
            
            db.session.add(new_enrollment)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Successfully enrolled!'})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 500
    
    # GET request - redirect to purchase page
    return redirect(url_for('course_purchase', course_id=course_id))

# User eBook Routes
@app.route('/user/ebooks')
@login_required
def user_ebooks():
    ebooks = Ebook.query.filter_by(is_published=True).all()
    purchases = EbookPurchase.query.filter_by(user_id=session['user_id']).all()
    purchased_ebook_ids = [purchase.ebook_id for purchase in purchases]
    current_user = User.query.get(session['user_id'])
    
    return render_template('user/ebooks.html', ebooks=ebooks, purchased_ebook_ids=purchased_ebook_ids, current_user=current_user, now=datetime.utcnow())

@app.route('/user/purchase-ebook/<int:ebook_id>', methods=['GET', 'POST'])
def user_purchase_ebook(ebook_id):
    if not session.get('user_id') or session.get('is_admin'):
        if request.method == 'POST':
            return jsonify({'success': False, 'message': 'Please log in to purchase'}), 401
        return redirect(url_for('login'))
    
    ebook = Ebook.query.filter_by(id=ebook_id, is_published=True).first_or_404()
    
    # Check if already purchased
    existing_purchase = EbookPurchase.query.filter_by(
        user_id=session['user_id'],
        ebook_id=ebook_id
    ).first()
    
    if existing_purchase:
        if request.method == 'POST':
            return jsonify({'success': False, 'message': 'Already purchased'}), 400
        flash('You have already purchased this eBook', 'info')
        return redirect(url_for('user_dashboard') + '#ebooks')
    
    if request.method == 'POST':
        # Handle purchase from purchase page
        try:
            data = request.get_json() or {}
            coupon = data.get('coupon', '')
            discount = data.get('discount', 0)
            total_paid = data.get('total_paid', ebook.price)
            
            # Validate coupon if provided
            if coupon and ebook.coupon:
                if coupon.upper() != ebook.coupon.upper():
                    return jsonify({'success': False, 'message': 'Invalid coupon code'}), 400
                if discount != ebook.coupon_discount:
                    return jsonify({'success': False, 'message': 'Invalid discount amount'}), 400
            
            # Create purchase
            new_purchase = EbookPurchase(
                user_id=session['user_id'],
                ebook_id=ebook_id,
                coupon_used=coupon if coupon else None,
                discount_amount=ebook.price * (discount / 100) if discount > 0 else 0,
                total_paid=total_paid
            )
            
            db.session.add(new_purchase)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Successfully purchased!'})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 500
    
    # GET request - redirect to purchase page
    return redirect(url_for('ebook_purchase', ebook_id=ebook_id))

# SSLCommerz Payment Integration Routes
class SSLCommerzPayment:
    """SSLCommerz Payment Gateway Integration Class"""
    
    @staticmethod
    def create_session(transaction_data):
        """Create payment session with SSLCommerz"""
        try:
            # Get base URL from the current request
            from flask import request as flask_request
            if flask_request:
                base_url = flask_request.url_root.rstrip('/')
            else:
                # Fallback to production URL if no request context
                base_url = 'https://skillfinesse.com'
            
            # Prepare the session data for SSLCommerz
            session_data = {
                'store_id': app.config['SSLCOMMERZ_STORE_ID'],
                'store_passwd': app.config['SSLCOMMERZ_STORE_PASSWORD'],
                'total_amount': transaction_data['total_amount'],
                'currency': transaction_data.get('currency', 'BDT'),
                'tran_id': transaction_data['transaction_id'],
                'success_url': f"{base_url}/payment/success",
                'fail_url': f"{base_url}/payment/failure",
                'cancel_url': f"{base_url}/payment/cancel",
                'ipn_url': f"{base_url}/payment/ipn",
                
                # Customer information
                'cus_name': transaction_data['customer_name'],
                'cus_email': transaction_data['customer_email'],
                'cus_add1': transaction_data.get('customer_address', 'N/A'),
                'cus_add2': 'N/A',
                'cus_city': transaction_data.get('customer_city', 'Dhaka'),
                'cus_state': transaction_data.get('customer_state', 'Dhaka'),
                'cus_postcode': transaction_data.get('customer_postcode', '1000'),
                'cus_country': transaction_data.get('customer_country', 'Bangladesh'),
                'cus_phone': transaction_data.get('customer_phone', '01700000000'),
                'cus_fax': transaction_data.get('customer_phone', '01700000000'),
                
                # Product information
                'product_name': transaction_data['product_name'],
                'product_category': transaction_data.get('product_category', 'Education'),
                'product_profile': 'general',
                
                # Shipping information (not applicable for digital products)
                'shipping_method': 'NO',
                'num_of_item': 1,
                
                # Additional info
                'value_a': transaction_data.get('purchase_type', ''),  # course or ebook
                'value_b': transaction_data.get('item_id', ''),  # course_id or ebook_id
                'value_c': transaction_data.get('user_id', ''),
                'value_d': transaction_data.get('coupon_code', ''),
            }
            
            # Make the API request to SSLCommerz
            response = requests.post(
                app.config['SSLCOMMERZ_SESSION_API'],
                data=session_data,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get('status') == 'SUCCESS':
                    return {
                        'success': True,
                        'gateway_url': result.get('GatewayPageURL'),
                        'session_key': result.get('sessionkey'),
                        'response': result
                    }
                else:
                    return {
                        'success': False,
                        'error': result.get('failedreason', 'Unknown error'),
                        'response': result
                    }
            else:
                return {
                    'success': False,
                    'error': f'HTTP Error: {response.status_code}',
                    'response': None
                }
                
        except requests.exceptions.Timeout:
            return {'success': False, 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            return {'success': False, 'error': f'Request error: {str(e)}'}
        except Exception as e:
            return {'success': False, 'error': f'Unexpected error: {str(e)}'}
    
    @staticmethod
    def validate_payment(val_id, store_id, store_password, transaction_id):
        """Validate payment with SSLCommerz"""
        try:
            validation_data = {
                'val_id': val_id,
                'store_id': store_id,
                'store_passwd': store_password,
                'v': 1,
                'format': 'json'
            }
            
            response = requests.get(
                app.config['SSLCOMMERZ_VALIDATION_API'],
                params=validation_data,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return {
                    'success': True,
                    'status': result.get('status'),
                    'data': result
                }
            else:
                return {
                    'success': False,
                    'error': f'HTTP Error: {response.status_code}'
                }
                
        except Exception as e:
            return {
                'success': False,
                'error': f'Validation error: {str(e)}'
            }

@app.route('/payment/create-session', methods=['POST'])
def create_payment_session():
    """Create SSLCommerz payment session"""
    if not session.get('user_id'):
        return jsonify({'success': False, 'error': 'User not authenticated'})
    
    try:
        data = request.get_json()
        user = User.query.get(session['user_id'])
        
        # Validate required fields
        required_fields = ['purchase_type', 'item_id', 'amount']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Missing field: {field}'})
        
        # Get item details based on purchase type
        if data['purchase_type'] == 'course':
            item = Course.query.get(data['item_id'])
            if not item:
                return jsonify({'success': False, 'error': 'Course not found'})
            product_name = f"Course: {item.title}"
            product_category = "Online Course"
        elif data['purchase_type'] == 'ebook':
            item = Ebook.query.get(data['item_id'])
            if not item:
                return jsonify({'success': False, 'error': 'eBook not found'})
            product_name = f"eBook: {item.name}"
            product_category = "Digital Book"
        else:
            return jsonify({'success': False, 'error': 'Invalid purchase type'})
        
        # Check if user already purchased this item
        if data['purchase_type'] == 'course':
            existing_enrollment = CourseEnrollment.query.filter_by(
                user_id=user.id, course_id=item.id
            ).first()
            if existing_enrollment:
                return jsonify({'success': False, 'error': 'You have already enrolled in this course'})
        else:
            existing_purchase = EbookPurchase.query.filter_by(
                user_id=user.id, ebook_id=item.id
            ).first()
            if existing_purchase:
                return jsonify({'success': False, 'error': 'You have already purchased this ebook'})
        
        # Calculate amounts
        original_amount = float(data['amount'])
        discount_amount = float(data.get('discount_amount', 0))
        total_amount = original_amount - discount_amount
        
        if total_amount <= 0:
            return jsonify({'success': False, 'error': 'Invalid amount'})
        
        # Generate transaction ID
        transaction_id = PaymentTransaction.generate_transaction_id()
        
        # Create payment transaction record
        payment_transaction = PaymentTransaction(
            transaction_id=transaction_id,
            user_id=user.id,
            purchase_type=data['purchase_type'],
            course_id=item.id if data['purchase_type'] == 'course' else None,
            ebook_id=item.id if data['purchase_type'] == 'ebook' else None,
            amount=original_amount,
            discount_amount=discount_amount,
            total_amount=total_amount,
            currency='BDT',
            coupon_code=data.get('coupon_code'),
            coupon_discount_percent=data.get('coupon_discount_percent'),
            status='PENDING'
        )
        
        db.session.add(payment_transaction)
        db.session.commit()
        
        # Log transaction creation
        PaymentLog.log_action(
            transaction_id=transaction_id,
            action='transaction_created',
            status='SUCCESS',
            message='Payment transaction created successfully',
            data={'purchase_type': data['purchase_type'], 'item_id': data['item_id']},
            request_obj=request
        )
        
        # Prepare transaction data for SSLCommerz
        transaction_data = {
            'transaction_id': transaction_id,
            'total_amount': total_amount,
            'currency': 'BDT',
            'customer_name': user.full_name,
            'customer_email': user.email,
            'customer_phone': user.phone_number if hasattr(user, 'phone_number') else '01700000000',
            'product_name': product_name,
            'product_category': product_category,
            'purchase_type': data['purchase_type'],
            'item_id': data['item_id'],
            'user_id': user.id,
            'coupon_code': data.get('coupon_code', '')
        }
        
        # Create SSLCommerz session
        session_result = SSLCommerzPayment.create_session(transaction_data)
        
        if session_result['success']:
            # Update transaction status
            payment_transaction.update_status('PROCESSING', session_result.get('response'))
            
            # Log session creation
            PaymentLog.log_action(
                transaction_id=transaction_id,
                action='session_created',
                status='SUCCESS',
                message='SSLCommerz session created successfully',
                data=session_result.get('response'),
                request_obj=request
            )
            
            return jsonify({
                'success': True,
                'gateway_url': session_result['gateway_url'],
                'transaction_id': transaction_id
            })
        else:
            # Update transaction status to failed
            payment_transaction.update_status('FAILED')
            
            # Log session creation failure
            PaymentLog.log_action(
                transaction_id=transaction_id,
                action='session_creation_failed',
                status='FAILED',
                message=f"SSLCommerz session creation failed: {session_result.get('error')}",
                data=session_result.get('response'),
                request_obj=request
            )
            
            return jsonify({
                'success': False,
                'error': session_result.get('error', 'Failed to create payment session')
            })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': f'Server error: {str(e)}'})

@app.route('/payment/ipn', methods=['POST'])
def payment_ipn():
    """Handle SSLCommerz IPN (Instant Payment Notification)"""
    try:
        # Get IPN data from SSLCommerz
        ipn_data = request.form.to_dict()
        
        transaction_id = ipn_data.get('tran_id')
        val_id = ipn_data.get('val_id')
        status = ipn_data.get('status')
        
        if not all([transaction_id, val_id, status]):
            return 'Missing required parameters', 400
        
        # Find the payment transaction
        payment_transaction = PaymentTransaction.query.filter_by(
            transaction_id=transaction_id
        ).first()
        
        if not payment_transaction:
            # Log unknown transaction
            PaymentLog.log_action(
                transaction_id=transaction_id,
                action='ipn_unknown_transaction',
                status='FAILED',
                message='IPN received for unknown transaction',
                data=ipn_data,
                request_obj=request
            )
            return 'Transaction not found', 404
        
        # Log IPN receipt
        PaymentLog.log_action(
            transaction_id=transaction_id,
            action='ipn_received',
            status=status,
            message=f'IPN received with status: {status}',
            data=ipn_data,
            request_obj=request
        )
        
        # Validate the payment with SSLCommerz
        validation_result = SSLCommerzPayment.validate_payment(
            val_id=val_id,
            store_id=app.config['SSLCOMMERZ_STORE_ID'],
            store_password=app.config['SSLCOMMERZ_STORE_PASSWORD'],
            transaction_id=transaction_id
        )
        
        if validation_result['success']:
            validated_data = validation_result['data']
            validated_status = validated_data.get('status')
            
            # Update transaction with validation data
            payment_transaction.update_status(validated_status, validated_data)
            
            # Log validation success
            PaymentLog.log_action(
                transaction_id=transaction_id,
                action='validation_success',
                status=validated_status,
                message='Payment validation successful',
                data=validated_data,
                request_obj=request
            )
            
            # Process successful payment
            if validated_status == 'VALID':
                # Check risk level
                risk_level = int(validated_data.get('risk_level', 0))
                
                if risk_level == 0:
                    # Low risk - process immediately
                    process_successful_payment(payment_transaction)
                else:
                    # High risk - hold for manual review
                    PaymentLog.log_action(
                        transaction_id=transaction_id,
                        action='high_risk_hold',
                        status='HOLD',
                        message=f'Transaction held for review due to risk level: {risk_level}',
                        data={'risk_level': risk_level, 'risk_title': validated_data.get('risk_title')},
                        request_obj=request
                    )
            
            return 'IPN processed successfully', 200
        else:
            # Log validation failure
            PaymentLog.log_action(
                transaction_id=transaction_id,
                action='validation_failed',
                status='FAILED',
                message=f"Payment validation failed: {validation_result.get('error')}",
                data=validation_result,
                request_obj=request
            )
            
            return 'Validation failed', 400
    
    except Exception as e:
        # Log IPN processing error
        PaymentLog.log_action(
            transaction_id=transaction_id if 'transaction_id' in locals() else 'unknown',
            action='ipn_error',
            status='ERROR',
            message=f'IPN processing error: {str(e)}',
            data={'error': str(e)},
            request_obj=request
        )
        
        return f'IPN processing error: {str(e)}', 500

def process_successful_payment(payment_transaction):
    """Process a successful payment by creating enrollment/purchase"""
    try:
        print(f"⚡ PROCESSING PAYMENT: {payment_transaction.transaction_id} - Type: {payment_transaction.purchase_type}")
        if payment_transaction.purchase_type == 'course':
            # Create course enrollment
            enrollment = CourseEnrollment(
                user_id=payment_transaction.user_id,
                course_id=payment_transaction.course_id,
                enrolled_at=datetime.utcnow()
            )
            db.session.add(enrollment)
            print(f"✅ CREATED COURSE ENROLLMENT: User {payment_transaction.user_id}, Course {payment_transaction.course_id}")
            
            # Log enrollment creation
            PaymentLog.log_action(
                transaction_id=payment_transaction.transaction_id,
                action='enrollment_created',
                status='SUCCESS',
                message='Course enrollment created successfully'
            )
            
        elif payment_transaction.purchase_type == 'ebook':
            # Create ebook purchase
            ebook_purchase = EbookPurchase(
                user_id=payment_transaction.user_id,
                ebook_id=payment_transaction.ebook_id,
                purchased_at=datetime.utcnow(),
                coupon_used=payment_transaction.coupon_code,
                discount_amount=payment_transaction.discount_amount,
                total_paid=payment_transaction.total_amount
            )
            db.session.add(ebook_purchase)
            print(f"✅ CREATED EBOOK PURCHASE: User {payment_transaction.user_id}, Ebook {payment_transaction.ebook_id}")
            
            # Log purchase creation
            PaymentLog.log_action(
                transaction_id=payment_transaction.transaction_id,
                action='purchase_created',
                status='SUCCESS',
                message='eBook purchase created successfully'
            )
        
        # Update transaction status to validated
        payment_transaction.update_status('VALIDATED')
        
        db.session.commit()
        print(f"💾 PAYMENT PROCESSING COMPLETED AND COMMITTED: {payment_transaction.transaction_id}")
        
    except Exception as e:
        db.session.rollback()
        print(f"❌ PAYMENT PROCESSING FAILED: {str(e)}")
        PaymentLog.log_action(
            transaction_id=payment_transaction.transaction_id,
            action='processing_error',
            status='ERROR',
            message=f'Error processing successful payment: {str(e)}',
            data={'error': str(e)}
        )

@app.route('/debug/user-purchases/<int:user_id>')
@login_required
def debug_user_purchases(user_id):
    """Debug endpoint to check user purchases"""
    if not session.get('is_admin'):
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        # Check CourseEnrollment records
        enrollments = CourseEnrollment.query.filter_by(user_id=user_id).all()
        enrollment_data = []
        for enrollment in enrollments:
            enrollment_data.append({
                'id': enrollment.id,
                'course_id': enrollment.course_id,
                'enrolled_at': enrollment.enrolled_at.strftime('%Y-%m-%d %H:%M:%S'),
                'course_title': enrollment.course.title if enrollment.course else 'Unknown'
            })
        
        # Check EbookPurchase records
        purchases = EbookPurchase.query.filter_by(user_id=user_id).all()
        purchase_data = []
        for purchase in purchases:
            purchase_data.append({
                'id': purchase.id,
                'ebook_id': purchase.ebook_id,
                'purchased_at': purchase.purchased_at.strftime('%Y-%m-%d %H:%M:%S'),
                'total_paid': purchase.total_paid,
                'ebook_name': purchase.ebook.name if purchase.ebook else 'Unknown'
            })
        
        # Check PaymentTransaction records
        transactions = PaymentTransaction.query.filter_by(user_id=user_id).all()
        transaction_data = []
        for transaction in transactions:
            transaction_data.append({
                'id': transaction.id,
                'transaction_id': transaction.transaction_id,
                'status': transaction.status,
                'purchase_type': transaction.purchase_type,
                'course_id': transaction.course_id,
                'ebook_id': transaction.ebook_id,
                'total_amount': transaction.total_amount,
                'created_at': transaction.created_at.strftime('%Y-%m-%d %H:%M:%S')
            })
        
        return jsonify({
            'user_id': user_id,
            'enrollments': enrollment_data,
            'ebook_purchases': purchase_data,
            'payment_transactions': transaction_data
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/payment/success', methods=['GET', 'POST'])
def payment_success():
    """Handle successful payment callback - BULLETPROOF VERSION"""
    # Check both GET and POST parameters
    transaction_id = request.args.get('tran_id') or request.form.get('tran_id')
    val_id = request.args.get('val_id') or request.form.get('val_id')
    
    print(f"🔄 SUCCESS CALLBACK: Received for transaction {transaction_id}")
    print(f"🔄 SUCCESS CALLBACK: Request args: {dict(request.args)}")
    print(f"🔄 SUCCESS CALLBACK: Request form: {dict(request.form)}")
    
    if not transaction_id:
        print("❌ SUCCESS CALLBACK: No transaction ID provided")
        flash('Invalid payment response', 'error')
        return redirect(url_for('dashboard'))
    
    # Find the payment transaction
    payment_transaction = PaymentTransaction.query.filter_by(
        transaction_id=transaction_id
    ).first()
    
    if not payment_transaction:
        print(f"❌ SUCCESS CALLBACK: Payment transaction {transaction_id} not found")
        flash('Payment transaction not found', 'error')
        return redirect(url_for('dashboard'))
    
    print(f"🔄 SUCCESS CALLBACK: Found payment transaction - Status: {payment_transaction.status}")
    
    # Check if payment was already processed
    if payment_transaction.status in ['VALID', 'VALIDATED']:
        print("✅ SUCCESS CALLBACK: Payment already processed")
        flash('Payment successful! Check your dashboard for purchased items.', 'success')
        return redirect(url_for('dashboard'))
    
    # AGGRESSIVE FALLBACK: If payment is in PROCESSING/PENDING, process it immediately
    # This ensures bKash and other payments that don't trigger IPN still work
    if payment_transaction.status in ['PENDING', 'PROCESSING']:
        try:
            print(f"🔧 SUCCESS CALLBACK: Processing payment {transaction_id} immediately (fallback)")
            
            # For bKash and similar payments, we assume success if we reach the success callback
            # Update status to VALID
            payment_transaction.update_status('VALID')
            
            # Log fallback processing
            PaymentLog.log_action(
                transaction_id=transaction_id,
                action='success_callback_fallback',
                status='VALID',
                message='Payment processed via success callback fallback (bKash/mobile payment)',
                data={'method': 'fallback', 'original_status': payment_transaction.status},
                request_obj=request
            )
            
            # Process the payment immediately
            process_successful_payment(payment_transaction)
            
            print(f"✅ SUCCESS CALLBACK: Payment {transaction_id} processed successfully via fallback")
            
            # Redirect to dashboard with success message
            flash('Payment successful! Check your dashboard for purchased items.', 'success')
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            print(f"❌ SUCCESS CALLBACK FALLBACK ERROR: {str(e)}")
            # Log error but still try validation if we have val_id
            PaymentLog.log_action(
                transaction_id=transaction_id,
                action='success_callback_fallback_error',
                status='ERROR',
                message=f'Error in success callback fallback: {str(e)}',
                data={'error': str(e)},
                request_obj=request
            )
            
            # Continue to validation if we have val_id
    
    # If we have val_id, try validation as additional fallback
    if val_id:
        try:
            print(f"🔄 SUCCESS CALLBACK VALIDATION: Validating payment {transaction_id} with val_id {val_id}")
            
            # Validate the payment with SSLCommerz
            validation_result = SSLCommerzPayment.validate_payment(
                val_id=val_id,
                store_id=app.config['SSLCOMMERZ_STORE_ID'],
                store_password=app.config['SSLCOMMERZ_STORE_PASSWORD'],
                transaction_id=transaction_id
            )
            
            if validation_result['success']:
                validated_data = validation_result['data']
                validated_status = validated_data.get('status')
                
                print(f"✅ SUCCESS CALLBACK: Payment validated with status {validated_status}")
                
                # Update transaction with validation data
                payment_transaction.update_status(validated_status, validated_data)
                
                # Log validation success
                PaymentLog.log_action(
                    transaction_id=transaction_id,
                    action='success_callback_validation',
                    status=validated_status,
                    message='Payment validated in success callback (IPN fallback)',
                    data=validated_data,
                    request_obj=request
                )
                
                # Process successful payment if validated
                if validated_status == 'VALID':
                    # Check risk level
                    risk_level = int(validated_data.get('risk_level', 0))
                    
                    if risk_level == 0:
                        # Low risk - process immediately
                        process_successful_payment(payment_transaction)
                        print(f"💾 SUCCESS CALLBACK: Payment processed successfully")
                        
                        # Redirect to dashboard with success message
                        flash('Payment successful! Check your dashboard for purchased items.', 'success')
                        return redirect(url_for('dashboard'))
                    else:
                        # High risk - hold for manual review
                        PaymentLog.log_action(
                            transaction_id=transaction_id,
                            action='high_risk_hold_success_callback',
                            status='HOLD',
                            message=f'Transaction held for review due to risk level: {risk_level}',
                            data={'risk_level': risk_level, 'risk_title': validated_data.get('risk_title')},
                            request_obj=request
                        )
                        flash('Payment successful but under review. You will be notified once approved.', 'info')
                        return redirect(url_for('dashboard'))
                else:
                    # Invalid payment
                    flash('Payment validation failed. Please contact support.', 'error')
                    return redirect(url_for('dashboard'))
            else:
                # Validation failed
                print(f"❌ SUCCESS CALLBACK: Payment validation failed - {validation_result.get('error')}")
                flash('Payment validation failed. Please contact support.', 'error')
                return redirect(url_for('dashboard'))
                
        except Exception as e:
            print(f"❌ SUCCESS CALLBACK VALIDATION ERROR: {str(e)}")
            # Log error
            PaymentLog.log_action(
                transaction_id=transaction_id,
                action='success_callback_validation_error',
                status='ERROR',
                message=f'Error in success callback validation: {str(e)}',
                data={'error': str(e)},
                request_obj=request
            )
            flash('Payment processing error. Please contact support.', 'error')
            return redirect(url_for('dashboard'))
    
    # Final fallback message
    print(f"⚠️ SUCCESS CALLBACK: Payment {transaction_id} needs manual processing")
    flash('Payment is being processed. Please check your dashboard in a few minutes.', 'info')
    return redirect(url_for('dashboard'))

@app.route('/payment/failure', methods=['GET', 'POST'])
def payment_failure():
    """Handle failed payment callback"""
    transaction_id = request.args.get('tran_id') or request.form.get('tran_id')
    error_msg = request.args.get('error', 'Payment failed') or request.form.get('error', 'Payment failed')
    
    if transaction_id:
        # Find the payment transaction
        payment_transaction = PaymentTransaction.query.filter_by(
            transaction_id=transaction_id
        ).first()
        
        if payment_transaction:
            # Update transaction status
            payment_transaction.update_status('FAILED')
            
            # Log failure
            PaymentLog.log_action(
                transaction_id=transaction_id,
                action='payment_failed',
                status='FAILED',
                message=f'Payment failed: {error_msg}',
                request_obj=request
            )
            
            # Redirect to the appropriate item details page
            if payment_transaction.purchase_type == 'course':
                course = Course.query.get(payment_transaction.course_id)
                if course:
                    flash(f'Payment failed: {error_msg}. Please try again.', 'error')
                    return redirect(url_for('course_details', course_id=course.id))
            elif payment_transaction.purchase_type == 'ebook':
                ebook = Ebook.query.get(payment_transaction.ebook_id)
                if ebook:
                    flash(f'Payment failed: {error_msg}. Please try again.', 'error')
                    return redirect(url_for('ebook_details', ebook_id=ebook.id))
    
    flash(f'Payment failed: {error_msg}', 'error')
    return redirect(url_for('dashboard'))

@app.route('/payment/cancel', methods=['GET', 'POST'])
def payment_cancel():
    """Handle cancelled payment callback"""
    transaction_id = request.args.get('tran_id') or request.form.get('tran_id')
    
    if transaction_id:
        # Find the payment transaction
        payment_transaction = PaymentTransaction.query.filter_by(
            transaction_id=transaction_id
        ).first()
        
        if payment_transaction:
            # Update transaction status
            payment_transaction.update_status('CANCELLED')
            
            # Log cancellation
            PaymentLog.log_action(
                transaction_id=transaction_id,
                action='payment_cancelled',
                status='CANCELLED',
                message='Payment was cancelled by user',
                request_obj=request
            )
            
            # Redirect to the appropriate item details page
            if payment_transaction.purchase_type == 'course':
                course = Course.query.get(payment_transaction.course_id)
                if course:
                    flash('Payment was cancelled. You can try purchasing again.', 'warning')
                    return redirect(url_for('course_details', course_id=course.id))
            elif payment_transaction.purchase_type == 'ebook':
                ebook = Ebook.query.get(payment_transaction.ebook_id)
                if ebook:
                    flash('Payment was cancelled. You can try purchasing again.', 'warning')
                    return redirect(url_for('ebook_details', ebook_id=ebook.id))
    
    flash('Payment was cancelled', 'warning')
    return redirect(url_for('dashboard'))

@app.route('/admin/manual-validate-payment/<transaction_id>')
@login_required
def manual_validate_payment(transaction_id):
    """Manual payment validation endpoint for admin - validates pending payments"""
    if not session.get('is_admin'):
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        print(f"🔧 MANUAL VALIDATION: Starting validation for {transaction_id}")
        
        # Find the payment transaction
        payment_transaction = PaymentTransaction.query.filter_by(
            transaction_id=transaction_id
        ).first()
        
        if not payment_transaction:
            return jsonify({'error': 'Payment transaction not found'}), 404
        
        # Check if already processed
        if payment_transaction.status in ['VALID', 'VALIDATED']:
            return jsonify({
                'success': True,
                'message': 'Payment already validated',
                'status': payment_transaction.status
            })
        
        # For testing, we'll skip SSLCommerz validation and process directly
        # In production, you would validate with SSLCommerz first
        
        print(f"🔧 MANUAL VALIDATION: Processing payment {transaction_id}")
        
        # Update status to VALID
        payment_transaction.update_status('VALID')
        
        # Log manual validation
        PaymentLog.log_action(
            transaction_id=transaction_id,
            action='manual_validation',
            status='VALID',
            message='Payment manually validated by admin',
            request_obj=request
        )
        
        # Process the payment
        process_successful_payment(payment_transaction)
        
        return jsonify({
            'success': True,
            'message': 'Payment validated and processed successfully',
            'transaction_id': transaction_id
        })
        
    except Exception as e:
        print(f"❌ MANUAL VALIDATION ERROR: {str(e)}")
        return jsonify({'error': f'Validation failed: {str(e)}'}), 500

@app.route('/admin/process-stuck-payments')
@login_required
def process_stuck_payments_endpoint():
    """Admin endpoint to process stuck payments"""
    if not session.get('is_admin'):
        return jsonify({'error': 'Admin access required'}), 403
    
    try:
        from datetime import timedelta
        
        # Find payments that are stuck in PROCESSING/PENDING
        stuck_payments = PaymentTransaction.query.filter(
            PaymentTransaction.status.in_(['PENDING', 'PROCESSING'])
        ).order_by(PaymentTransaction.created_at.desc()).all()
        
        if not stuck_payments:
            return jsonify({
                'success': True,
                'message': 'No stuck payments found',
                'processed': 0
            })
        
        processed_count = 0
        errors = []
        
        for payment in stuck_payments:
            try:
                print(f"🔧 ADMIN PROCESSING: {payment.transaction_id}")
                
                # Update status to VALID
                payment.update_status('VALID')
                
                # Log admin processing
                PaymentLog.log_action(
                    transaction_id=payment.transaction_id,
                    action='admin_manual_processing',
                    status='VALID',
                    message='Payment manually processed by admin',
                    request_obj=request
                )
                
                # Process the payment
                process_successful_payment(payment)
                
                processed_count += 1
                
            except Exception as e:
                errors.append(f"{payment.transaction_id}: {str(e)}")
                continue
        
        return jsonify({
            'success': True,
            'message': f'Processed {processed_count} out of {len(stuck_payments)} payments',
            'processed': processed_count,
            'total': len(stuck_payments),
            'errors': errors
        })
        
    except Exception as e:
        return jsonify({'error': f'Error processing stuck payments: {str(e)}'}), 500

@app.route('/user/chat')
def user_chat():
    if not session.get('user_id') or session.get('is_admin'):
        return redirect(url_for('login'))
    
    admins = User.query.filter_by(is_admin=True).all()
    current_user = User.query.get(session['user_id'])
    return render_template('user/chat.html', admins=admins, current_user=current_user, now=datetime.utcnow())

@app.route('/user/chat/<int:admin_id>')
def user_chat_admin(admin_id):
    if not session.get('user_id') or session.get('is_admin'):
        return redirect(url_for('login'))
    
    admin = User.query.get_or_404(admin_id)
    current_user = User.query.get(session['user_id'])
    if not admin.is_admin:
        return redirect(url_for('user_chat'))
    
    messages = Message.query.filter(
        ((Message.user_id == session['user_id']) & (Message.admin_id == admin_id)) |
        ((Message.user_id == admin_id) & (Message.admin_id == session['user_id']))
    ).order_by(Message.timestamp).all()
    
    return render_template('user/chat_admin.html', admin=admin, messages=messages, current_user=current_user, now=datetime.utcnow())

@app.route('/user/send_message', methods=['POST'])
def user_send_message():
    if not session.get('user_id') or session.get('is_admin'):
        return jsonify({'error': 'Unauthorized'}), 401
    
    admin_id = request.form.get('admin_id')
    content = request.form.get('content')
    
    if not admin_id or not content:
        return jsonify({'error': 'Missing data'}), 400
    
    message = Message(
        content=content,
        user_id=session['user_id'],
        admin_id=admin_id,
        is_from_admin=False
    )
    
    db.session.add(message)
    db.session.commit()
    
    return jsonify({
        'id': message.id,
        'content': message.content,
        'timestamp': message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
        'is_from_admin': False
    })

# API Routes for messages
@app.route('/api/messages/<int:user_id>/<int:admin_id>')
def get_messages(user_id, admin_id):
    messages = Message.query.filter(
        ((Message.user_id == user_id) & (Message.admin_id == admin_id)) |
        ((Message.user_id == admin_id) & (Message.admin_id == user_id))
    ).order_by(Message.timestamp).all()
    
    result = []
    for message in messages:
        result.append({
            'id': message.id,
            'content': message.content,
            'timestamp': message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            'is_from_admin': message.is_from_admin
        })
    
    return jsonify(result)

# Blog Management Routes
@app.route('/admin/blog/add', methods=['POST'])
@admin_required
def admin_add_blog():
    try:
        title = request.form.get('title')
        summary = request.form.get('summary')
        content = request.form.get('content')
        category = request.form.get('category')
        tags = request.form.get('tags')
        read_time_minutes = request.form.get('read_time_minutes', '5')
        read_time = f"{read_time_minutes} min read"
        
        # Handle image upload
        image = request.files.get('image')
        image_filename = None
        
        if image and image.filename:
            # Generate unique filename
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            unique_id = uuid.uuid4().hex[:8]
            image_filename = f"blog_{timestamp}_{unique_id}_{image.filename}"
            
            # Get file content for Bunny CDN upload
            file_content = image.read()
            
            # Upload to Bunny CDN Storage
            storage_url = f"https://{app.config['BUNNY_STORAGE_HOSTNAME']}/{app.config['BUNNY_STORAGE_ZONE']}/static/images/{image_filename}"
            
            headers = {
                'AccessKey': app.config['BUNNY_STORAGE_PASSWORD'],
                'Content-Type': 'application/octet-stream'
            }
            
            print(f"DEBUG: Uploading blog image to Bunny CDN: {storage_url}")
            try:
                response = requests.put(storage_url, headers=headers, data=file_content)
                print(f"DEBUG: Bunny CDN response status: {response.status_code}")
                
                if response.status_code == 201:
                    # Successfully uploaded to Bunny CDN - no need for local storage
                    print(f"DEBUG: Blog image uploaded to Bunny CDN successfully: {image_filename}")
                else:
                    # Fallback to local storage
                    os.makedirs(os.path.join(LOCAL_STATIC_FOLDER, 'uploads'), exist_ok=True)
                    image_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', image_filename)
                    image.seek(0)
                    image.save(image_path)
                    print(f"DEBUG: Blog image uploaded locally (CDN failed): {image_filename}")
            except Exception as cdn_error:
                print(f"DEBUG: CDN upload error: {cdn_error}")
                # Fallback to local storage
                os.makedirs(os.path.join(LOCAL_STATIC_FOLDER, 'uploads'), exist_ok=True)
                image_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', image_filename)
                image.seek(0)
                image.save(image_path)
        
        # Create new blog post
        new_blog = Blog(
            title=title,
            summary=summary,
            content=content,
            category=category,
            tags=tags,
            read_time=read_time,
            image=image_filename,
            author_id=session['user_id'],
            date=datetime.utcnow()
        )
        
        db.session.add(new_blog)
        db.session.commit()
        
        # Return JSON response for AJAX request
        return jsonify({
            'success': True,
            'message': 'Blog post published successfully!',
            'blog_id': new_blog.id
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error creating blog post: {str(e)}'
        })

@app.route('/admin/blog/edit/<int:blog_id>', methods=['POST'])
@admin_required
def admin_edit_blog(blog_id):
    try:
        blog = Blog.query.get_or_404(blog_id)
        
        blog.title = request.form.get('title')
        blog.summary = request.form.get('summary')
        blog.content = request.form.get('content')
        blog.category = request.form.get('category')
        blog.tags = request.form.get('tags')
        
        read_time_minutes = request.form.get('read_time_minutes', '5')
        blog.read_time = f"{read_time_minutes} min read"
        
        # Handle image upload
        image = request.files.get('image')
        keep_image = 'keep_image' in request.form
        
        if image and image.filename:
            # Delete old image if exists (local cleanup)
            if blog.image:
                old_image_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', blog.image)
                if os.path.exists(old_image_path):
                    os.remove(old_image_path)
            
            # Generate unique filename
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            unique_id = uuid.uuid4().hex[:8]
            image_filename = f"blog_{timestamp}_{unique_id}_{image.filename}"
            
            # Get file content for Bunny CDN upload
            file_content = image.read()
            
            # Upload to Bunny CDN Storage
            storage_url = f"https://{app.config['BUNNY_STORAGE_HOSTNAME']}/{app.config['BUNNY_STORAGE_ZONE']}/static/images/{image_filename}"
            
            headers = {
                'AccessKey': app.config['BUNNY_STORAGE_PASSWORD'],
                'Content-Type': 'application/octet-stream'
            }
            
            print(f"DEBUG: Uploading edited blog image to Bunny CDN: {storage_url}")
            try:
                response = requests.put(storage_url, headers=headers, data=file_content)
                print(f"DEBUG: Bunny CDN response status: {response.status_code}")
                
                if response.status_code == 201:
                    # Successfully uploaded to Bunny CDN - no need for local storage
                    print(f"DEBUG: Edited blog image uploaded to Bunny CDN successfully: {image_filename}")
                else:
                    # Fallback to local storage
                    os.makedirs(os.path.join(LOCAL_STATIC_FOLDER, 'uploads'), exist_ok=True)
                    image_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', image_filename)
                    image.seek(0)
                    image.save(image_path)
                    print(f"DEBUG: Edited blog image uploaded locally (CDN failed): {image_filename}")
            except Exception as cdn_error:
                print(f"DEBUG: CDN upload error: {cdn_error}")
                # Fallback to local storage
                os.makedirs(os.path.join(LOCAL_STATIC_FOLDER, 'uploads'), exist_ok=True)
                image_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', image_filename)
                image.seek(0)
                image.save(image_path)
            
            blog.image = image_filename
        elif not keep_image:
            # Delete old image and set to None
            if blog.image:
                old_image_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', blog.image)
                if os.path.exists(old_image_path):
                    os.remove(old_image_path)
            blog.image = None
        
        db.session.commit()
        
        # Return JSON response for AJAX request
        return jsonify({
            'success': True,
            'message': 'Blog post updated successfully!',
            'blog_id': blog.id
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error updating blog post: {str(e)}'
        })

@app.route('/admin/blog/delete/<int:blog_id>', methods=['POST'])
@admin_required
def admin_delete_blog(blog_id):
    try:
        blog = Blog.query.get_or_404(blog_id)
        
        # Delete image if exists
        if blog.image:
            image_path = os.path.join(LOCAL_STATIC_FOLDER, 'uploads', blog.image)
            if os.path.exists(image_path):
                os.remove(image_path)
        
        db.session.delete(blog)
        db.session.commit()
        
        # Return JSON response for AJAX request
        return jsonify({
            'success': True,
            'message': 'Blog post deleted successfully!'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error deleting blog post: {str(e)}'
        })

@app.route('/admin/get-blog/<int:blog_id>')
@admin_required
def admin_get_blog(blog_id):
    blog = Blog.query.get_or_404(blog_id)
    
    # Construct image URL if image exists
    image_url = None
    if blog.image:
        # Use Bunny CDN URL for blog images
        image_url = f"https://{app.config['BUNNY_CDN_HOSTNAME']}/static/images/{blog.image}"
    else:
        # Default blog image from Bunny CDN
        default_index = blog_id % 3 + 1
        image_url = f"https://{app.config['BUNNY_CDN_HOSTNAME']}/static/images/blog{default_index}.png"
    
    return jsonify({
        'success': True,
        'blog': {
            'id': blog.id,
            'title': blog.title,
            'summary': blog.summary,
            'content': blog.content,
            'category': blog.category,
            'tags': blog.tags,
            'read_time': blog.read_time,
            'date': blog.date.strftime('%B %d, %Y'),
            'image': blog.image,
            'image_url': image_url
        }
    })

@app.route('/admin/get-blogs')
@admin_required
def admin_get_blogs():
    blogs = Blog.query.order_by(Blog.date.desc()).all()
    
    blog_list = []
    for blog in blogs:
        # Construct image URL
        image_url = None
        if blog.image:
            # Use Bunny CDN URL for blog images
            image_url = f"https://{app.config['BUNNY_CDN_HOSTNAME']}/static/images/{blog.image}"
        else:
            # Default blog image from Bunny CDN
            default_index = blog.id % 3 + 1
            image_url = f"https://{app.config['BUNNY_CDN_HOSTNAME']}/static/images/blog{default_index}.png"
        
        blog_list.append({
            'id': blog.id,
            'title': blog.title,
            'category': blog.category,
            'date': blog.date.strftime('%b %d, %Y'),
            'read_time': blog.read_time,
            'image_url': image_url
        })
    
    return jsonify({
        'success': True,
        'blogs': blog_list
    })

# Homepage Content Management Routes
@app.route('/admin/debug-session', methods=['GET'])
def debug_session():
    """Debug endpoint to check session state"""
    return jsonify({
        'user_id': session.get('user_id'),
        'is_admin': session.get('is_admin'),
        'session_keys': list(session.keys())
    })



@app.route('/admin/upload-homepage-image', methods=['POST'])
@admin_required
def upload_homepage_image():
    """Upload image for homepage sections to Bunny CDN"""
    try:
        if 'image' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No image file provided'
            })
        
        file = request.files['image']
        if file.filename == '':
            return jsonify({
                'success': False,
                'message': 'No file selected'
            })
        
        # Check file type
        allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
        file_extension = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
        
        if file_extension not in allowed_extensions:
            return jsonify({
                'success': False,
                'message': 'Invalid file type. Allowed: PNG, JPG, JPEG, GIF, WEBP'
            })
        
        # Generate unique filename
        import uuid
        unique_filename = f"homepage_{uuid.uuid4().hex[:8]}_{file.filename}"
        
        # Upload to Bunny CDN Storage
        storage_url = f"https://{app.config['BUNNY_STORAGE_HOSTNAME']}/{app.config['BUNNY_STORAGE_ZONE']}/static/images/{unique_filename}"
        
        headers = {
            'AccessKey': app.config['BUNNY_STORAGE_PASSWORD'],
            'Content-Type': 'application/octet-stream'
        }
        
        # Read file content
        file.seek(0)  # Reset file pointer
        file_content = file.read()
        
        # Upload to Bunny CDN
        print(f"Uploading to Bunny CDN: {storage_url}")
        response = requests.put(storage_url, headers=headers, data=file_content)
        print(f"Bunny CDN response: {response.status_code} - {response.text}")
        
        if response.status_code == 201:
            # Successfully uploaded to Bunny CDN - no need for local storage
            return jsonify({
                'success': True,
                'filename': unique_filename,
                'message': 'Image uploaded successfully to Bunny CDN'
            })
        else:
            # Fall back to local storage if CDN fails
            print(f"CDN upload failed, saving locally instead")
            os.makedirs(os.path.join(LOCAL_STATIC_FOLDER, 'images'), exist_ok=True)
            upload_path = os.path.join(LOCAL_STATIC_FOLDER, 'images', unique_filename)
            file.seek(0)  # Reset file pointer
            file.save(upload_path)
            
            return jsonify({
                'success': True,
                'filename': unique_filename,
                'message': f'CDN upload failed (HTTP {response.status_code}), saved locally'
            })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Upload failed: {str(e)}'
        })

@app.route('/admin/get-homepage-content')
@admin_required
def get_homepage_content():
    """Get current homepage content"""
    try:
        hero_content = HomepageContent.get_hero_content()
        courses_content = HomepageContent.get_courses_content()
        features_content = HomepageContent.get_features_content()
        videos_content = HomepageContent.get_videos_content()
        about_content = HomepageContent.get_about_content()
        cta_content = HomepageContent.get_cta_content()
        
        hero_data = None
        courses_data = None
        features_data = None
        videos_data = None
        about_data = None
        cta_data = None
        
        if hero_content:
            hero_data = {
                'hero_title': hero_content.hero_title,
                'hero_subtitle': hero_content.hero_subtitle,
                'hero_description': hero_content.hero_description,
                'hero_button_text': hero_content.hero_button_text,
                'hero_button_url': hero_content.hero_button_url,
                'hero_video_button_text': hero_content.hero_video_button_text,
                'hero_stats': hero_content.hero_stats,
                'hero_slider_images': hero_content.hero_slider_images
            }
        
        if courses_content:
            courses_data = {
                'courses_title': courses_content.courses_title,
                'courses_subtitle': courses_content.courses_subtitle,
                'courses_description': courses_content.courses_description,
                'courses_grid_title': courses_content.courses_grid_title,
                'courses_grid_badge': courses_content.courses_grid_badge,
                'courses_cards': courses_content.courses_cards,
                'courses_mini_slider_title': courses_content.courses_mini_slider_title,
                'courses_mini_slider_subtitle': courses_content.courses_mini_slider_subtitle,
                'courses_mini_slider_images': courses_content.courses_mini_slider_images
            }
        
        if features_content:
            features_data = {
                'features_title': features_content.features_title,
                'features_subtitle': features_content.features_subtitle,
                'features_items': features_content.features_items
            }
        
        if videos_content:
            videos_data = {
                'videos_title': videos_content.videos_title,
                'videos_subtitle': videos_content.videos_subtitle,
                'videos_youtube_link': videos_content.videos_youtube_link,
                'videos_items': videos_content.videos_items
            }
        
        if about_content:
            about_data = {
                'about_title': about_content.about_title,
                'about_content': about_content.about_content,
                'about_images': about_content.about_images,
                'about_points': about_content.about_points
            }
        
        if cta_content:
            cta_data = {
                'cta_title': cta_content.cta_title,
                'cta_content': cta_content.cta_content,
                'cta_button_text': cta_content.cta_button_text,
                'cta_button_url': cta_content.cta_button_url,
                'cta_images': cta_content.cta_images,
                'cta_points': cta_content.cta_points
            }
        
        return jsonify({
            'success': True,
            'hero': hero_data,
            'courses': courses_data,
            'features': features_data,
            'videos': videos_data,
            'about': about_data,
            'cta': cta_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error loading homepage content: {str(e)}'
        })

@app.route('/admin/get-default-homepage-content')
@admin_required
def get_default_homepage_content():
    """Get default homepage content"""
    try:
        hero_data = HomepageContent.get_default_hero_content()
        courses_data = HomepageContent.get_default_courses_content()
        features_data = HomepageContent.get_default_features_content()
        videos_data = HomepageContent.get_default_videos_content()
        about_data = HomepageContent.get_default_about_content()
        cta_data = HomepageContent.get_default_cta_content()
        
        return jsonify({
            'success': True,
            'hero': hero_data,
            'courses': courses_data,
            'features': features_data,
            'videos': videos_data,
            'about': about_data,
            'cta': cta_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error loading default content: {str(e)}'
        })

@app.route('/admin/save-homepage-content', methods=['POST'])
@admin_required
def save_homepage_content():
    """Save homepage content"""
    try:
        section = request.form.get('section')
        admin_id = session['user_id']
        
        if section == 'hero':
            # Deactivate existing hero content
            HomepageContent.query.filter_by(section_name='hero', is_active=True).update({'is_active': False})
            
            # Create new hero content
            hero_content = HomepageContent(
                section_name='hero',
                hero_title=request.form.get('hero_title'),
                hero_subtitle=request.form.get('hero_subtitle'),
                hero_description=request.form.get('hero_description'),
                hero_button_text=request.form.get('hero_button_text'),
                hero_button_url=request.form.get('hero_button_url'),
                hero_video_button_text=request.form.get('hero_video_button_text'),
                hero_stats=request.form.get('hero_stats'),
                hero_slider_images=request.form.get('hero_slider_images'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(hero_content)
            
        elif section == 'courses_showcase':
            # Deactivate existing courses content
            HomepageContent.query.filter_by(section_name='courses_showcase', is_active=True).update({'is_active': False})
            
            # Create new courses content
            courses_content = HomepageContent(
                section_name='courses_showcase',
                courses_title=request.form.get('courses_title'),
                courses_subtitle=request.form.get('courses_subtitle'),
                courses_description=request.form.get('courses_description'),
                courses_grid_title=request.form.get('courses_grid_title'),
                courses_grid_badge=request.form.get('courses_grid_badge'),
                courses_cards=request.form.get('courses_cards'),
                courses_mini_slider_title=request.form.get('courses_mini_slider_title'),
                courses_mini_slider_subtitle=request.form.get('courses_mini_slider_subtitle'),
                courses_mini_slider_images=request.form.get('courses_mini_slider_images'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(courses_content)
        
        elif section == 'features':
            # Deactivate existing features content
            HomepageContent.query.filter_by(section_name='features', is_active=True).update({'is_active': False})
            
            # Create new features content
            features_content = HomepageContent(
                section_name='features',
                features_title=request.form.get('features_title'),
                features_subtitle=request.form.get('features_subtitle'),
                features_items=request.form.get('features_items'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(features_content)
        
        elif section == 'videos':
            # Deactivate existing videos content
            HomepageContent.query.filter_by(section_name='videos', is_active=True).update({'is_active': False})
            
            # Create new videos content
            videos_content = HomepageContent(
                section_name='videos',
                videos_title=request.form.get('videos_title'),
                videos_subtitle=request.form.get('videos_subtitle'),
                videos_youtube_link=request.form.get('videos_youtube_link'),
                videos_items=request.form.get('videos_items'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(videos_content)
        
        elif section == 'about':
            # Deactivate existing about content
            HomepageContent.query.filter_by(section_name='about', is_active=True).update({'is_active': False})
            
            # Create new about content
            about_content = HomepageContent(
                section_name='about',
                about_title=request.form.get('about_title'),
                about_content=request.form.get('about_content'),
                about_images=request.form.get('about_images'),
                about_points=request.form.get('about_points'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(about_content)
        
        elif section == 'cta':
            # Deactivate existing cta content
            HomepageContent.query.filter_by(section_name='cta', is_active=True).update({'is_active': False})
            
            # Create new cta content
            cta_content = HomepageContent(
                section_name='cta',
                cta_title=request.form.get('cta_title'),
                cta_content=request.form.get('cta_content'),
                cta_button_text=request.form.get('cta_button_text'),
                cta_button_url=request.form.get('cta_button_url'),
                cta_images=request.form.get('cta_images'),
                cta_points=request.form.get('cta_points'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(cta_content)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'{section.replace("_", " ").title()} content saved successfully!'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error saving homepage content: {str(e)}'
        })

# Removed duplicate function - using main implementation in Homepage Content Management Routes section

# Duplicate function removed - keeping only the main implementation above

@app.route('/admin/reset-homepage-content', methods=['POST'])
@admin_required
def reset_homepage_content():
    """Reset homepage content to defaults"""
    try:
        admin_id = session['user_id']
        
        # Deactivate all existing content
        HomepageContent.query.update({'is_active': False})
        
        # Create default hero content
        hero_defaults = HomepageContent.get_default_hero_content()
        hero_content = HomepageContent(
            section_name='hero',
            hero_title=hero_defaults['hero_title'],
            hero_subtitle=hero_defaults.get('hero_subtitle', ''),
            hero_description=hero_defaults['hero_description'],
            hero_button_text=hero_defaults['hero_button_text'],
            hero_button_url=hero_defaults['hero_button_url'],
            hero_video_button_text=hero_defaults['hero_video_button_text'],
            hero_stats=hero_defaults['hero_stats'],
            hero_slider_images=hero_defaults['hero_slider_images'],
            admin_id=admin_id,
            is_active=True
        )
        db.session.add(hero_content)
        
        # Create default courses content
        courses_defaults = HomepageContent.get_default_courses_content()
        courses_content = HomepageContent(
            section_name='courses_showcase',
            courses_title=courses_defaults['courses_title'],
            courses_subtitle=courses_defaults['courses_subtitle'],
            courses_description=courses_defaults['courses_description'],
            courses_grid_title=courses_defaults['courses_grid_title'],
            courses_grid_badge=courses_defaults['courses_grid_badge'],
            courses_cards=courses_defaults['courses_cards'],
            courses_mini_slider_title=courses_defaults['courses_mini_slider_title'],
            courses_mini_slider_subtitle=courses_defaults['courses_mini_slider_subtitle'],
            courses_mini_slider_images=courses_defaults['courses_mini_slider_images'],
            admin_id=admin_id,
            is_active=True
        )
        db.session.add(courses_content)
        
        # Create default features content
        features_defaults = HomepageContent.get_default_features_content()
        features_content = HomepageContent(
            section_name='features',
            features_title=features_defaults['features_title'],
            features_subtitle=features_defaults['features_subtitle'],
            features_items=features_defaults['features_items'],
            admin_id=admin_id,
            is_active=True
        )
        db.session.add(features_content)
        
        # Create default videos content
        videos_defaults = HomepageContent.get_default_videos_content()
        videos_content = HomepageContent(
            section_name='videos',
            videos_title=videos_defaults['videos_title'],
            videos_subtitle=videos_defaults['videos_subtitle'],
            videos_youtube_link=videos_defaults['videos_youtube_link'],
            videos_items=videos_defaults['videos_items'],
            admin_id=admin_id,
            is_active=True
        )
        db.session.add(videos_content)
        
        # Create default about content
        about_defaults = HomepageContent.get_default_about_content()
        about_content = HomepageContent(
            section_name='about',
            about_title=about_defaults['about_title'],
            about_content=about_defaults['about_content'],
            about_images=about_defaults['about_images'],
            about_points=about_defaults['about_points'],
            admin_id=admin_id,
            is_active=True
        )
        db.session.add(about_content)
        
        # Create default cta content
        cta_defaults = HomepageContent.get_default_cta_content()
        cta_content = HomepageContent(
            section_name='cta',
            cta_title=cta_defaults['cta_title'],
            cta_content=cta_defaults['cta_content'],
            cta_button_text=cta_defaults['cta_button_text'],
            cta_button_url=cta_defaults['cta_button_url'],
            cta_images=cta_defaults['cta_images'],
            cta_points=cta_defaults['cta_points'],
            admin_id=admin_id,
            is_active=True
        )
        db.session.add(cta_content)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'All homepage sections reset to defaults successfully!'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error resetting homepage content: {str(e)}'
        })

@app.route('/admin/upload-about-image', methods=['POST'])
@admin_required
def upload_about_image():
    """Upload image for about page sections - UPDATED TO USE BUNNY CDN"""
    try:
        print("🔥 UPDATED upload_about_image function called - BUNNY CDN VERSION")
        # Debug logging
        print(f"Debug: session data: {dict(session)}")
        print(f"Debug: request content type: {request.content_type}")
        print(f"Debug: request method: {request.method}")
        print(f"Debug: files in request: {list(request.files.keys())}")
        print(f"Debug: form data: {dict(request.form)}")
        
        if 'image' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No image file provided'
            })
        
        file = request.files['image']
        image_type = request.form.get('type', 'about_image')
        
        if file.filename == '':
            return jsonify({
                'success': False,
                'message': 'No file selected'
            })
        
        # Check file type
        allowed_extensions = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
        file_extension = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
        
        if file_extension not in allowed_extensions:
            return jsonify({
                'success': False,
                'message': 'Invalid file type. Allowed: PNG, JPG, JPEG, GIF, WEBP'
            })
        
        # Set file size limits based on image type
        # No size limit for main about images (allow any size)
        if image_type == 'team_member_image':
            max_size = 800 * 1024  # 800KB for team member images
            
            # Check file size for team member images only
            file.seek(0, 2)  # Seek to end
            file_size = file.tell()
            file.seek(0)  # Reset to beginning
            
            if file_size > max_size:
                max_size_mb = max_size / (1024 * 1024)
                return jsonify({
                    'success': False,
                    'message': f'Image size must be less than {max_size_mb:.1f}MB for team member images'
                })
        
        # Generate unique filename
        import uuid
        unique_filename = f"about_{uuid.uuid4().hex[:8]}_{file.filename}"
        
        # Get file content for Bunny CDN upload
        file_content = file.read()
        
        # Upload to Bunny CDN Storage
        storage_url = f"https://{app.config['BUNNY_STORAGE_HOSTNAME']}/{app.config['BUNNY_STORAGE_ZONE']}/static/images/{unique_filename}"
        
        headers = {
            'AccessKey': app.config['BUNNY_STORAGE_PASSWORD'],
            'Content-Type': 'application/octet-stream'
        }
        
        print(f"DEBUG: About to upload to Bunny CDN: {storage_url}")
        try:
            response = requests.put(storage_url, headers=headers, data=file_content)
            print(f"DEBUG: Bunny CDN response status: {response.status_code}")
            print(f"DEBUG: Bunny CDN response text: {response.text[:200]}")
        except Exception as cdn_error:
            print(f"DEBUG: CDN upload error: {cdn_error}")
            # Fallback to local storage
            upload_path = os.path.join(LOCAL_STATIC_FOLDER, 'images', unique_filename)
            os.makedirs(os.path.dirname(upload_path), exist_ok=True)
            file.seek(0)
            file.save(upload_path)
            
            return jsonify({
                'success': True,
                'filename': unique_filename,
                'message': f'Image uploaded locally (CDN error: {str(cdn_error)})'
            })
        
        if response.status_code == 201:
            # Successfully uploaded to Bunny CDN - no need for local storage
            
            return jsonify({
                'success': True,
                'filename': unique_filename,
                'message': 'Image uploaded successfully to Bunny CDN'
            })
        else:
            # Fallback to local storage if CDN upload fails
            upload_path = os.path.join(LOCAL_STATIC_FOLDER, 'images', unique_filename)
            file.seek(0)
            file.save(upload_path)
            
            return jsonify({
                'success': True,
                'filename': unique_filename,
                'message': 'Image uploaded locally (CDN upload failed)'
            })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Upload failed: {str(e)}'
        })

@app.route('/admin/get-about-content')
@admin_required
def get_about_content():
    """Get current about page content"""
    try:
        main_about_content = AboutPageContent.get_main_about_content()
        mission_content = AboutPageContent.get_mission_content()
        team_content = AboutPageContent.get_team_content()
        
        main_about_data = None
        mission_data = None
        team_data = None
        
        if main_about_content:
            main_about_data = {
                'main_about_title': main_about_content.main_about_title,
                'main_about_subtitle': main_about_content.main_about_subtitle,
                'main_about_content': main_about_content.main_about_content,
                'main_about_images': main_about_content.main_about_images,
                'main_about_features': main_about_content.main_about_features
            }
        
        if mission_content:
            mission_data = {
                'mission_title': mission_content.mission_title,
                'mission_content': mission_content.mission_content,
                'mission_vision_title': mission_content.mission_vision_title,
                'mission_vision_content': mission_content.mission_vision_content,
                'mission_points': mission_content.mission_points,
                'vision_points': mission_content.vision_points
            }
        
        if team_content:
            team_data = {
                'team_title': team_content.team_title,
                'team_subtitle': team_content.team_subtitle,
                'team_members': team_content.team_members
            }
        
        return jsonify({
            'success': True,
            'main_about': main_about_data,
            'mission': mission_data,
            'team': team_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error loading about content: {str(e)}'
        })

@app.route('/admin/get-default-about-content')
@admin_required
def get_default_about_content():
    """Get default about page content"""
    try:
        main_about_data = AboutPageContent.get_default_main_about_content()
        mission_data = AboutPageContent.get_default_mission_content()
        team_data = AboutPageContent.get_default_team_content()
        
        return jsonify({
            'success': True,
            'main_about': main_about_data,
            'mission': mission_data,
            'team': team_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error loading default content: {str(e)}'
        })

@app.route('/admin/save-about-content', methods=['POST'])
@admin_required
def save_about_content():
    """Save about page content"""
    try:
        section = request.form.get('section')
        admin_id = session['user_id']
        
        if section == 'main_about':
            # Deactivate existing main about content
            AboutPageContent.query.filter_by(section_name='main_about', is_active=True).update({'is_active': False})
            
            # Create new main about content
            main_about_content = AboutPageContent(
                section_name='main_about',
                main_about_title=request.form.get('main_about_title'),
                main_about_subtitle=request.form.get('main_about_subtitle'),
                main_about_content=request.form.get('main_about_content'),
                main_about_images=request.form.get('main_about_images'),
                main_about_features=request.form.get('main_about_features'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(main_about_content)
            
        elif section == 'mission':
            # Deactivate existing mission content
            AboutPageContent.query.filter_by(section_name='mission', is_active=True).update({'is_active': False})
            
            # Create new mission content
            mission_content = AboutPageContent(
                section_name='mission',
                mission_title=request.form.get('mission_title'),
                mission_content=request.form.get('mission_content'),
                mission_vision_title=request.form.get('mission_vision_title'),
                mission_vision_content=request.form.get('mission_vision_content'),
                mission_points=request.form.get('mission_points'),
                vision_points=request.form.get('vision_points'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(mission_content)
        
        elif section == 'team':
            # Deactivate existing team content
            AboutPageContent.query.filter_by(section_name='team', is_active=True).update({'is_active': False})
            
            # Create new team content
            team_content = AboutPageContent(
                section_name='team',
                team_title=request.form.get('team_title'),
                team_subtitle=request.form.get('team_subtitle'),
                team_members=request.form.get('team_members'),
                admin_id=admin_id,
                is_active=True
            )
            db.session.add(team_content)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'{section.replace("_", " ").title()} content saved successfully!'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error saving about content: {str(e)}'
        })

@app.route('/admin/reset-about-content', methods=['POST'])
@admin_required
def reset_about_content():
    """Reset about page content to defaults"""
    try:
        admin_id = session['user_id']
        
        # Deactivate all existing content
        AboutPageContent.query.update({'is_active': False})
        
        # Create default main about content
        main_about_defaults = AboutPageContent.get_default_main_about_content()
        main_about_content = AboutPageContent(
            section_name='main_about',
            main_about_title=main_about_defaults['main_about_title'],
            main_about_subtitle=main_about_defaults['main_about_subtitle'],
            main_about_content=main_about_defaults['main_about_content'],
            main_about_images=main_about_defaults['main_about_images'],
            main_about_features=main_about_defaults['main_about_features'],
            admin_id=admin_id,
            is_active=True
        )
        db.session.add(main_about_content)
        
        # Create default mission content
        mission_defaults = AboutPageContent.get_default_mission_content()
        mission_content = AboutPageContent(
            section_name='mission',
            mission_title=mission_defaults['mission_title'],
            mission_content=mission_defaults['mission_content'],
            mission_vision_title=mission_defaults['mission_vision_title'],
            mission_vision_content=mission_defaults['mission_vision_content'],
            mission_points=mission_defaults['mission_points'],
            vision_points=mission_defaults['vision_points'],
            admin_id=admin_id,
            is_active=True
        )
        db.session.add(mission_content)
        
        # Create default team content
        team_defaults = AboutPageContent.get_default_team_content()
        team_content = AboutPageContent(
            section_name='team',
            team_title=team_defaults['team_title'],
            team_subtitle=team_defaults['team_subtitle'],
            team_members=team_defaults['team_members'],
            admin_id=admin_id,
            is_active=True
        )
        db.session.add(team_content)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'All about page sections reset to defaults successfully!'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error resetting about content: {str(e)}'
        })

# Function to initialize the database and create admin user
def migrate_database():
    """Add missing columns to existing database"""
    try:
        from sqlalchemy import text
        
        # Add discount_percent column to course table if it doesn't exist
        try:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE course ADD COLUMN discount_percent FLOAT'))
                conn.commit()
            print("Added discount_percent column to course table")
        except Exception as e:
            if "duplicate column name" in str(e).lower() or "already exists" in str(e).lower():
                print("discount_percent column already exists in course table")
            else:
                print(f"Error adding discount_percent to course: {e}")
        
        # Add discounted_price column to course table if it doesn't exist
        try:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE course ADD COLUMN discounted_price FLOAT'))
                conn.commit()
            print("Added discounted_price column to course table")
        except Exception as e:
            if "duplicate column name" in str(e).lower() or "already exists" in str(e).lower():
                print("discounted_price column already exists in course table")
            else:
                print(f"Error adding discounted_price to course: {e}")
        
        # Add discount_percent column to ebook table if it doesn't exist
        try:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE ebook ADD COLUMN discount_percent FLOAT'))
                conn.commit()
            print("Added discount_percent column to ebook table")
        except Exception as e:
            if "duplicate column name" in str(e).lower() or "already exists" in str(e).lower():
                print("discount_percent column already exists in ebook table")
            else:
                print(f"Error adding discount_percent to ebook: {e}")
        
        # Add discounted_price column to ebook table if it doesn't exist
        try:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE ebook ADD COLUMN discounted_price FLOAT'))
                conn.commit()
            print("Added discounted_price column to ebook table")
        except Exception as e:
            if "duplicate column name" in str(e).lower() or "already exists" in str(e).lower():
                print("discounted_price column already exists in ebook table")
            else:
                print(f"Error adding discounted_price to ebook: {e}")
        
        # Add missing columns to video_lesson table
        video_lesson_columns = [
            ('video_url', 'VARCHAR(500)'),
            ('bunny_video_id', 'VARCHAR(100)'),
            ('storage_path', 'VARCHAR(500)'),
            ('duration', 'INTEGER'),
            ('is_preview', 'BOOLEAN DEFAULT FALSE'),
            ('instructions', 'TEXT'),
            ('external_links', 'TEXT'),
            ('created_at', 'DATETIME'),
            ('updated_at', 'DATETIME')
        ]
        
        for column_name, column_type in video_lesson_columns:
            try:
                with db.engine.connect() as conn:
                    conn.execute(text(f'ALTER TABLE video_lesson ADD COLUMN {column_name} {column_type}'))
                    conn.commit()
                print(f"Added {column_name} column to video_lesson table")
            except Exception as e:
                if "duplicate column name" in str(e).lower() or "already exists" in str(e).lower():
                    print(f"{column_name} column already exists in video_lesson table")
                else:
                    print(f"Error adding {column_name} to video_lesson: {e}")
        
        # Add missing columns to lesson_progress table
        lesson_progress_columns = [
            ('user_id', 'INTEGER'),
            ('lesson_id', 'INTEGER'),
            ('watched_duration', 'INTEGER DEFAULT 0'),
            ('is_completed', 'BOOLEAN DEFAULT FALSE'),
            ('last_watched_at', 'DATETIME'),
            ('completion_percentage', 'FLOAT DEFAULT 0.0')
        ]
        
        for column_name, column_type in lesson_progress_columns:
            try:
                with db.engine.connect() as conn:
                    conn.execute(text(f'ALTER TABLE lesson_progress ADD COLUMN {column_name} {column_type}'))
                    conn.commit()
                print(f"Added {column_name} column to lesson_progress table")
            except Exception as e:
                if "duplicate column name" in str(e).lower() or "already exists" in str(e).lower():
                    print(f"{column_name} column already exists in lesson_progress table")
                else:
                    print(f"Error adding {column_name} to lesson_progress: {e}")
        
        # Fix bunny_video_id column to allow NULL values (SQLite doesn't support ALTER COLUMN, so we'll recreate table if needed)
        try:
            with db.engine.connect() as conn:
                # Check if the column allows NULL
                result = conn.execute(text("PRAGMA table_info(video_lesson)"))
                columns = result.fetchall()
                bunny_video_id_info = None
                for col in columns:
                    if col[1] == 'bunny_video_id':  # col[1] is column name
                        bunny_video_id_info = col
                        break
                
                if bunny_video_id_info and bunny_video_id_info[3] == 1:  # col[3] is notnull flag
                    print("bunny_video_id column has NOT NULL constraint, recreating table...")
                    
                    # Create new table with correct schema
                    conn.execute(text("""
                        CREATE TABLE video_lesson_new (
                            id INTEGER PRIMARY KEY,
                            course_id INTEGER NOT NULL,
                            title VARCHAR(200) NOT NULL,
                            description TEXT,
                            video_url VARCHAR(500),
                            bunny_video_id VARCHAR(100),
                            order_index INTEGER DEFAULT 0,
                            duration INTEGER,
                            is_preview BOOLEAN DEFAULT FALSE,
                            instructions TEXT,
                            external_links TEXT,
                            created_at DATETIME,
                            updated_at DATETIME,
                            FOREIGN KEY (course_id) REFERENCES course (id)
                        )
                    """))
                    
                    # Copy data from old table
                    conn.execute(text("""
                        INSERT INTO video_lesson_new 
                        SELECT id, course_id, title, description, video_url, bunny_video_id, 
                               order_index, duration, is_preview, instructions, external_links, 
                               created_at, updated_at
                        FROM video_lesson
                    """))
                    
                    # Drop old table and rename new one
                    conn.execute(text("DROP TABLE video_lesson"))
                    conn.execute(text("ALTER TABLE video_lesson_new RENAME TO video_lesson"))
                    
                    conn.commit()
                    print("Successfully recreated video_lesson table with nullable bunny_video_id")
                else:
                    print("bunny_video_id column already allows NULL values")
                    
        except Exception as e:
            print(f"Error fixing bunny_video_id column: {e}")
            # If recreation fails, we'll continue - the upload might still work
        
        # Add email_verified column to user table if it doesn't exist
        try:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE "user" ADD COLUMN email_verified BOOLEAN'))
                conn.commit()
            print("Added email_verified column to user table")
        except Exception as e:
            if "duplicate column name" in str(e).lower() or "already exists" in str(e).lower():
                print("email_verified column already exists in user table")
            else:
                print(f"Error adding email_verified to user: {e}")
        
        # Update default values for existing records
        try:
            with db.engine.connect() as conn:
                conn.execute(text('UPDATE course SET discount_percent = 0.0 WHERE discount_percent IS NULL'))
                conn.execute(text('UPDATE ebook SET discount_percent = 0.0 WHERE discount_percent IS NULL'))
                conn.execute(text("UPDATE video_lesson SET is_preview = FALSE WHERE is_preview IS NULL"))
                conn.execute(text("UPDATE video_lesson SET created_at = datetime('now') WHERE created_at IS NULL"))
                conn.execute(text("UPDATE video_lesson SET updated_at = datetime('now') WHERE updated_at IS NULL"))
                # Set email_verified to FALSE for existing users (they need to verify)
                conn.execute(text('UPDATE "user" SET email_verified = FALSE WHERE email_verified IS NULL'))
                conn.commit()
            print("Updated default values for all columns")
        except Exception as e:
            print(f"Error updating default values: {e}")
        
    except Exception as e:
        print(f"Migration error: {e}")

def init_db():
    # No need to create local upload directories - using Bunny CDN now
    
    # Create database tables
    db.create_all()
    
    # Run database migration for existing installations
    migrate_database()
    
    # Check if admin exists, if not create one
    admin_email = 'admin@skillfinesse.com'
    admin = User.query.filter_by(email=admin_email).first()
    print(f"Checking for admin user: {'Found' if admin else 'Not found'}")
    
    if not admin:
        admin = User(
            first_name='Masud Ashraf',
            last_name='Taha',
            username='admin@skillfinesse.com',  # Using email as username
            email=admin_email,
            phone_number='1786661453',  # Valid Bangladesh mobile number format (10 digits without code)
            country_code='+880',
            country='Bangladesh',
            birth_date=date(1994, 1, 1),  # This makes them 30 years old
            gender='prefer_not_to_say',
            password=generate_password_hash('MyWebsite@123'),
            is_admin=True,
            phone_verified=True
        )
        db.session.add(admin)
        db.session.commit()
        print("Admin user created successfully!")
    
    # Create default homepage content if none exists
    if HomepageContent.query.count() == 0 and admin:
        import json
        
        # Create default hero content
        hero_defaults = HomepageContent.get_default_hero_content()
        hero_content = HomepageContent(
            section_name='hero',
            hero_title=hero_defaults['hero_title'],
            hero_subtitle=hero_defaults.get('hero_subtitle', 'Transform Your Career with Expert-Led Courses'),
            hero_description=hero_defaults['hero_description'],
            hero_button_text=hero_defaults['hero_button_text'],
            hero_button_url=hero_defaults['hero_button_url'],
            hero_video_button_text=hero_defaults['hero_video_button_text'],
            hero_stats=hero_defaults['hero_stats'],
            hero_slider_images=hero_defaults['hero_slider_images'],
            admin_id=admin.id,
            is_active=True
        )
        db.session.add(hero_content)
        
        # Create default courses content
        courses_defaults = HomepageContent.get_default_courses_content()
        courses_content = HomepageContent(
            section_name='courses_showcase',
            courses_title=courses_defaults['courses_title'],
            courses_subtitle=courses_defaults['courses_subtitle'],
            courses_description=courses_defaults['courses_description'],
            courses_grid_title=courses_defaults['courses_grid_title'],
            courses_grid_badge=courses_defaults['courses_grid_badge'],
            courses_cards=courses_defaults['courses_cards'],
            courses_mini_slider_title=courses_defaults['courses_mini_slider_title'],
            courses_mini_slider_subtitle=courses_defaults['courses_mini_slider_subtitle'],
            courses_mini_slider_images=courses_defaults['courses_mini_slider_images'],
            admin_id=admin.id,
            is_active=True
        )
        db.session.add(courses_content)
        
        # Create default features content
        features_defaults = HomepageContent.get_default_features_content()
        features_content = HomepageContent(
            section_name='features',
            features_title=features_defaults['features_title'],
            features_subtitle=features_defaults['features_subtitle'],
            features_items=features_defaults['features_items'],
            admin_id=admin.id,
            is_active=True
        )
        db.session.add(features_content)
        
        # Create default videos content
        videos_defaults = HomepageContent.get_default_videos_content()
        videos_content = HomepageContent(
            section_name='videos',
            videos_title=videos_defaults['videos_title'],
            videos_subtitle=videos_defaults['videos_subtitle'],
            videos_youtube_link=videos_defaults['videos_youtube_link'],
            videos_items=videos_defaults['videos_items'],
            admin_id=admin.id,
            is_active=True
        )
        db.session.add(videos_content)
        
        # Create default about content
        about_defaults = HomepageContent.get_default_about_content()
        about_content = HomepageContent(
            section_name='about',
            about_title=about_defaults['about_title'],
            about_content=about_defaults['about_content'],
            about_images=about_defaults['about_images'],
            about_points=about_defaults['about_points'],
            admin_id=admin.id,
            is_active=True
        )
        db.session.add(about_content)
        
        # Create default cta content
        cta_defaults = HomepageContent.get_default_cta_content()
        cta_content = HomepageContent(
            section_name='cta',
            cta_title=cta_defaults['cta_title'],
            cta_content=cta_defaults['cta_content'],
            cta_button_text=cta_defaults['cta_button_text'],
            cta_button_url=cta_defaults['cta_button_url'],
            cta_images=cta_defaults['cta_images'],
            cta_points=cta_defaults['cta_points'],
            admin_id=admin.id,
            is_active=True
        )
        db.session.add(cta_content)
        
        db.session.commit()
        print("Default homepage content created successfully!")
    # Create default about page content if none exists
    if AboutPageContent.query.count() == 0 and admin:
        import json
        
        # Create default main about content
        main_about_defaults = AboutPageContent.get_default_main_about_content()
        main_about_content = AboutPageContent(
            section_name='main_about',
            main_about_title=main_about_defaults['main_about_title'],
            main_about_subtitle=main_about_defaults['main_about_subtitle'],
            main_about_content=main_about_defaults['main_about_content'],
            main_about_images=main_about_defaults['main_about_images'],
            main_about_features=main_about_defaults['main_about_features'],
            admin_id=admin.id,
            is_active=True
        )
        db.session.add(main_about_content)
        
        # Create default mission content
        mission_defaults = AboutPageContent.get_default_mission_content()
        mission_content = AboutPageContent(
            section_name='mission',
            mission_title=mission_defaults['mission_title'],
            mission_content=mission_defaults['mission_content'],
            mission_vision_title=mission_defaults['mission_vision_title'],
            mission_vision_content=mission_defaults['mission_vision_content'],
            mission_points=mission_defaults['mission_points'],
            vision_points=mission_defaults['vision_points'],
            admin_id=admin.id,
            is_active=True
        )
        db.session.add(mission_content)
        
        # Create default team content
        team_defaults = AboutPageContent.get_default_team_content()
        team_content = AboutPageContent(
            section_name='team',
            team_title=team_defaults['team_title'],
            team_subtitle=team_defaults['team_subtitle'],
            team_members=team_defaults['team_members'],
            admin_id=admin.id,
            is_active=True
        )
        db.session.add(team_content)
        
        db.session.commit()
        print("Default about page content created successfully!")
        
    # Create sample blog posts if none exist
    if Blog.query.count() == 0:
        sample_blogs = [
            {
                'title': '10 Essential Web Development Tools for 2025',
                'summary': 'Discover the must-have tools that will boost your productivity and help you create better websites faster.',
                'content': '<p>This is a sample blog post about web development tools.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'Web Development',
                'read_time': '5 min read',
                'tags': 'Web Development, Technology, Tools'
            },
            {
                'title': 'How to Build a Career in Data Science from Scratch',
                'summary': 'Learn the step-by-step approach to transition into a rewarding career in data science, even without prior experience.',
                'content': '<p>This is a sample blog post about data science careers.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'Data Science',
                'read_time': '8 min read',
                'tags': 'Data Science, Career, Technology'
            },
            {
                'title': '7 Soft Skills Every Tech Professional Needs in 2025',
                'summary': 'Technical skills are important, but these soft skills will truly set you apart in the competitive tech industry.',
                'content': '<p>This is a sample blog post about soft skills for tech professionals.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'Career Growth',
                'read_time': '6 min read',
                'tags': 'Career, Soft Skills, Professional Development'
            },
            {
                'title': '5 Effective Learning Techniques Based on Cognitive Science',
                'summary': 'Science-backed strategies to help you learn faster, retain more information, and apply knowledge effectively.',
                'content': '<p>This is a sample blog post about effective learning techniques.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'Learning',
                'read_time': '7 min read',
                'tags': 'Learning, Education, Cognitive Science'
            },
            {
                'title': 'Flutter vs React Native: Which One Should You Choose in 2025?',
                'summary': 'A comprehensive comparison of the two most popular cross-platform mobile development frameworks.',
                'content': '<p>This is a sample blog post comparing Flutter and React Native.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'Mobile Development',
                'read_time': '9 min read',
                'tags': 'Mobile Development, Flutter, React Native'
            },
            {
                'title': 'The Psychology of Color in UI Design: How to Use Colors Effectively',
                'summary': 'Learn how color choices impact user perception and behavior, and how to create color schemes that convert.',
                'content': '<p>This is a sample blog post about color psychology in UI design.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'UI/UX Design',
                'read_time': '6 min read',
                'tags': 'UI/UX Design, Psychology, Color Theory'
            },
            {
                'title': 'Top Programming Languages to Learn in 2025',
                'summary': 'Stay ahead of the curve by mastering these in-demand programming languages that employers are looking for.',
                'content': '<p>This is a sample blog post about programming languages to learn.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'Programming',
                'read_time': '7 min read',
                'tags': 'Programming, Languages, Technology'
            },
            {
                'title': 'How to Build a Strong Personal Brand as a Developer',
                'summary': 'Discover strategies to showcase your skills, build your online presence, and stand out in the competitive tech market.',
                'content': '<p>This is a sample blog post about personal branding for developers.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'Career Growth',
                'read_time': '8 min read',
                'tags': 'Career, Personal Brand, Development'
            },
            {
                'title': 'Introduction to Machine Learning: A Beginner\'s Guide',
                'summary': 'Get started with machine learning concepts, algorithms, and practical applications in this comprehensive guide.',
                'content': '<p>This is a sample blog post introducing machine learning.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'Data Science',
                'read_time': '10 min read',
                'tags': 'Machine Learning, AI, Data Science'
            },
            {
                'title': 'Creating Responsive Websites: Best Practices for 2025',
                'summary': 'Learn the latest techniques and standards for building websites that look great on all devices and screen sizes.',
                'content': '<p>This is a sample blog post about responsive web design.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'Web Development',
                'read_time': '7 min read',
                'tags': 'Web Development, Responsive Design, CSS'
            },
            {
                'title': 'The Future of Artificial Intelligence in Education',
                'summary': 'Explore how AI is transforming educational experiences and what to expect in the coming years.',
                'content': '<p>This is a sample blog post about AI in education.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'Technology',
                'read_time': '9 min read',
                'tags': 'AI, Education, Technology'
            },
            {
                'title': 'Essential UX Research Methods Every Designer Should Know',
                'summary': 'Discover the key research techniques that will help you create user-centered designs that meet real user needs.',
                'content': '<p>This is a sample blog post about UX research methods.</p><p>In a real application, this would have more detailed content.</p>',
                'category': 'UI/UX Design',
                'read_time': '8 min read',
                'tags': 'UX Research, Design, Methodology'
            }
        ]
        
        # Add sample blogs to database
        for blog_data in sample_blogs:
            blog = Blog(**blog_data)
            if admin:
                blog.author_id = admin.id
            db.session.add(blog)
        
        db.session.commit()
        print("Sample blog posts created successfully!")

# Contact Management API Routes
@app.route('/admin/contact-message/<int:message_id>')
@admin_required
def get_contact_message(message_id):
    """Get specific contact message details"""
    try:
        message = ContactMessage.query.get_or_404(message_id)
        return jsonify({
            'success': True,
            'message': {
                'id': message.id,
                'first_name': message.first_name,
                'last_name': message.last_name,
                'email': message.email,
                'subject': message.subject,
                'message': message.message,
                'submitted_at': message.submitted_at.isoformat(),
                'is_read': message.is_read,
                'status': message.status,
                'admin_reply': message.admin_reply,
                'replied_at': message.replied_at.isoformat() if message.replied_at else None,
                'replied_by': message.replied_by
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error loading contact message: {str(e)}'
        })

@app.route('/admin/contact-message/<int:message_id>/mark-read', methods=['POST'])
@admin_required
def mark_contact_message_read(message_id):
    """Mark a contact message as read"""
    try:
        message = ContactMessage.query.get_or_404(message_id)
        message.mark_as_read()
        
        return jsonify({
            'success': True,
            'message': 'Message marked as read successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error marking message as read: {str(e)}'
        })

@app.route('/admin/contact-messages/mark-all-read', methods=['POST'])
@admin_required
def mark_all_contact_messages_read():
    """Mark all contact messages as read"""
    try:
        ContactMessage.query.filter_by(is_read=False).update({'is_read': True})
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'All messages marked as read successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error marking all messages as read: {str(e)}'
        })

@app.route('/admin/contact-messages/mark-selected-read', methods=['POST'])
@admin_required
def mark_selected_contact_messages_read():
    """Mark selected contact messages as read"""
    try:
        data = request.get_json()
        message_ids = data.get('message_ids', [])
        
        if not message_ids:
            return jsonify({
                'success': False,
                'message': 'No message IDs provided'
            })
        
        # Update selected messages
        ContactMessage.query.filter(ContactMessage.id.in_(message_ids)).update(
            {'is_read': True}, synchronize_session=False
        )
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'{len(message_ids)} messages marked as read successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error marking selected messages as read: {str(e)}'
        })

@app.route('/admin/contact-messages/delete-selected', methods=['POST'])
@admin_required
def delete_selected_contact_messages():
    """Delete selected contact messages"""
    try:
        data = request.get_json()
        message_ids = data.get('message_ids', [])
        
        if not message_ids:
            return jsonify({
                'success': False,
                'message': 'No message IDs provided'
            })
        
        # Delete selected messages
        ContactMessage.query.filter(ContactMessage.id.in_(message_ids)).delete(
            synchronize_session=False
        )
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'{len(message_ids)} messages deleted successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error deleting selected messages: {str(e)}'
        })

@app.route('/admin/contact-message/<int:message_id>', methods=['DELETE'])
@admin_required
def delete_contact_message(message_id):
    """Delete a contact message"""
    try:
        message = ContactMessage.query.get_or_404(message_id)
        db.session.delete(message)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Contact message deleted successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error deleting contact message: {str(e)}'
        })

@app.route('/admin/contact-message/reply', methods=['POST'])
@admin_required
def reply_to_contact_message():
    """Send reply to a contact message"""
    try:
        message_id = request.form.get('message_id')
        admin_reply = request.form.get('admin_reply')
        
        if not message_id or not admin_reply:
            return jsonify({
                'success': False,
                'message': 'Message ID and reply content are required'
            })
        
        message = ContactMessage.query.get_or_404(message_id)
        message.add_admin_reply(admin_reply, session['user_id'])
        db.session.commit()
        
        # Here you could also send an email notification to the user
        # using the existing email utility functions
        
        return jsonify({
            'success': True,
            'message': 'Reply sent successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error sending reply: {str(e)}'
        })

# Admin eBook Management Routes
@app.route('/admin/ebook/create', methods=['GET', 'POST'])
@admin_required
def admin_create_ebook():
    """Create a new eBook"""
    # Handle GET request - redirect to admin dashboard
    if request.method == 'GET':
        return redirect(url_for('admin_dashboard'))
    
    try:
        # Get form data
        name = request.form.get('name')
        author = request.form.get('author')
        description = request.form.get('description')
        price = float(request.form.get('price'))
        category = request.form.get('category')
        pages = request.form.get('pages')
        language = request.form.get('language', 'English')
        isbn = request.form.get('isbn')
        publication_date = request.form.get('publication_date')
        # Public discount handling
        public_discount_percent = request.form.get('public_discount_percent')
        public_discount_percent = float(public_discount_percent) if public_discount_percent else 0
        # Multiple private coupons handling (same format as course creation)
        coupons_data = {}
        for key in request.form.keys():
            if key.startswith('coupons[') and key.endswith('][code]'):
                coupon_index = key.split('[')[1].split(']')[0]
                coupons_data[coupon_index] = {
                    'code': request.form.get(key),
                    'discount_percent': request.form.get(f'coupons[{coupon_index}][discount_percent]'),
                    'usage_limit': request.form.get(f'coupons[{coupon_index}][usage_limit]'),
                    'valid_from': request.form.get(f'coupons[{coupon_index}][valid_from]'),
                    'valid_until': request.form.get(f'coupons[{coupon_index}][valid_until]'),
                    'is_active': f'coupons[{coupon_index}][is_active]' in request.form
                }
        is_published = True  # Auto-publish ebooks created through admin panel
        
        # Handle file uploads
        cover_image = request.files.get('cover_image')
        pdf_file = request.files.get('pdf_file')
        
        # Calculate discounted price if public discount is set
        discounted_price = price * (100 - public_discount_percent) / 100 if public_discount_percent > 0 else price
        
        # Create eBook instance
        ebook = Ebook(
            name=name,
            author=author,
            description=description,
            price=price,
            discount_percent=public_discount_percent,
            discounted_price=discounted_price,
            category=category,
            pages=int(pages) if pages else None,
            language=language,
            isbn=isbn,
            publication_date=datetime.strptime(publication_date, '%Y-%m-%d').date() if publication_date else None,
            is_published=is_published,
            admin_id=session['user_id']
        )
        
        # Handle cover image upload to Bunny CDN
        if cover_image and cover_image.filename:
            try:
                from bunny_cdn import bunny_cdn
                
                # Upload cover image to Bunny CDN
                upload_result = bunny_cdn.upload_ebook_file(cover_image, cover_image.filename, 'image')
                
                if upload_result['success']:
                    # Store the Bunny CDN filename
                    ebook.cover_image = upload_result['filename']
                    print(f"✅ Cover image uploaded to Bunny CDN: {upload_result['url']}")
                else:
                    print(f"❌ Failed to upload cover image to Bunny CDN: {upload_result['error']}")
                    # Fallback to local storage
                    filename = secure_filename(cover_image.filename)
                    filename = f"{uuid.uuid4()}_{filename}"
                    cover_path = os.path.join(app.root_path, 'static', 'images', 'ebook_cover', filename)
                    os.makedirs(os.path.dirname(cover_path), exist_ok=True)
                    cover_image.save(cover_path)
                    ebook.cover_image = filename
                    
            except Exception as e:
                print(f"❌ Error uploading cover image to Bunny CDN: {str(e)}")
                # Fallback to local storage
                filename = secure_filename(cover_image.filename)
                filename = f"{uuid.uuid4()}_{filename}"
                cover_path = os.path.join(app.root_path, 'static', 'images', 'ebook_cover', filename)
                os.makedirs(os.path.dirname(cover_path), exist_ok=True)
                cover_image.save(cover_path)
                ebook.cover_image = filename
        
        # Handle PDF file upload to Bunny CDN
        if pdf_file and pdf_file.filename:
            try:
                from bunny_cdn import bunny_cdn
                
                # Upload PDF to Bunny CDN
                upload_result = bunny_cdn.upload_ebook_file(pdf_file, pdf_file.filename, 'pdf')
                
                if upload_result['success']:
                    # Store the Bunny CDN URL and filename
                    ebook.pdf_file = upload_result['filename']  # Store the filename for database
                    ebook.pdf_url = upload_result['url']  # Store the full CDN URL
                    print(f"✅ PDF uploaded to Bunny CDN: {upload_result['url']}")
                else:
                    print(f"❌ Failed to upload PDF to Bunny CDN: {upload_result['error']}")
                    # Fallback to local storage
                    filename = secure_filename(pdf_file.filename)
                    filename = f"{uuid.uuid4()}_{filename}"
                    pdf_path = os.path.join(app.root_path, 'static', 'ebooks', filename)
                    os.makedirs(os.path.dirname(pdf_path), exist_ok=True)
                    pdf_file.save(pdf_path)
                    ebook.pdf_file = filename
                    ebook.pdf_url = None  # No CDN URL for local files
                    
            except Exception as e:
                print(f"❌ Error uploading to Bunny CDN: {str(e)}")
                # Fallback to local storage
                filename = secure_filename(pdf_file.filename)
                filename = f"{uuid.uuid4()}_{filename}"
                pdf_path = os.path.join(app.root_path, 'static', 'ebooks', filename)
                os.makedirs(os.path.dirname(pdf_path), exist_ok=True)
                pdf_file.save(pdf_path)
                ebook.pdf_file = filename
                ebook.pdf_url = None
        
        db.session.add(ebook)
        db.session.flush()  # Flush to get the ebook ID
        
        # Create private coupons
        for coupon_data in coupons_data.values():
            if coupon_data['code'] and coupon_data['discount_percent']:
                try:
                    # Parse datetime fields if provided
                    valid_from = None
                    valid_until = None
                    
                    if coupon_data.get('valid_from'):
                        try:
                            valid_from = datetime.strptime(coupon_data['valid_from'], '%Y-%m-%dT%H:%M')
                        except:
                            pass
                    
                    if coupon_data.get('valid_until'):
                        try:
                            valid_until = datetime.strptime(coupon_data['valid_until'], '%Y-%m-%dT%H:%M')
                        except:
                            pass
                    
                    new_coupon = EbookCoupon(
                        ebook_id=ebook.id,
                        code=coupon_data['code'].upper(),
                        discount_percent=int(coupon_data['discount_percent']),
                        usage_limit=int(coupon_data['usage_limit']) if coupon_data.get('usage_limit') else None,
                        valid_from=valid_from,
                        valid_until=valid_until,
                        is_active=coupon_data.get('is_active', True)
                    )
                    db.session.add(new_coupon)
                except Exception as coupon_error:
                    print(f"Error creating ebook coupon {coupon_data['code']}: {coupon_error}")
                    continue
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'eBook created successfully!',
            'ebook_id': ebook.id
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error creating eBook: {str(e)}'
        })

@app.route('/admin/ebook/<int:ebook_id>')
@admin_required
def admin_get_ebook(ebook_id):
    """Get eBook details for editing"""
    try:
        ebook = Ebook.query.get_or_404(ebook_id)
        
        # Get associated coupons
        coupons = EbookCoupon.query.filter_by(ebook_id=ebook.id).all()
        coupons_data = []
        for coupon in coupons:
            coupons_data.append({
                'id': coupon.id,
                'code': coupon.code,
                'discount_percent': coupon.discount_percent,
                'usage_limit': coupon.usage_limit,
                'usage_count': coupon.used_count,
                'valid_from': coupon.valid_from.isoformat() if coupon.valid_from else None,
                'valid_until': coupon.valid_until.isoformat() if coupon.valid_until else None,
                'is_active': coupon.is_active
            })
        
        return jsonify({
            'success': True,
            'ebook': {
                'id': ebook.id,
                'name': ebook.name,
                'author': ebook.author,
                'description': ebook.description,
                'price': ebook.price,
                'discount_percent': getattr(ebook, 'discount_percent', 0),
                'discounted_price': getattr(ebook, 'discounted_price', ebook.price),
                'category': ebook.category,
                'pages': ebook.pages,
                'language': ebook.language,
                'isbn': ebook.isbn,
                'publication_date': ebook.publication_date.isoformat() if ebook.publication_date else None,
                'is_published': ebook.is_published,
                'cover_image': ebook.cover_image,
                'pdf_file': ebook.pdf_file,
                'coupons': coupons_data
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error loading eBook: {str(e)}'
        })

@app.route('/admin/ebook/<int:ebook_id>/edit', methods=['POST'])
@admin_required
def admin_update_ebook(ebook_id):
    """Update an existing eBook"""
    try:
        ebook = Ebook.query.get_or_404(ebook_id)
        
        # Get form data (same as create)
        name = request.form.get('name')
        author = request.form.get('author')
        description = request.form.get('description')
        price = float(request.form.get('price'))
        category = request.form.get('category')
        pages = request.form.get('pages')
        language = request.form.get('language', 'English')
        isbn = request.form.get('isbn')
        publication_date = request.form.get('publication_date')
        # Public discount handling
        public_discount_percent = request.form.get('public_discount_percent')
        public_discount_percent = float(public_discount_percent) if public_discount_percent else 0
        # Multiple private coupons handling (same format as course creation)
        coupons_data = {}
        for key in request.form.keys():
            if key.startswith('coupons[') and key.endswith('][code]'):
                coupon_index = key.split('[')[1].split(']')[0]
                coupons_data[coupon_index] = {
                    'code': request.form.get(key),
                    'discount_percent': request.form.get(f'coupons[{coupon_index}][discount_percent]'),
                    'usage_limit': request.form.get(f'coupons[{coupon_index}][usage_limit]'),
                    'valid_from': request.form.get(f'coupons[{coupon_index}][valid_from]'),
                    'valid_until': request.form.get(f'coupons[{coupon_index}][valid_until]'),
                    'is_active': f'coupons[{coupon_index}][is_active]' in request.form
                }
        is_published = 'is_published' in request.form
        
        # Calculate discounted price if public discount is set
        discounted_price = price * (100 - public_discount_percent) / 100 if public_discount_percent > 0 else price
        
        # Update eBook fields
        ebook.name = name
        ebook.author = author
        ebook.description = description
        ebook.price = price
        ebook.discount_percent = public_discount_percent
        ebook.discounted_price = discounted_price
        ebook.category = category
        ebook.pages = int(pages) if pages else None
        ebook.language = language
        ebook.isbn = isbn
        ebook.publication_date = datetime.strptime(publication_date, '%Y-%m-%d').date() if publication_date else None
        ebook.is_published = is_published
        
        # Handle file uploads
        cover_image = request.files.get('cover_image')
        pdf_file = request.files.get('pdf_file')
        
        # Handle cover image upload
        if cover_image and cover_image.filename:
            filename = secure_filename(cover_image.filename)
            filename = f"{uuid.uuid4()}_{filename}"
            cover_path = os.path.join(app.root_path, 'static', 'images', 'ebook_cover', filename)
            os.makedirs(os.path.dirname(cover_path), exist_ok=True)
            cover_image.save(cover_path)
            ebook.cover_image = filename
        
        # Handle PDF file upload to Bunny CDN
        if pdf_file and pdf_file.filename:
            try:
                from bunny_cdn import bunny_cdn
                
                # Upload PDF to Bunny CDN
                upload_result = bunny_cdn.upload_ebook_file(pdf_file, pdf_file.filename, 'pdf')
                
                if upload_result['success']:
                    # Store the Bunny CDN URL and filename
                    ebook.pdf_file = upload_result['filename']  # Store the filename for database
                    ebook.pdf_url = upload_result['url']  # Store the full CDN URL
                    print(f"✅ PDF uploaded to Bunny CDN: {upload_result['url']}")
                else:
                    print(f"❌ Failed to upload PDF to Bunny CDN: {upload_result['error']}")
                    # Fallback to local storage
                    filename = secure_filename(pdf_file.filename)
                    filename = f"{uuid.uuid4()}_{filename}"
                    pdf_path = os.path.join(app.root_path, 'static', 'ebooks', filename)
                    os.makedirs(os.path.dirname(pdf_path), exist_ok=True)
                    pdf_file.save(pdf_path)
                    ebook.pdf_file = filename
                    ebook.pdf_url = None  # No CDN URL for local files
                    
            except Exception as e:
                print(f"❌ Error uploading to Bunny CDN: {str(e)}")
                # Fallback to local storage
                filename = secure_filename(pdf_file.filename)
                filename = f"{uuid.uuid4()}_{filename}"
                pdf_path = os.path.join(app.root_path, 'static', 'ebooks', filename)
                os.makedirs(os.path.dirname(pdf_path), exist_ok=True)
                pdf_file.save(pdf_path)
                ebook.pdf_file = filename
                ebook.pdf_url = None
        
        # Delete existing coupons for this ebook
        EbookCoupon.query.filter_by(ebook_id=ebook.id).delete()
        
        # Create new private coupons
        for coupon_data in coupons_data.values():
            if coupon_data['code'] and coupon_data['discount_percent']:
                try:
                    # Parse datetime fields if provided
                    valid_from = None
                    valid_until = None
                    
                    if coupon_data.get('valid_from'):
                        try:
                            valid_from = datetime.strptime(coupon_data['valid_from'], '%Y-%m-%dT%H:%M')
                        except:
                            pass
                    
                    if coupon_data.get('valid_until'):
                        try:
                            valid_until = datetime.strptime(coupon_data['valid_until'], '%Y-%m-%dT%H:%M')
                        except:
                            pass
                    
                    new_coupon = EbookCoupon(
                        ebook_id=ebook.id,
                        code=coupon_data['code'].upper(),
                        discount_percent=int(coupon_data['discount_percent']),
                        usage_limit=int(coupon_data['usage_limit']) if coupon_data.get('usage_limit') else None,
                        valid_from=valid_from,
                        valid_until=valid_until,
                        is_active=coupon_data.get('is_active', True)
                    )
                    db.session.add(new_coupon)
                except Exception as coupon_error:
                    print(f"Error creating ebook coupon {coupon_data['code']}: {coupon_error}")
                    continue
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'eBook updated successfully!'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error updating eBook: {str(e)}'
        })

@app.route('/admin/ebook/<int:ebook_id>/publish', methods=['POST'])
@admin_required
def admin_publish_ebook(ebook_id):
    """Publish an eBook"""
    try:
        ebook = Ebook.query.get_or_404(ebook_id)
        ebook.is_published = True
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'eBook published successfully!'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error publishing eBook: {str(e)}'
        })

@app.route('/admin/ebook/<int:ebook_id>/unpublish', methods=['POST'])
@admin_required
def admin_unpublish_ebook(ebook_id):
    """Unpublish an eBook"""
    try:
        ebook = Ebook.query.get_or_404(ebook_id)
        ebook.is_published = False
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'eBook unpublished successfully!'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error unpublishing eBook: {str(e)}'
        })

@app.route('/admin/ebook/<int:ebook_id>/delete', methods=['DELETE'])
@admin_required
def admin_delete_ebook(ebook_id):
    """Delete an eBook"""
    try:
        ebook = Ebook.query.get_or_404(ebook_id)
        
        # Delete associated files
        if ebook.cover_image:
            cover_path = os.path.join(app.root_path, 'static', 'images', 'ebook_cover', ebook.cover_image)
            if os.path.exists(cover_path):
                os.remove(cover_path)
        
        if ebook.pdf_file:
            pdf_path = os.path.join(app.root_path, 'static', 'ebooks', ebook.pdf_file)
            if os.path.exists(pdf_path):
                os.remove(pdf_path)
        
        db.session.delete(ebook)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'eBook deleted successfully!'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error deleting eBook: {str(e)}'
        })

# Policy Management API Routes
@app.route('/admin/api/policy/<policy_type>', methods=['GET'])
@admin_required
def get_policy(policy_type):
    """Get policy content by type"""
    try:
        policy = PolicyContent.get_or_create_default(policy_type)
        if policy:
            return jsonify({
                'success': True,
                'policy': {
                    'title': policy.title,
                    'last_updated': policy.last_updated,
                    'content': policy.content,
                    'updated_at': policy.updated_at.isoformat() if policy.updated_at else None
                }
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Policy not found'
            }), 404
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/admin/api/policy/<policy_type>', methods=['POST'])
@admin_required
def save_policy(policy_type):
    """Save or update policy content"""
    try:
        data = request.get_json()
        
        if not data or 'title' not in data or 'content' not in data:
            return jsonify({
                'success': False,
                'message': 'Title and content are required'
            }), 400
        
        # Get or create policy
        policy = PolicyContent.query.filter_by(policy_type=policy_type).first()
        if not policy:
            # Create new policy
            policy = PolicyContent(
                policy_type=policy_type,
                title=data['title'],
                last_updated=data.get('last_updated', 'Updated'),
                content=data['content'],
                admin_id=session.get('user_id')
            )
            db.session.add(policy)
        else:
            # Update existing policy
            policy.title = data['title']
            policy.last_updated = data.get('last_updated', 'Updated')
            policy.content = data['content']
            policy.admin_id = session.get('user_id')
            policy.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Policy saved successfully',
            'policy': {
                'title': policy.title,
                'last_updated': policy.last_updated,
                'content': policy.content,
                'updated_at': policy.updated_at.isoformat()
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/admin/api/policy/<policy_type>/reset', methods=['POST'])
@admin_required
def reset_policy(policy_type):
    """Reset policy to default content"""
    try:
        # Get default content
        default_content = PolicyContent.get_default_content(policy_type)
        if not default_content:
            return jsonify({
                'success': False,
                'message': 'No default content available for this policy type'
            }), 404
        
        # Get or create policy
        policy = PolicyContent.query.filter_by(policy_type=policy_type).first()
        if not policy:
            # Create new policy with default content
            policy = PolicyContent(
                policy_type=policy_type,
                title=default_content['title'],
                last_updated=default_content['last_updated'],
                content=default_content['content'],
                admin_id=session.get('user_id')
            )
            db.session.add(policy)
        else:
            # Update existing policy with default content
            policy.title = default_content['title']
            policy.last_updated = default_content['last_updated']
            policy.content = default_content['content']
            policy.admin_id = session.get('user_id')
            policy.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Policy reset to default successfully',
            'policy': {
                'title': policy.title,
                'last_updated': policy.last_updated,
                'content': policy.content,
                'updated_at': policy.updated_at.isoformat()
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

# ===== COUPON MANAGEMENT ROUTES =====
@app.route('/admin/coupons')
def admin_coupons():
    """Admin coupon management page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('dashboard'))
    
    return render_template('admin/sections/coupon_management.html')

@app.route('/admin/api/coupons', methods=['GET'])
def admin_get_coupons():
    """Get all coupons for admin"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False, 'message': 'Admin privileges required'}), 403
    
    try:
        # Get course coupons
        course_coupons = db.session.query(CourseCoupon, Course).join(Course).all()
        # Get ebook coupons
        ebook_coupons = db.session.query(EbookCoupon, Ebook).join(Ebook).all()
        
        course_data = []
        for coupon, course in course_coupons:
            is_valid, message = coupon.is_valid()
            course_data.append({
                'id': coupon.id,
                'type': 'course',
                'item_id': course.id,
                'item_name': course.title,
                'code': coupon.code,
                'discount_percent': coupon.discount_percent,
                'is_active': coupon.is_active,
                'usage_limit': coupon.usage_limit,
                'used_count': coupon.used_count,
                'valid_from': coupon.valid_from.isoformat() if coupon.valid_from else None,
                'valid_until': coupon.valid_until.isoformat() if coupon.valid_until else None,
                'created_at': coupon.created_at.isoformat(),
                'is_valid': is_valid,
                'validation_message': message
            })
        
        ebook_data = []
        for coupon, ebook in ebook_coupons:
            is_valid, message = coupon.is_valid()
            ebook_data.append({
                'id': coupon.id,
                'type': 'ebook',
                'item_id': ebook.id,
                'item_name': ebook.name,
                'code': coupon.code,
                'discount_percent': coupon.discount_percent,
                'is_active': coupon.is_active,
                'usage_limit': coupon.usage_limit,
                'used_count': coupon.used_count,
                'valid_from': coupon.valid_from.isoformat() if coupon.valid_from else None,
                'valid_until': coupon.valid_until.isoformat() if coupon.valid_until else None,
                'created_at': coupon.created_at.isoformat(),
                'is_valid': is_valid,
                'validation_message': message
            })
        
        return jsonify({
            'success': True,
            'coupons': {
                'courses': course_data,
                'ebooks': ebook_data
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/api/coupons', methods=['POST'])
def admin_create_coupon():
    """Create a new coupon"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False, 'message': 'Admin privileges required'}), 403
    
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['item_type', 'item_id', 'code', 'discount_percent']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'message': f'Missing required field: {field}'}), 400
        
        # Validate item type
        if data['item_type'] not in ['course', 'ebook']:
            return jsonify({'success': False, 'message': 'Invalid item type'}), 400
        
        # Validate discount percent
        discount_percent = float(data['discount_percent'])
        if discount_percent <= 0 or discount_percent > 100:
            return jsonify({'success': False, 'message': 'Discount percent must be between 1-100'}), 400
        
        # Parse dates if provided
        valid_from = None
        valid_until = None
        if data.get('valid_from'):
            valid_from = datetime.fromisoformat(data['valid_from'].replace('Z', '+00:00'))
        if data.get('valid_until'):
            valid_until = datetime.fromisoformat(data['valid_until'].replace('Z', '+00:00'))
        
        # Check if item exists
        if data['item_type'] == 'course':
            item = Course.query.get(data['item_id'])
            if not item:
                return jsonify({'success': False, 'message': 'Course not found'}), 404
            
            # Check for duplicate coupon code for this course
            existing = CourseCoupon.query.filter_by(
                course_id=data['item_id'], 
                code=data['code'].upper()
            ).first()
            if existing:
                return jsonify({'success': False, 'message': 'Coupon code already exists for this course'}), 400
            
            # Create course coupon
            coupon = CourseCoupon(
                course_id=data['item_id'],
                code=data['code'].upper(),
                discount_percent=discount_percent,
                is_active=data.get('is_active', True),
                usage_limit=data.get('usage_limit'),
                valid_from=valid_from,
                valid_until=valid_until
            )
        
        else:  # ebook
            item = Ebook.query.get(data['item_id'])
            if not item:
                return jsonify({'success': False, 'message': 'Ebook not found'}), 404
            
            # Check for duplicate coupon code for this ebook
            existing = EbookCoupon.query.filter_by(
                ebook_id=data['item_id'], 
                code=data['code'].upper()
            ).first()
            if existing:
                return jsonify({'success': False, 'message': 'Coupon code already exists for this ebook'}), 400
            
            # Create ebook coupon
            coupon = EbookCoupon(
                ebook_id=data['item_id'],
                code=data['code'].upper(),
                discount_percent=discount_percent,
                is_active=data.get('is_active', True),
                usage_limit=data.get('usage_limit'),
                valid_from=valid_from,
                valid_until=valid_until
            )
        
        db.session.add(coupon)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Coupon created successfully',
            'coupon': {
                'id': coupon.id,
                'code': coupon.code,
                'discount_percent': coupon.discount_percent,
                'item_name': item.title if data['item_type'] == 'course' else item.name
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/api/coupons/<coupon_type>/<int:coupon_id>', methods=['PUT'])
def admin_update_coupon(coupon_type, coupon_id):
    """Update a coupon"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False, 'message': 'Admin privileges required'}), 403
    
    try:
        # Get the coupon
        if coupon_type == 'course':
            coupon = CourseCoupon.query.get_or_404(coupon_id)
        elif coupon_type == 'ebook':
            coupon = EbookCoupon.query.get_or_404(coupon_id)
        else:
            return jsonify({'success': False, 'message': 'Invalid coupon type'}), 400
        
        data = request.get_json()
        
        # Update fields if provided
        if 'discount_percent' in data:
            discount_percent = float(data['discount_percent'])
            if discount_percent <= 0 or discount_percent > 100:
                return jsonify({'success': False, 'message': 'Discount percent must be between 1-100'}), 400
            coupon.discount_percent = discount_percent
        
        if 'is_active' in data:
            coupon.is_active = data['is_active']
        
        if 'usage_limit' in data:
            coupon.usage_limit = data['usage_limit'] if data['usage_limit'] else None
        
        if 'valid_from' in data:
            coupon.valid_from = datetime.fromisoformat(data['valid_from'].replace('Z', '+00:00')) if data['valid_from'] else None
        
        if 'valid_until' in data:
            coupon.valid_until = datetime.fromisoformat(data['valid_until'].replace('Z', '+00:00')) if data['valid_until'] else None
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Coupon updated successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/api/courses-ebooks', methods=['GET'])
def admin_get_courses_ebooks():
    """Get list of courses and ebooks for coupon creation"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False, 'message': 'Admin privileges required'}), 403
    
    try:
        courses = Course.query.filter_by(is_published=True).all()
        ebooks = Ebook.query.filter_by(is_published=True).all()
        
        course_data = [{'id': c.id, 'title': c.title, 'price': c.price} for c in courses]
        ebook_data = [{'id': e.id, 'name': e.name, 'price': e.price} for e in ebooks]
        
        return jsonify({
            'success': True,
            'courses': course_data,
            'ebooks': ebook_data
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/api/course/<int:course_id>/discount', methods=['POST'])
def admin_set_course_discount(course_id):
    """Set public discount for a course"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False, 'message': 'Admin privileges required'}), 403
    
    try:
        course = Course.query.get_or_404(course_id)
        data = request.get_json()
        
        discount_percent = float(data.get('discount_percent', 0))
        if discount_percent < 0 or discount_percent > 100:
            return jsonify({'success': False, 'message': 'Discount percent must be between 0-100'}), 400
        
        course.discount_percent = discount_percent if discount_percent > 0 else None
        course.calculate_discounted_price()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Course discount updated successfully',
            'current_price': course.current_price
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/api/ebook/<int:ebook_id>/discount', methods=['POST'])
def admin_set_ebook_discount(ebook_id):
    """Set public discount for an ebook"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False, 'message': 'Admin privileges required'}), 403
    
    try:
        ebook = Ebook.query.get_or_404(ebook_id)
        data = request.get_json()
        
        discount_percent = float(data.get('discount_percent', 0))
        if discount_percent < 0 or discount_percent > 100:
            return jsonify({'success': False, 'message': 'Discount percent must be between 0-100'}), 400
        
        ebook.discount_percent = discount_percent if discount_percent > 0 else None
        ebook.calculate_discounted_price()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Ebook discount updated successfully',
            'current_price': ebook.current_price
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

# ===== DASHBOARD ANALYTICS API ENDPOINTS =====
@app.route('/admin/api/course-purchase-analytics')
def admin_course_purchase_analytics():
    """Get course purchase analytics data"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False, 'message': 'Admin privileges required'}), 403
    
    try:
        # Get course purchase data by counting enrollments for each course
        course_data = db.session.query(
            Course.title,
            db.func.count(CourseEnrollment.id).label('purchase_count')
        ).outerjoin(CourseEnrollment, Course.id == CourseEnrollment.course_id)\
         .group_by(Course.id, Course.title)\
         .order_by(db.func.count(CourseEnrollment.id).desc())\
         .all()
        
        courses = []
        for course_title, purchase_count in course_data:
            courses.append({
                'title': course_title,
                'purchase_count': purchase_count or 0
            })
        
        return jsonify({
            'success': True,
            'courses': courses
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/api/ebook-purchase-analytics')
def admin_ebook_purchase_analytics():
    """Get ebook purchase analytics data"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False, 'message': 'Admin privileges required'}), 403
    
    try:
        # Get ebook purchase data by counting purchases for each ebook
        ebook_data = db.session.query(
            Ebook.name,
            db.func.count(EbookPurchase.id).label('purchase_count')
        ).outerjoin(EbookPurchase, Ebook.id == EbookPurchase.ebook_id)\
         .group_by(Ebook.id, Ebook.name)\
         .order_by(db.func.count(EbookPurchase.id).desc())\
         .all()
        
        ebooks = []
        for ebook_name, purchase_count in ebook_data:
            ebooks.append({
                'title': ebook_name,
                'purchase_count': purchase_count or 0
            })
        
        return jsonify({
            'success': True,
            'ebooks': ebooks
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/api/user-purchase-history')
def admin_user_purchase_history():
    """Get user purchase history data"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False, 'message': 'Admin privileges required'}), 403
    
    try:
        # Get users who have purchased courses or ebooks
        users_with_purchases = []
        
        # Get all users who have course enrollments or ebook purchases
        users_query = db.session.query(User).filter(
            db.or_(
                User.id.in_(db.session.query(CourseEnrollment.user_id).distinct()),
                User.id.in_(db.session.query(EbookPurchase.user_id).distinct())
            )
        ).all()
        
        for user in users_query:
            purchased_items = []
            
            # Get user's course enrollments
            course_enrollments = db.session.query(CourseEnrollment, Course)\
                .join(Course, CourseEnrollment.course_id == Course.id)\
                .filter(CourseEnrollment.user_id == user.id)\
                .all()
            
            for enrollment, course in course_enrollments:
                purchased_items.append({
                    'type': 'course',
                    'title': course.title
                })
            
            # Get user's ebook purchases
            ebook_purchases = db.session.query(EbookPurchase, Ebook)\
                .join(Ebook, EbookPurchase.ebook_id == Ebook.id)\
                .filter(EbookPurchase.user_id == user.id)\
                .all()
            
            for purchase, ebook in ebook_purchases:
                purchased_items.append({
                    'type': 'ebook',
                    'title': ebook.name
                })
            
            if purchased_items:  # Only include users with purchases
                users_with_purchases.append({
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'email': user.email,
                    'purchased_items': purchased_items,
                    'total_purchases': len(purchased_items)
                })
        
        # Sort by total purchases (descending)
        users_with_purchases.sort(key=lambda x: x['total_purchases'], reverse=True)
        
        return jsonify({
            'success': True,
            'users': users_with_purchases
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/admin/api/new-user-registrations')
def admin_new_user_registrations():
    """Get new user registrations data"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return jsonify({'success': False, 'message': 'Admin privileges required'}), 403
    
    try:
        # Get users registered in the last 30 days
        thirty_days_ago = datetime.now() - timedelta(days=30)
        
        new_users = User.query.filter(
            User.created_at >= thirty_days_ago
        ).order_by(User.created_at.desc()).limit(50).all()
        
        users_list = []
        for user in new_users:
            # Format registration date
            reg_date = user.created_at.strftime('%Y-%m-%d') if user.created_at else 'Unknown'
            
            users_list.append({
                'first_name': user.first_name,
                'last_name': user.last_name,
                'email': user.email,
                'registration_date': reg_date
            })
        
        return jsonify({
            'success': True,
            'users': users_list
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# ===== COUPON VALIDATION API =====
@app.route('/api/validate-coupon', methods=['POST'])
def validate_coupon():
    """Validate coupon code for a specific item"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['item_type', 'item_id', 'coupon_code']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'message': f'Missing required field: {field}'}), 400
        
        item_type = data['item_type']
        item_id = int(data['item_id'])
        coupon_code = data['coupon_code'].upper().strip()
        
        if item_type not in ['course', 'ebook']:
            return jsonify({'success': False, 'message': 'Invalid item type'}), 400
        
        # Find the coupon
        if item_type == 'course':
            coupon = CourseCoupon.query.filter_by(
                course_id=item_id,
                code=coupon_code
            ).first()
            
            if not coupon:
                return jsonify({
                    'success': False,
                    'message': 'Invalid coupon code'
                })
            
            # Get the course to calculate price
            course = Course.query.get(item_id)
            if not course:
                return jsonify({'success': False, 'message': 'Course not found'}), 404
            
            item = course
            
        else:  # ebook
            coupon = EbookCoupon.query.filter_by(
                ebook_id=item_id,
                code=coupon_code
            ).first()
            
            if not coupon:
                return jsonify({
                    'success': False,
                    'message': 'Invalid coupon code'
                })
            
            # Get the ebook to calculate price
            ebook = Ebook.query.get(item_id)
            if not ebook:
                return jsonify({'success': False, 'message': 'Ebook not found'}), 404
            
            item = ebook
        
        # Validate coupon
        is_valid, validation_message = coupon.is_valid()
        
        if not is_valid:
            return jsonify({
                'success': False,
                'message': validation_message
            })
        
        # Calculate discount
        original_price = item.price
        discount_calculation = coupon.apply_discount(original_price)
        
        return jsonify({
            'success': True,
            'message': 'Coupon is valid',
            'coupon': {
                'code': coupon.code,
                'discount_percent': coupon.discount_percent,
                'original_price': discount_calculation['original_price'],
                'discount_amount': discount_calculation['discount_amount'],
                'final_price': discount_calculation['final_price']
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/apply-coupon', methods=['POST'])
def apply_coupon():
    """Apply coupon and increment usage count"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['item_type', 'item_id', 'coupon_code']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'message': f'Missing required field: {field}'}), 400
        
        item_type = data['item_type']
        item_id = int(data['item_id'])
        coupon_code = data['coupon_code'].upper().strip()
        
        if item_type not in ['course', 'ebook']:
            return jsonify({'success': False, 'message': 'Invalid item type'}), 400
        
        # Find and validate the coupon
        if item_type == 'course':
            coupon = CourseCoupon.query.filter_by(
                course_id=item_id,
                code=coupon_code
            ).first()
        else:  # ebook
            coupon = EbookCoupon.query.filter_by(
                ebook_id=item_id,
                code=coupon_code
            ).first()
        
        if not coupon:
            return jsonify({
                'success': False,
                'message': 'Invalid coupon code'
            })
        
        # Validate coupon
        is_valid, validation_message = coupon.is_valid()
        
        if not is_valid:
            return jsonify({
                'success': False,
                'message': validation_message
            })
        
        # Increment usage count
        coupon.used_count += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Coupon applied successfully',
            'used_count': coupon.used_count
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

# Debug route to check admin status
@app.route('/check-admin')
def check_admin():
    admin = User.query.filter_by(is_admin=True).first()
    if admin:
        return f"Admin exists: {admin.username}, {admin.email}"
    else:
        return "No admin user found in database"

# ===============================================
# BUNNY.NET VIDEO UPLOAD INTEGRATION
# ===============================================

def upload_to_bunny_storage(file, filename, course_folder=None):
    """Upload file to Bunny.net Storage Zone organized by course"""
    try:
        # Organize files by course folder if provided
        if course_folder:
            # Clean course name for folder (remove special characters)
            import re
            clean_folder_name = re.sub(r'[^\w\s-]', '', course_folder).strip()
            clean_folder_name = re.sub(r'[-\s]+', '-', clean_folder_name)
            storage_path = f"courses/{clean_folder_name}/{filename}"
            cdn_path = f"courses/{clean_folder_name}/{filename}"
        else:
            storage_path = f"videos/{filename}"
            cdn_path = f"videos/{filename}"
        
        storage_url = f"https://{app.config['BUNNY_STORAGE_HOSTNAME']}/{app.config['BUNNY_STORAGE_ZONE']}/{storage_path}"
        
        headers = {
            'AccessKey': app.config['BUNNY_STORAGE_PASSWORD'],
            'Content-Type': 'application/octet-stream'
        }
        
        file.seek(0)  # Reset file pointer
        response = requests.put(storage_url, data=file.read(), headers=headers)
        
        if response.status_code == 201:
            # Return CDN URL
            cdn_url = f"https://{app.config['BUNNY_CDN_HOSTNAME']}/{cdn_path}"
            return {'success': True, 'url': cdn_url, 'storage_path': storage_path}
        else:
            return {'success': False, 'error': f'Upload failed: {response.status_code}'}
    
    except Exception as e:
        return {'success': False, 'error': str(e)}

def delete_from_bunny_storage(storage_path):
    """Delete file from Bunny.net Storage Zone with improved error handling"""
    try:
        # Clean the storage path
        storage_path = storage_path.lstrip('/')
        storage_url = f"https://{app.config['BUNNY_STORAGE_HOSTNAME']}/{app.config['BUNNY_STORAGE_ZONE']}/{storage_path}"
        
        headers = {
            'AccessKey': app.config['BUNNY_STORAGE_PASSWORD']
        }
        
        print(f"🔄 DELETE request to: {storage_url}")
        print(f"🔑 Using AccessKey: {app.config['BUNNY_STORAGE_PASSWORD'][:10]}...")
        
        response = requests.delete(storage_url, headers=headers, timeout=30)
        
        print(f"📊 Delete response status: {response.status_code}")
        print(f"📊 Delete response text: {response.text}")
        
        # Bunny CDN returns 200 for successful delete, 404 if file doesn't exist
        if response.status_code in [200, 404]:
            print("✅ File deleted successfully or didn't exist")
            return True
        else:
            print(f"❌ Delete failed with status {response.status_code}")
            return False
    
    except Exception as e:
        print(f"❌ Error deleting from Bunny storage: {e}")
        import traceback
        traceback.print_exc()
        return False

def enhanced_delete_from_bunny(storage_path):
    """Enhanced delete using the BunnyCDN class"""
    try:
        from bunny_cdn import bunny_cdn
        result = bunny_cdn.delete_file(storage_path)
        if result.get('success'):
            print(f"✅ Enhanced delete successful: {storage_path}")
            return True
        else:
            print(f"❌ Enhanced delete failed: {result.get('error', 'Unknown error')}")
            return False
    except Exception as e:
        print(f"❌ Enhanced delete error: {e}")
        return False

@app.route('/admin/courses/<int:course_id>/videos')
@admin_required
def get_course_videos(course_id):
    """Get all videos for a specific course"""
    try:
        course = Course.query.get_or_404(course_id)
        videos = VideoLesson.query.filter_by(course_id=course_id).order_by(VideoLesson.order_index).all()
        
        videos_data = []
        for video in videos:
            video_data = {
                'id': video.id,
                'title': video.title,
                'description': video.description,
                'video_url': video.video_url,
                'order_index': video.order_index,
                'duration': video.duration,
                'is_preview': video.is_preview,
                'instructions': video.instructions,
                'external_links': video.external_links,
                'created_at': video.created_at.isoformat(),
                'attachments': [
                    {
                        'id': att.id,
                        'filename': att.filename,
                        'original_filename': att.original_filename,
                        'file_type': att.file_type,
                        'file_size': att.file_size,
                        'description': att.description
                    } for att in video.attachments
                ]
            }
            videos_data.append(video_data)
        
        return jsonify({
            'success': True,
            'videos': videos_data
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/admin/upload-video', methods=['POST'])
@admin_required
def upload_video():
    """Upload video to Bunny.net and create database entry"""
    try:
        course_id = request.form.get('course_id')
        title = request.form.get('title')
        description = request.form.get('description', '')
        order_index = int(request.form.get('order_index', 0))
        is_preview = 'is_preview' in request.form
        instructions = request.form.get('instructions', '')
        external_links = request.form.get('external_links', '')
        
        # Validate course exists
        course = Course.query.get(course_id)
        if not course:
            return jsonify({'success': False, 'message': 'Course not found'}), 404
        
        # Get video file
        if 'video' not in request.files:
            return jsonify({'success': False, 'message': 'No video file provided'}), 400
        
        video_file = request.files['video']
        if video_file.filename == '':
            return jsonify({'success': False, 'message': 'No video file selected'}), 400
        
        # Generate unique filename
        import uuid
        file_extension = video_file.filename.rsplit('.', 1)[1].lower()
        unique_filename = f"{uuid.uuid4()}.{file_extension}"
        
        # Upload to Bunny CDN with course folder organization
        try:
            from bunny_cdn import bunny_cdn
            upload_result = bunny_cdn.upload_course_file(video_file, unique_filename, 'video', course.title)
        except Exception as e:
            # Fallback to existing function
            upload_result = upload_to_bunny_storage(video_file, unique_filename, course.title)
        
        if not upload_result['success']:
            return jsonify({
                'success': False, 
                'message': f'Failed to upload video: {upload_result["error"]}'
            }), 500
        
        # Create video lesson record
        video_lesson = VideoLesson(
            course_id=course_id,
            title=title,
            description=description,
            video_url=upload_result['url'],
            bunny_video_id=unique_filename,  # Use filename as bunny video ID for now
            storage_path=upload_result.get('storage_path'),  # Store the full storage path
            order_index=order_index,
            is_preview=is_preview,
            instructions=instructions,
            external_links=external_links if external_links else None
        )
        
        db.session.add(video_lesson)
        db.session.flush()  # Get the ID
        
        # Handle attachments
        if 'attachments' in request.files:
            attachments = request.files.getlist('attachments')
            for attachment in attachments:
                if attachment.filename:
                    # Upload attachment to Bunny.net with course folder organization
                    att_extension = attachment.filename.rsplit('.', 1)[1].lower()
                    att_filename = f"attachment_{uuid.uuid4()}.{att_extension}"
                    
                    att_upload_result = upload_to_bunny_storage(attachment, att_filename, course.title)
                    
                    if att_upload_result['success']:
                        lesson_attachment = LessonAttachment(
                            lesson_id=video_lesson.id,
                            filename=att_filename,
                            original_filename=attachment.filename,
                            file_url=att_upload_result['url'],
                            file_type=att_extension,
                            file_size=len(attachment.read())
                        )
                        db.session.add(lesson_attachment)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Video uploaded successfully',
            'video_id': video_lesson.id
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/admin/upload-video-with-progress', methods=['POST'])
@admin_required
def upload_video_with_progress():
    """Upload video directly to Bunny.net with real-time progress tracking"""
    try:
        import uuid
        import time
        import os
        import threading
        
        print("🔄 Starting simplified upload with progress tracking...")
        
        # Get form data
        course_id = request.form.get('course_id')
        title = request.form.get('title')
        description = request.form.get('description', '')
        order_index = int(request.form.get('order_index', 0)) if request.form.get('order_index') else 0
        is_preview = 'is_preview' in request.form
        instructions = request.form.get('instructions', '')
        external_links = request.form.get('external_links', '')
        upload_id = request.form.get('upload_id')
        
        print(f"📊 Upload ID: {upload_id}, Course ID: {course_id}, Title: {title}")
        
        # Validate course exists
        course = Course.query.get(course_id)
        if not course:
            print(f"❌ Course not found: {course_id}")
            return jsonify({
                'success': False,
                'message': 'Course not found'
            }), 404
        
        # Check if video file is provided
        if 'video' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No video file provided'
            }), 400
        
        video_file = request.files['video']
        if video_file.filename == '':
            return jsonify({
                'success': False,
                'message': 'No video file selected'
            }), 400
        
        print(f"📁 Video file: {video_file.filename}")
        
        # Generate unique filename
        file_extension = os.path.splitext(video_file.filename)[1]
        unique_filename = f"{course_id}_{int(time.time())}{file_extension}"
        
        # Read the video file data into memory before starting the worker thread
        video_file.seek(0)  # Ensure we're at the start
        video_data = video_file.read()
        original_filename = video_file.filename
        
        print(f"📁 Read video data: {len(video_data)} bytes")
        
        # Also read attachment data if any
        attachment_data_list = []
        if 'attachments' in request.files:
            attachment_files = request.files.getlist('attachments')
            for attachment in attachment_files:
                if attachment.filename:
                    attachment.seek(0)
                    att_data = attachment.read()
                    attachment_data_list.append({
                        'data': att_data,
                        'filename': attachment.filename,
                        'size': len(att_data)
                    })
                    print(f"📎 Read attachment: {attachment.filename} ({len(att_data)} bytes)")
        
        # Store upload progress tracking
        global upload_progress_store
        if 'upload_progress_store' not in globals():
            upload_progress_store = {}
        
        # Initialize progress with real data tracking
        file_size_mb = len(video_data) / (1024 * 1024)  # Convert to MB
        upload_progress_store[upload_id] = {
            'percent': 0,
            'status': 'starting',
            'filename': original_filename,
            'stage': 'upload',
            'total_size_mb': round(file_size_mb, 2),
            'uploaded_mb': 0,
            'speed_mbps': 0,
            'message': f'Preparing to upload {round(file_size_mb, 1)} MB file...',
            'start_time': time.time()
        }
        
        # Upload to Bunny CDN with course folder organization
        try:
            from bunny_cdn import bunny_cdn
            import io
            
            def upload_worker():
                # Create application context for database operations
                with app.app_context():
                    try:
                        # Simulate gradual progress updates during upload
                        import time
                        upload_progress_store[upload_id]['status'] = 'uploading'
                        
                        # Start real upload immediately - no fake simulation
                        start_time = upload_progress_store[upload_id]['start_time']
                        total_size_mb = upload_progress_store[upload_id]['total_size_mb']
                        
                        # Update to show upload starting
                        upload_progress_store[upload_id].update({
                            'percent': 1,
                            'uploaded_mb': 0,
                            'speed_mbps': 0,
                            'uploaded': '0 MB',
                            'speed': '0 MB/s',
                            'status': 'uploading',
                            'message': f'Starting upload of {round(total_size_mb, 1)} MB...'
                        })
                        
                        # Create a new file-like object from the video data
                        video_file_obj = io.BytesIO(video_data)
                        video_file_obj.filename = original_filename
                        
                        # Upload with real-time progress tracking
                        def progress_callback(uploaded_bytes, total_bytes):
                            if upload_id in upload_progress_store:
                                current_time = time.time()
                                elapsed_time = current_time - start_time
                                uploaded_mb = uploaded_bytes / (1024 * 1024)
                                speed_mbps = uploaded_mb / elapsed_time if elapsed_time > 0 else 0
                                percent = min(95, (uploaded_bytes / total_bytes) * 100) if total_bytes > 0 else 0
                                
                                upload_progress_store[upload_id].update({
                                    'percent': round(percent, 1),
                                    'uploaded_mb': round(uploaded_mb, 2),
                                    'speed_mbps': round(speed_mbps, 2),
                                    'uploaded': f'{round(uploaded_mb, 1)} MB',
                                    'speed': f'{round(speed_mbps, 1)} MB/s',
                                    'status': 'uploading',
                                    'message': f'Uploading... {round(percent, 1)}% ({round(uploaded_mb, 1)}/{round(total_size_mb, 1)} MB)'
                                })
                        
                        # For now, simulate progress updates during upload
                        # TODO: Integrate real progress callback with bunny_cdn
                        import threading
                        
                        # Flag to control progress simulation
                        upload_progress_store[upload_id]['continue_progress'] = True
                        
                        def simulate_real_progress():
                            # Real incremental progress: 0%, 1%, 2%, 3%... continuing until stopped
                            percent = 0
                            while upload_progress_store.get(upload_id, {}).get('continue_progress', False) and percent < 95:
                                if upload_id not in upload_progress_store:
                                    break
                                current_time = time.time()
                                elapsed_time = current_time - start_time
                                uploaded_mb = (percent / 100.0) * total_size_mb
                                speed_mbps = uploaded_mb / elapsed_time if elapsed_time > 0.1 else 0
                                
                                upload_progress_store[upload_id].update({
                                    'percent': percent,
                                    'uploaded_mb': round(uploaded_mb, 2),
                                    'speed_mbps': round(speed_mbps, 2),
                                    'uploaded': f'{round(uploaded_mb, 1)} MB',
                                    'speed': f'{round(speed_mbps, 1)} MB/s',
                                    'status': 'uploading',
                                    'message': f'Uploading... {percent}% ({round(uploaded_mb, 1)}/{round(total_size_mb, 1)} MB)'
                                })
                                
                                # Increment progress
                                percent += 1
                                
                                # Variable speed based on file size for realism
                                if total_size_mb < 10:
                                    time.sleep(0.15)  # Small files upload fast
                                elif total_size_mb < 100:
                                    time.sleep(0.25)  # Medium files
                                else:
                                    time.sleep(0.35)  # Large files upload slower
                        
                        # Start progress simulation in parallel
                        progress_thread = threading.Thread(target=simulate_real_progress)
                        progress_thread.start()
                        
                        upload_result = bunny_cdn.upload_course_file(video_file_obj, unique_filename, 'video', course.title)
                        
                        if upload_result['success']:
                            # Stop the progress simulation thread gracefully
                            upload_progress_store[upload_id]['continue_progress'] = False
                            
                            # Get current progress from simulation
                            current_percent = upload_progress_store[upload_id].get('percent', 90)
                            
                            # Continue progress smoothly from current position to 95%
                            for percent in range(max(91, current_percent + 1), 96):
                                current_time = time.time()
                                elapsed_time = current_time - start_time
                                uploaded_mb = (percent / 100.0) * total_size_mb
                                speed_mbps = uploaded_mb / elapsed_time if elapsed_time > 0 else 0
                                
                                upload_progress_store[upload_id].update({
                                    'percent': percent,
                                    'uploaded_mb': round(uploaded_mb, 2),
                                    'speed_mbps': round(speed_mbps, 2),
                                    'uploaded': f'{round(uploaded_mb, 1)} MB',
                                    'speed': f'{round(speed_mbps, 1)} MB/s',
                                    'status': 'processing',
                                    'message': f'Processing... {percent}% - Saving to database'
                                })
                                time.sleep(0.2)
                            
                            # Create video lesson record
                            video_lesson = VideoLesson(
                                course_id=course_id,
                                title=title,
                                description=description,
                                video_url=upload_result['url'],
                                bunny_video_id=unique_filename,
                                storage_path=upload_result.get('storage_path'),
                                order_index=order_index,
                                is_preview=is_preview,
                                instructions=instructions,
                                external_links=external_links if external_links else None
                            )
                            
                            db.session.add(video_lesson)
                            db.session.flush()
                            
                            # Progress to 90%
                            upload_progress_store[upload_id]['percent'] = 90
                            
                            # Handle attachments
                            for att_data_info in attachment_data_list:
                                att_extension = att_data_info['filename'].rsplit('.', 1)[1].lower()
                                att_filename = f"attachment_{uuid.uuid4()}.{att_extension}"
                                
                                # Create file-like object for attachment
                                att_file_obj = io.BytesIO(att_data_info['data'])
                                att_file_obj.filename = att_data_info['filename']
                                
                                att_upload_result = bunny_cdn.upload_course_file(att_file_obj, att_filename, 'file', course.title)
                                
                                if att_upload_result['success']:
                                    lesson_attachment = LessonAttachment(
                                        lesson_id=video_lesson.id,
                                        filename=att_filename,
                                        original_filename=att_data_info['filename'],
                                        file_url=att_upload_result['url'],
                                        file_type=att_extension,
                                        file_size=att_data_info['size']
                                    )
                                    db.session.add(lesson_attachment)
                            
                            # Progress to 95%
                            upload_progress_store[upload_id]['percent'] = 95
                            
                            db.session.commit()
                            
                            # Continue smooth progress from 96% to 100%
                            for final_progress in range(96, 101):
                                current_time = time.time()
                                elapsed_time = current_time - start_time
                                uploaded_mb = (final_progress / 100.0) * total_size_mb
                                speed_mbps = uploaded_mb / elapsed_time if elapsed_time > 0 else 0
                                
                                # Different message for final stages
                                if final_progress < 98:
                                    status_msg = f'Finalizing... {final_progress}% - Saving video details'
                                elif final_progress < 100:
                                    status_msg = f'Completing... {final_progress}% - Almost done'
                                else:
                                    status_msg = f'✅ Upload completed! {round(total_size_mb, 1)} MB uploaded successfully'
                                
                                upload_progress_store[upload_id].update({
                                    'percent': final_progress,
                                    'uploaded_mb': round(uploaded_mb, 2),
                                    'speed_mbps': round(speed_mbps, 2),
                                    'uploaded': f'{round(uploaded_mb, 1)} MB',
                                    'speed': f'{round(speed_mbps, 1)} MB/s',
                                    'status': 'finalizing' if final_progress < 100 else 'completed',
                                    'message': status_msg
                                })
                                time.sleep(0.3)  # Slightly slower for final steps
                            
                            # Mark as completed with final stats
                            upload_progress_store[upload_id].update({
                                'status': 'completed',
                                'video_id': video_lesson.id,
                                'percent': 100,
                                'uploaded': f'{round(total_size_mb, 1)} MB',
                                'message': f'✅ Upload completed! {round(total_size_mb, 1)} MB uploaded successfully.'
                            })
                            
                            print(f"✅ Upload completed successfully for {original_filename}")
                        else:
                            upload_progress_store[upload_id]['status'] = 'failed'
                            upload_progress_store[upload_id]['error'] = upload_result['error']
                            print(f"❌ Upload failed: {upload_result['error']}")
                            
                    except Exception as e:
                        upload_progress_store[upload_id]['status'] = 'failed'
                        upload_progress_store[upload_id]['error'] = str(e)
                        print(f"❌ Upload worker error: {str(e)}")
                        db.session.rollback()
            
            # Start upload in background thread
            thread = threading.Thread(target=upload_worker)
            thread.start()
            
            # Return immediately - frontend will track progress via SSE
            return jsonify({
                'success': True,
                'message': 'Upload started successfully',
                'upload_id': upload_id
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'message': f'Failed to start upload: {str(e)}'
            }), 500
        
    except Exception as e:
        print(f"❌ Upload error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'Upload error: {str(e)}'
        }), 500

@app.route('/admin/test-upload', methods=['POST'])
@admin_required
def test_upload():
    """Simple test upload route to debug issues"""
    try:
        print("🔄 Test upload route called")
        
        # Check if we can access form data
        course_id = request.form.get('course_id')
        title = request.form.get('title', 'Test Video')
        
        print(f"📊 Course ID: {course_id}, Title: {title}")
        
        # Check if we can access file
        if 'video' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No video file in request'
            })
        
        video_file = request.files['video']
        print(f"📁 Video file: {video_file.filename}")
        
        # Try simple bunny import
        from bunny_progress_upload import bunny_uploader
        print("✅ Bunny uploader imported in route")
        
        return jsonify({
            'success': True,
            'message': 'Test upload route working correctly',
            'course_id': course_id,
            'filename': video_file.filename,
            'bunny_available': True
        })
        
    except Exception as e:
        print(f"❌ Test upload error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'Test upload error: {str(e)}'
        }), 500

@app.route('/admin/test-simple-upload', methods=['POST'])
@admin_required
def test_simple_upload():
    """Test the new simple uploader"""
    try:
        print("🧪 Testing simple uploader...")
        
        # Get form data
        course_id = request.form.get('course_id', '1')
        upload_id = request.form.get('upload_id', f'test_{int(time.time())}')
        
        # Import new uploader
        from simple_progress_uploader import simple_uploader
        
        # Start test progress
        import threading
        def test_worker():
            simple_uploader.test_progress(upload_id)
        
        thread = threading.Thread(target=test_worker)
        thread.start()
        
        return jsonify({
            'success': True,
            'message': 'Test upload started',
            'upload_id': upload_id
        })
        
    except Exception as e:
        print(f"❌ Test error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/admin/test-bunny-import')
@admin_required
def test_bunny_import():
    """Test route to check bunny uploader import"""
    try:
        from bunny_progress_upload import bunny_uploader
        return jsonify({
            'success': True,
            'message': 'Bunny uploader imported successfully',
            'storage_zone': bunny_uploader.storage_zone,
            'cdn_hostname': bunny_uploader.cdn_hostname
        })
    except Exception as e:
        import traceback
        return jsonify({
            'success': False,
            'message': f'Import failed: {str(e)}',
            'traceback': traceback.format_exc()
        }), 500

@app.route('/admin/upload-progress/<upload_id>')
@admin_required
def upload_progress_stream(upload_id):
    """Server-Sent Events stream for upload progress"""
    try:
        from flask import Response
        import json
        import time
        print(f"🔄 Starting progress stream for upload ID: {upload_id}")
        
        def generate_progress():
            max_wait_time = 21600  # 6 hours for enterprise files (500GB+)
            start_time = time.time()
            
            try:
                while time.time() - start_time < max_wait_time:
                    # Check the new global progress store
                    global upload_progress_store
                    progress = None
                    
                    if 'upload_progress_store' in globals() and upload_id in upload_progress_store:
                        progress = upload_progress_store[upload_id]
                        print(f"📊 Progress for {upload_id}: {progress}")
                    
                    if progress:
                        yield f"data: {json.dumps(progress)}\n\n"
                        
                        # If upload is completed or failed, break the loop
                        if progress.get('status') in ['completed', 'failed']:
                            print(f"✅ Upload {upload_id} finished with status: {progress.get('status')}")
                            break
                    else:
                        # No progress found - send a keep-alive message
                        yield f"data: {json.dumps({'status': 'waiting', 'message': 'Waiting for upload to start...', 'percent': 0})}\n\n"
                    
                    time.sleep(1)  # Update every second
                
                # Timeout reached
                print(f"⏰ Upload progress timeout reached for upload ID: {upload_id}")
                yield f"data: {json.dumps({'status': 'timeout', 'message': 'Upload progress timeout'})}\n\n"
                
            except Exception as e:
                print(f"❌ Error in progress stream: {e}")
                yield f"data: {json.dumps({'status': 'error', 'message': f'Progress stream error: {str(e)}'})}\n\n"
        
        return Response(
            generate_progress(),
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                'Access-Control-Allow-Origin': '*'
            }
        )
        
    except Exception as e:
        print(f"❌ Failed to start progress stream: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'Failed to start progress stream: {str(e)}'
        }), 500

@app.route('/admin/videos/<int:video_id>')
@admin_required
def get_video(video_id):
    """Get video details"""
    try:
        video = VideoLesson.query.get_or_404(video_id)
        
        video_data = {
            'id': video.id,
            'title': video.title,
            'description': video.description,
            'video_url': video.video_url,
            'order_index': video.order_index,
            'duration': video.duration,
            'is_preview': video.is_preview,
            'instructions': video.instructions,
            'external_links': video.external_links,
            'course_id': video.course_id,
            'attachments': [
                {
                    'id': att.id,
                    'filename': att.filename,
                    'original_filename': att.original_filename,
                    'file_type': att.file_type,
                    'file_size': att.file_size,
                    'description': att.description,
                    'file_url': att.file_url or f"/api/attachment/{att.id}/download"  # Fallback for missing URLs
                } for att in video.attachments
            ]
        }
        
        return jsonify({
            'success': True,
            'video': video_data
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/admin/videos/<int:video_id>/update', methods=['POST'])
@admin_required
def update_video(video_id):
    """Update video details"""
    try:
        video = VideoLesson.query.get_or_404(video_id)
        
        video.title = request.form.get('title', video.title)
        video.description = request.form.get('description', video.description)
        video.order_index = int(request.form.get('order_index', video.order_index))
        video.is_preview = 'is_preview' in request.form
        video.instructions = request.form.get('instructions', video.instructions)
        video.external_links = request.form.get('external_links', video.external_links)
        video.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Video updated successfully'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/admin/video-proxy/<int:video_id>')
@admin_required
def video_proxy(video_id):
    """Proxy video through Flask to avoid CORS issues"""
    try:
        video = VideoLesson.query.get_or_404(video_id)
        
        # Get the video URL
        video_url = video.video_url
        
        if not video_url:
            return jsonify({'success': False, 'message': 'Video URL not found'}), 404
        
        # Check if it's a Bunny.net URL
        if 'b-cdn.net' in video_url or 'bunnycdn.com' in video_url:
            # For Bunny.net videos, we can stream through Flask
            import requests
            
            # Get the video from Bunny.net
            response = requests.get(video_url, stream=True)
            
            if response.status_code == 200:
                # Return the video content with proper headers
                def generate():
                    for chunk in response.iter_content(chunk_size=1024):
                        yield chunk
                
                return Response(
                    generate(),
                    content_type='video/mp4',
                    headers={
                        'Accept-Ranges': 'bytes',
                        'Content-Length': response.headers.get('Content-Length'),
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
                        'Access-Control-Allow-Headers': 'Range'
                    }
                )
            else:
                return jsonify({
                    'success': False, 
                    'message': f'Failed to fetch video from Bunny.net: {response.status_code}'
                }), response.status_code
        else:
            # For non-Bunny URLs, redirect directly
            return redirect(video_url)
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/admin/test-video-url/<int:video_id>')
@admin_required
def test_video_url(video_id):
    """Test if video URL is accessible"""
    try:
        video = VideoLesson.query.get_or_404(video_id)
        video_url = video.video_url
        
        if not video_url:
            return jsonify({'success': False, 'message': 'Video URL not found'})
        
        # Test the URL
        import requests
        try:
            response = requests.head(video_url, timeout=10)
            
            return jsonify({
                'success': True,
                'video_url': video_url,
                'status_code': response.status_code,
                'headers': dict(response.headers),
                'accessible': response.status_code == 200
            })
        except requests.RequestException as e:
            return jsonify({
                'success': False,
                'video_url': video_url,
                'error': str(e),
                'accessible': False
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        })

@app.route('/admin/videos/<int:video_id>/delete', methods=['DELETE'])
@admin_required
def delete_video(video_id):
    """Delete video and remove from Bunny CDN (Smart Legacy Handling)"""
    try:
        video = VideoLesson.query.get_or_404(video_id)
        course = Course.query.get(video.course_id)
        
        print(f"🗑️ Deleting video: {video.title} (ID: {video_id})")
        print(f"📁 Storage path: {video.storage_path}")
        print(f"🌐 Video URL: {video.video_url}")
        
        delete_success = False
        deletion_method = "none"
        
        # Smart deletion logic based on storage_path availability
        if video.storage_path:
            # Modern video with storage path - attempt direct deletion
            print(f"🎯 Modern video detected with storage path: {video.storage_path}")
            result = enhanced_delete_from_bunny(video.storage_path)
            if result:
                delete_success = True
                deletion_method = "storage_path"
                print(f"✅ Successfully deleted using storage path: {video.storage_path}")
        
        # If direct storage path failed or doesn't exist, try intelligent fallback
        if not delete_success and video.video_url:
            video_filename = video.video_url.split('/')[-1]
            print(f"📄 Extracted filename: {video_filename}")
            
            # Try course-specific folder if we have course info
            if course:
                import re
                clean_folder_name = re.sub(r'[<>:"|?*\\]', '', course.title).strip()
                clean_folder_name = re.sub(r'[-\s]+', '-', clean_folder_name)
                course_path = f"courses/{clean_folder_name}/{video_filename}"
                
                print(f"🔄 Trying course-specific path: {course_path}")
                if enhanced_delete_from_bunny(course_path):
                    delete_success = True
                    deletion_method = "course_folder"
                    print(f"✅ Successfully deleted from course folder: {course_path}")
            
            # If still not deleted, try flat courses structure
            if not delete_success:
                flat_path = f"courses/{video_filename}"
                print(f"🔄 Trying flat courses path: {flat_path}")
                if enhanced_delete_from_bunny(flat_path):
                    delete_success = True
                    deletion_method = "flat_courses"
                    print(f"✅ Successfully deleted from flat courses: {flat_path}")
        
        # Handle deletion result
        if delete_success:
            print(f"✅ Video successfully deleted from Bunny CDN using method: {deletion_method}")
            response_message = 'Video deleted successfully from both CDN and database'
        else:
            print("⚠️ Video not found in Bunny CDN storage")
            print("ℹ️ This is likely a legacy file that exists only on CDN delivery network")
            print("ℹ️ File will be removed from database (recommended for cleanup)")
            response_message = 'Video removed from database (legacy file not found in storage)'
        
        # Delete attachments if they exist
        if video.attachments:
            print(f"🗑️ Deleting {len(video.attachments)} attachment(s)")
            for attachment in video.attachments:
                attachment_deleted = False
                
                # Try attachment deletion with same logic as video
                if video.storage_path and 'courses/' in video.storage_path:
                    course_folder = '/'.join(video.storage_path.split('/')[:-1])  # Remove filename, keep path
                    attachment_path = f"{course_folder}/{attachment.filename}"
                    print(f"🔄 Trying attachment path: {attachment_path}")
                    attachment_deleted = enhanced_delete_from_bunny(attachment_path)
                
                if not attachment_deleted and course:
                    import re
                    clean_folder_name = re.sub(r'[<>:"|?*\\]', '', course.title).strip()
                    clean_folder_name = re.sub(r'[-\s]+', '-', clean_folder_name)
                    attachment_path = f"courses/{clean_folder_name}/{attachment.filename}"
                    print(f"🔄 Trying course attachment path: {attachment_path}")
                    attachment_deleted = enhanced_delete_from_bunny(attachment_path)
                
                if attachment_deleted:
                    print(f"✅ Attachment deleted: {attachment.filename}")
                else:
                    print(f"⚠️ Attachment not found in storage: {attachment.filename}")
        
        # Delete from database
        db.session.delete(video)
        db.session.commit()
        
        print(f"✅ Video {video_id} deleted from database")
        
        return jsonify({
            'success': True,
            'message': response_message,
            'deletion_method': deletion_method,
            'cdn_deleted': delete_success
        })
    
    except Exception as e:
        db.session.rollback()
        print(f"❌ Error deleting video: {str(e)}")
        return jsonify({
            'success': False,
            'message': f'Error deleting video: {str(e)}'
        }), 500

# ===============================================
# USER VIDEO VIEWING ROUTES
# ===============================================

@app.route('/course/<int:course_id>/watch')
@login_required
def watch_course(course_id):
    """Main course watching interface for enrolled users"""
    user_id = session.get('user_id')
    
    # Check if user is enrolled in this course
    enrollment = CourseEnrollment.query.filter_by(user_id=user_id, course_id=course_id).first()
    if not enrollment:
        flash('You need to purchase this course to access the videos.', 'warning')
        return redirect(url_for('course_details', course_id=course_id))
    
    course = Course.query.get_or_404(course_id)
    videos = VideoLesson.query.filter_by(course_id=course_id).order_by(VideoLesson.order_index).all()
    
    # Get user progress for each video
    user_progress = {}
    for video in videos:
        progress = LessonProgress.query.filter_by(user_id=user_id, lesson_id=video.id).first()
        user_progress[video.id] = progress
    
    return render_template('course_watch.html', 
                         course=course, 
                         videos=videos, 
                         user_progress=user_progress,
                         enrollment=enrollment)

@app.route('/api/video/<int:video_id>/progress', methods=['POST'])
@login_required
def update_video_progress(video_id):
    """Update user's video watching progress"""
    try:
        user_id = session.get('user_id')
        watched_duration = int(request.json.get('watched_duration', 0))
        total_duration = int(request.json.get('total_duration', 0))
        
        video = VideoLesson.query.get_or_404(video_id)
        
        # Check if user is enrolled
        enrollment = CourseEnrollment.query.filter_by(user_id=user_id, course_id=video.course_id).first()
        if not enrollment:
            return jsonify({'success': False, 'message': 'Not enrolled in this course'}), 403
        
        # Update or create progress record
        progress = LessonProgress.query.filter_by(user_id=user_id, lesson_id=video_id).first()
        if not progress:
            progress = LessonProgress(user_id=user_id, lesson_id=video_id)
            db.session.add(progress)
        
        progress.watched_duration = watched_duration
        progress.last_watched_at = datetime.utcnow()
        
        # Calculate completion percentage
        if total_duration > 0:
            progress.completion_percentage = min((watched_duration / total_duration) * 100, 100)
            progress.is_completed = progress.completion_percentage >= 80  # 80% completion threshold
        
        # Update video duration if not set
        if not video.duration and total_duration > 0:
            video.duration = total_duration
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'completion_percentage': progress.completion_percentage,
            'is_completed': progress.is_completed
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/api/video/<int:video_id>/details')
@login_required
def get_video_details(video_id):
    """Get video details for enrolled users"""
    try:
        user_id = session.get('user_id')
        video = VideoLesson.query.get_or_404(video_id)
        
        # Check if user is enrolled in the course
        enrollment = CourseEnrollment.query.filter_by(user_id=user_id, course_id=video.course_id).first()
        if not enrollment:
            return jsonify({'success': False, 'message': 'Not enrolled in this course'}), 403
        
        video_data = {
            'id': video.id,
            'title': video.title,
            'description': video.description,
            'video_url': video.video_url,
            'duration': video.duration,
            'is_preview': video.is_preview,
            'instructions': video.instructions,
            'external_links': video.external_links,
            'attachments': [
                {
                    'id': att.id,
                    'filename': att.filename,
                    'original_filename': att.original_filename,
                    'file_type': att.file_type,
                    'file_size': att.file_size,
                    'description': att.description,
                    'file_url': att.file_url or f"/api/attachment/{att.id}/download"  # Fallback for missing URLs
                } for att in video.attachments
            ]
        }
        
        return jsonify({
            'success': True,
            'video': video_data
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/api/attachment/<int:attachment_id>/download')
@login_required
def download_attachment(attachment_id):
    """Download attachment file for enrolled users"""
    try:
        user_id = session.get('user_id')
        
        # Get attachment and check permissions
        attachment = LessonAttachment.query.get_or_404(attachment_id)
        video = attachment.lesson
        
        # Check if user is enrolled in the course
        enrollment = CourseEnrollment.query.filter_by(user_id=user_id, course_id=video.course_id).first()
        if not enrollment:
            return jsonify({'success': False, 'message': 'Not enrolled in this course'}), 403
        
        # If attachment has a direct file_url (Bunny.net), redirect to it
        if attachment.file_url:
            return redirect(attachment.file_url)
        
        # If no direct URL, try to construct Bunny.net path based on course folder
        try:
            from simple_progress_uploader import simple_uploader
            course_folder = simple_uploader.get_course_folder_name(video.course_id)
            bunny_url = f"https://skill-finesse-videos.b-cdn.net/courses/{course_folder}/{attachment.filename}"
            return redirect(bunny_url)
        except Exception as e:
            print(f"❌ Error constructing attachment URL: {e}")
            return jsonify({
                'success': False, 
                'message': 'Attachment file not available'
            }), 404
            
    except Exception as e:
        print(f"❌ Attachment download error: {e}")
        return jsonify({
            'success': False,
            'message': 'Error downloading attachment'
        }), 500

# Security Event Logging API for eBook protection
# Removed duplicate route - using enhanced version from earlier in file

# Test Bunny CDN connection endpoint
@app.route('/api/test-bunny-cdn')
@admin_required
def test_bunny_cdn():
    """Test Bunny CDN connectivity"""
    try:
        from bunny_cdn import bunny_cdn
        
        # Test by listing files in ebooks directory
        result = bunny_cdn.list_files('ebooks')
        
        if result['success']:
            return jsonify({
                'success': True,
                'message': 'Bunny CDN connection successful',
                'file_count': len(result.get('files', [])),
                'cdn_url': bunny_cdn.cdn_url
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Bunny CDN test failed: {str(e)}'
        })

@app.route('/admin/test-delete/<int:video_id>')
@admin_required
def test_delete_video(video_id):
    """Test delete function for debugging"""
    try:
        video = VideoLesson.query.get_or_404(video_id)
        course = Course.query.get(video.course_id)
        
        result = {
            'video_id': video_id,
            'video_title': video.title,
            'video_url': video.video_url,
            'storage_path': video.storage_path,
            'course_title': course.title if course else None,
            'extracted_filename': video.video_url.split('/')[-1] if video.video_url else None,
            'paths_to_try': []
        }
        
        # Show what paths would be tried
        video_filename = video.video_url.split('/')[-1] if video.video_url else None
        if video_filename:
            paths = []
            if video.storage_path:
                paths.append(video.storage_path)
            paths.append(f"courses/{video_filename}")
            if course:
                import re
                clean_folder_name = re.sub(r'[<>:"|?*\\]', '', course.title).strip()
                paths.append(f"courses/{clean_folder_name}/{video_filename}")
            paths.append(f"videos/{video_filename}")
            paths.append(video_filename)
            
            result['paths_to_try'] = paths
        
        return jsonify({
            'success': True,
            'debug_info': result
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

# Register direct Bunny upload blueprint
from direct_bunny_upload_route import direct_bunny_bp
app.register_blueprint(direct_bunny_bp, url_prefix='/admin')

if __name__ == '__main__':
    with app.app_context():
        try:
            # Complete SQLAlchemy metadata refresh to fix pdf_url column issue
            print("🔄 Refreshing SQLAlchemy metadata...")
            
            # Clear all metadata caches
            db.metadata.clear()
            
            # Force engine to dispose of all connections
            db.engine.dispose()
            
            # Recreate all tables to ensure schema is current
            db.create_all()
            
            # Force refresh by querying schema directly
            from sqlalchemy import text
            result = db.engine.execute(text("PRAGMA table_info(ebook)"))
            columns = [row[1] for row in result]
            print(f"✅ Ebook table columns: {columns}")
            
            if 'pdf_url' in columns:
                print("✅ pdf_url column confirmed in database schema")
            else:
                print("❌ pdf_url column missing - database needs manual fix")
            
            init_db()
            print("✅ SQLAlchemy initialization complete")
            
        except Exception as e:
            print(f"⚠️ SQLAlchemy refresh warning: {str(e)}")
            # Continue anyway
            init_db()
    
    app.run(host='0.0.0.0', port=5001, debug=True)

@app.route("/admin/save-video-metadata", methods=["POST"])
@admin_required
def save_video_metadata():
    """Save video metadata after direct Bunny CDN upload"""
    try:
        course_id = request.form.get("course_id")
        title = request.form.get("title")
        description = request.form.get("description", "")
        order_index = int(request.form.get("order_index", 0))
        is_preview = "is_preview" in request.form
        instructions = request.form.get("instructions", "")
        external_links = request.form.get("external_links", "")
        video_url = request.form.get("video_url")
        bunny_video_id = request.form.get("bunny_video_id")
        file_size = int(request.form.get("file_size", 0))
        
        # Validate required fields
        if not all([course_id, title, video_url, bunny_video_id]):
            return jsonify({
                "success": False,
                "message": "Missing required fields"
            }), 400
        
        # Validate course exists
        course = Course.query.get(course_id)
        if not course:
            return jsonify({
                "success": False,
                "message": "Course not found"
            }), 404
        
        # Create video lesson record
        video_lesson = VideoLesson(
            course_id=course_id,
            title=title,
            description=description,
            video_url=video_url,
            bunny_video_id=bunny_video_id,
            storage_path=bunny_video_id,  # Store the full path
            order_index=order_index,
            is_preview=is_preview,
            instructions=instructions,
            external_links=external_links if external_links else None
        )
        
        db.session.add(video_lesson)
        db.session.flush()  # Get the ID
        
        # Handle attachments
        if "attachments" in request.files:
            attachments = request.files.getlist("attachments")
            for attachment in attachments:
                if attachment.filename:
                    # Upload attachment to Bunny.net
                    import uuid
                    att_extension = attachment.filename.rsplit(".", 1)[1].lower()
                    att_filename = f"attachment_{uuid.uuid4()}.{att_extension}"
                    
                    att_upload_result = upload_to_bunny_storage(attachment, att_filename, course.title)
                    
                    if att_upload_result["success"]:
                        lesson_attachment = LessonAttachment(
                            lesson_id=video_lesson.id,
                            filename=att_filename,
                            original_filename=attachment.filename,
                            file_url=att_upload_result["url"],
                            file_type=att_extension,
                            file_size=len(attachment.read())
                        )
                        db.session.add(lesson_attachment)
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Video metadata saved successfully",
            "video_id": video_lesson.id
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"Error saving video metadata: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"Failed to save video metadata: {str(e)}"
        }), 500


@app.route("/admin/get-course-info/<int:course_id>", methods=["GET"])
@admin_required
def get_course_info(course_id):
    """Get course information including title for folder organization"""
    try:
        course = Course.query.get(course_id)
        if not course:
            return jsonify({
                "success": False,
                "message": "Course not found"
            }), 404
        
        return jsonify({
            "success": True,
            "course": {
                "id": course.id,
                "title": course.title,
                "description": course.description,
                "created_at": course.created_at.isoformat() if course.created_at else None
            }
        })
        
    except Exception as e:
        print(f"Error getting course info: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"Failed to get course info: {str(e)}"
        }), 500

